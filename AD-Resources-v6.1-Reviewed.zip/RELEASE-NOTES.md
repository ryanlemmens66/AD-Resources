## Canvas and divider refinement, 28 September 2026

v6.1 build `20260928.2`. Canvas lightened to #F4F6F3. The desktop splitter
column is 24px, with card padding and scrollbar allowance balanced against
the map edge. Tabs align with the card edge. The resize and keyboard logic
are unchanged, and expanded map mode removes the extra edge allowance.

Mouse/trackpad desktop layouts retain a slim, quiet scrollbar and stable
scrollbar space. Touch layouts use native scroll indicators without a reserved
gutter. No scrollbar is forcibly hidden and scrolling remains enabled.

115 static checks passed; source comparison confirms that operational and map
scripts are unchanged (only the build identifier changed in configuration).
Rendered spacing and native scrollbar behavior still need device acceptance.

## Final consistency pass, 28 September 2026

v6.1, build `20260928.1`. The build identifier appears in System Status, the phone-accessible Desk Status
panel, and the deployment self-check, without changing the main header version. Future
working packages should increment APP.buildId and keep buildDate aligned with
the file header. Build identity is diagnostic, not a cache invalidation mechanism.

- Desk Status now says Connecting to services until every service confirms;
  it no longer reports All feeds live while a service is still connecting.
- SAR Water now shares Land's guarded copy feedback and retains generated text
  for manual copying on failure. Successful retry closes that recovery output.
- Land/Water generators bind only their own messages. Copy controls avoid
  duplicate listeners when sections are revisited.
- Clinical Advice uses the shared copy feedback and retry behavior, restoring
  its action label. Generated wording is unchanged.
- Both Primary skill rows expose their selected state through aria-pressed,
  including deselection, draft restoration and reset.
- Removed an obsolete selected-pill shadow rule and corrected the in-file
  design guidance to describe individual skill pills.

The accepted visual design, map behavior, calculation rules and data remain
unchanged. Real browser and live-service acceptance are separate from automated
checks; no new rendered or Citrix certification is claimed.

Verification: all 247 automated checks passed across seven suites (115 static,
43 runtime, 56 workflow, 9 offline, 7 asynchronous-state, 6 map-policy and
11 aircraft-advisory). The new workflow checks cover secondary copy recovery,
selected-state accessibility, build identity and connecting-service messaging.
The runtime suite passed before the final status-summary correction; static and
workflow suites were rerun after that correction. No rendered/live certification
is implied. Archive integrity passed.

## Phone header action, 28 September 2026

At the existing compact-header breakpoint (700px and narrower), Reset Forms
now occupies the header action position instead of Board View. Wider layouts
retain all existing actions. The existing two-tap confirmation is unchanged:
first tap shows Confirm Reset?, second tap resets; confirmation expires after
12 seconds. No reset logic changed. Static checks passed (115); rendered phone
acceptance remains open.

## IHT/SAR aircraft advisories and FENZ preview, 28 September 2026

- All three workflows now resolve their own location and selected resource for
  the amber Closer aircraft advisory. IHT uses the sending hospital; SAR uses
  its scene. Primary uses its selected base or live aircraft.
- The pill opens the matching Live Aircraft panel and remains advisory only.
  It does not assert availability or change resource selection. Only airborne
  fixes within the existing five-minute response freshness threshold qualify,
  and failed/stale feeds suppress the advisory.
- IHT/SAR selection and reset changes refresh the advisory immediately.
- FENZ LZ Request now has a three-row, vertically resizable preview with an
  accessible label. Longer messages remain scrollable and fully copyable.
- Targeted verification: 115 static, 44 workflow and 11 new advisory checks
  passed. Prior full review passed 224 checks; unaffected suites were not rerun
  for this focused change. Real browser layout and live feed checks remain open.

## Updated upload review, 27 September 2026 (same v6.1)

Reviewed the newly supplied ZIP as the working version. Preserved its header,
skill chips, map-footer pills and zoom 4.7 national view. Corrected Auto island
label handling so Topo is untouched and stricter native zoom thresholds remain.
Consolidated coordinate/shortcode copy feedback and restored a manual-copy SAR
message preview when clipboard access fails, with a guarded successful retry.
Removed the unused copied-icon style. No clinical datasets, calculation rules,
generated message wording, button styling or Firebase paths changed.

`npm test`: 224 checks passed (115 static, 43 runtime, 44 workflow, 9 offline,
7 asynchronous-state and 6 map-policy). These include DOM simulations and mocked
services, not rendered or live-service certification. Updated deployment, rollback
and test documentation; AUDIT.md and VISUAL-REVIEW.md now contain current status.
Browser, actual Citrix and deployed-origin sign-off remain outstanding.

## v6.1 desk presentation packaging, 27 September 2026

Same release identity as v6.1 (APP.version 6.1, baseline v6.0, dataVersion
2026.09.24). This ZIP is the file to upload to Netlify.

What changed in the HTML: Auto island/country labels hidden below zoom 7;
default/reset zoom 4.7; Live Flight Events label; Heli Status Board count
pills; Primary skill chips as loose hairline pills; header pine surface
treatment on the existing 68px bar.

What did not change: button colours, datasets, calculations, CAD text,
Tasking & Clinical Guidance wording, Firebase paths, tab strip, What's New
and Citrix first-load cards, dashed Guidance / + Add, map toolbar.

Checks run on this ZIP: `node tools/check.mjs` (115) and
`node tools/offline-check.mjs` (9). jsdom suites require `npm ci` on a
maintainer machine and are unchanged in intent. Live-origin Citrix, iPad
and provider smoke remain the production sign-off in README.md.

## Times alignment and non-map release review, 27 September 2026

- Times Breakdown uses dedicated paired parameter panels, shared row tracks where supported and a regular-height fallback. Labels have separate Editable / Read only metadata, inputs fill their column, and phone layouts stack the panels. Shortened display labels; time arithmetic and field identities are unchanged. Missing read-only values display Unavailable.
- Weather results and failures can update only their original, still-open dialog. A late response no longer reopens a dismissed popup or replaces another one. Failures retain reference content and offer Try again.
- Empty contact/code searches now announce the empty result and suggest a different query. Modal keyboard traversal excludes negative-tabindex, hidden and inert controls.
- Checks passed: 115 static, 43 app-runtime, 41 workflows including keyboard navigation, 9 offline-worker and 7 simulated service-state checks (215 total). The state suite is included in npm test. These are source/DOM checks, not actual browser layout or live-provider verification.
- User reports general device consistency satisfactory, except the times popup addressed here. Verify the updated popup on iPad and phone. Actual Citrix performance and deployed-origin/provider sign-off remain open. No deployment or shared operational record was changed; maps remain deferred.

## Approved compact advisory, 27 September 2026

- Removed the workflow column's outer border, shadow and rounded clipping. Individual tabs and cards remain on the overall grey canvas.
- Changed the closer-aircraft banner into a pale amber pill immediately after Live Aircraft. The visible label is "Closer aircraft"; the fuller detection message and TracPlus source remain available to assistive technology and in the tooltip. The pair wraps only if the available width cannot contain it.
- Map styling and behaviour, clinical labels and proximity logic are unchanged. Unrelated labels in the generated mockup were not applied.
- Validation: 115 static checks passed. Isolated DOM checks verified placement, accessible wording, stable refreshes, clearing and reappearance. Device layout review remains outstanding.

## Unified workflow canvas, 27 September 2026

- Cards and individual navigation tabs now sit directly on the existing overall grey canvas. Removed the white navigation strip and the second, blue-grey content background.
- Inactive tabs are separate white controls with spacing, while the active green state remains. The map and functional modules are unchanged.
- Static audit: 115 checks passed. Visual review on iPad and phone remains required.

## Card contrast and comparison layout, 27 September 2026

- Added a shared cool grey canvas behind workflow cards across all four tabs, retaining white card surfaces and gently strengthening their borders.
- Compare Hospitals now uses five equal metric columns above 700px. Narrow views use two columns, with the fifth metric spanning the final row.
- Replaced the inline closer-aircraft text with an amber advisory above Live Aircraft: "Closer aircraft detected", with "Live position · TracPlus" beneath. Status updates occur only when the advisory changes. Proximity calculations, provider polling and map behaviour are unchanged.
- Validation: 115 static checks and 38 workflow checks passed. An isolated DOM check verified advisory placement, content, repeated updates, clearing and reappearance. Rendered device review remains required.

## Non-map completion pass, 27 September 2026

- Consolidated four document-copy handlers into the existing feedback module. Primary CAD, Transfer CAD, SAR CAD and FENZ request previews now permit retries, prevent concurrent duplicate writes, announce failures and restore original labels and icons.
- Clinical notes and referring clinician sections expose their expanded state and return focus to Add after user deletion. Programmatic resets retain focus. The privacy clear path also restores the notes Add row and disclosure state.
- Consolidated identical hover declarations without changing selectors or styling, and replaced stale introductory release prose with links to the maintained documentation. No additional override stylesheet was appended.
- Preserved the accepted visual treatment, intentionally thin header and separate logo. Map, configuration, clinical data and calculation modules are unchanged.
- Validation: see AUDIT.md. Rendered phone, iPad and desktop review and live-origin service checks remain outstanding; DOM simulation is not device verification.

## v6.1 optional-section spacing, 27 September 2026

- Referring Clinician now has a 48 px minimum height, 8 px vertical padding and 16 px spacing above/below. A row containing a button needs more breathing room than a plain input.
- Primary Clinical Notes uses the same spacing principle, with a 44 px minimum borderless row and a 12 px label/action gap.
- Expanded clinician and clinical-note headers have 12 px separation from their fields. Optional header text can wrap with a readable line height.
- Button dimensions, application logic, mapping and calculations unchanged. Source checks do not replace visual device review.

## v6.1 shared action button refinement, 27 September 2026

- Added shared resting/hover shadow tokens to coloured action pills, primary actions, reference actions and header actions. Neutral shadows and a fine inset edge replace the stronger coloured glow.
- Standard action pills use 32 px height, 12 px horizontal padding and centred 12 px labels. Compact card-header actions retain a 28 px minimum and 11 px labels, including the existing narrow-screen spacing rules.
- Existing palette, gradient fills, pill shapes, outlined/quiet actions, selector states and overdue-alert animation retained. Larger primary actions and compact header controls retain their functional sizes.
- App markup/scripts and all map CSS rules verified unchanged. All background colours and gradients match the preceding version.
- Rendered phone/iPad/desktop verification remains outstanding.

## v6.1 surface, typography and reference consistency, 27 September 2026

- Clinical Hub comparison: its restrained card borders, stacked shadows and small inset highlights informed this pass. No additional backdrop blur or translucent reading surfaces were introduced.
- Workflow card headers and resource accordions now share subtle surface highlights, quieter depth and consistent spacing. Green heading icons retain a small sheen with reduced glow.
- Resources cards now use the same border, radius and shadow treatment as the main workflow cards instead of their older heavy shadow override.
- Removed conflicting reference-sheet rules that reduced panel gaps to 6 px, padding to 14 px and body text to 13 px. Reference panels now retain 16 px gaps, 16/18 px padding and 14 px body text with 1.6 line spacing. Headings use readable sentence-case styling rather than small uppercase styling.
- Coordination and Key Questions have consistent 16 px section gaps. Mobile Tasking Guidance reading text is 13.5 px with 1.65 line spacing. Helicopter Change Process instructions and Shift Notes have more consistent reading typography.
- App markup, embedded scripts, clinical content and calculations verified unchanged. All 572 CSS rules identified for map/button controls match the preceding file. Resource-card landscape columns, one-line names and corrected footer spacing retained.
- Rendered device verification remains outstanding. This is a source and automated-workflow verified refinement, not a claimed screenshot/device sign-off.

## v6.1 form cleanup, 27 September 2026

- Removed location guidance from Primary and SAR and the sending-hospital guidance from Transfers, including their obsolete aria-describedby references.
- The collapsed Referring Clinician row now uses the standard control height and corner radius, with vertically centred text and Add action.
- No JavaScript, calculation, clinical content or mapping changes.

## v6.1 landscape card layout and metadata spacing, 27 September 2026

- Restored two equal resource-card columns in landscape; phone portrait retains stacked cards.
- Removed the conflicting Primary picker padding rule that placed the distance/time text too close to the footer divider.
- Metadata now follows the selection context with a 12 px gap and at least 16 px before the footer. Names retain single-line truncation.
- CSS-only change. Scripts, calculations and data verified unchanged. All 115 source checks passed. Rendered device verification remains outstanding.

## v6.1 resource and destination cards, 27 September 2026

- Primary helicopter and hospital cards now use pine top accents, icon tiles, prominent names and aligned lightly tinted action footers.
- Names stay on one line. Long names use an ellipsis without changing the underlying name, picker or CAD output. Card columns respond to available panel width, with a 260 px preferred minimum before stacking.
- Distance and time remain secondary. Existing action button styles retained.
- Selection context distinguishes closest base, manual selections and live aircraft. Hospital context says Selected destination because the current automatic lookup is distance-based, not a catchment-boundary calculation.
- No calculation rules, map controls or clinical content changed. 115 source checks and 26 DOM workflow checks passed. Rendered device review remains outstanding.

## v6.1 audit and offline resilience, 26 September 2026

- Offline worker preserves successful network responses when cache storage is unavailable or full, falls back on host 5xx errors, and preserves unrelated caches.
- Added workflow and offline-worker regression checks to npm test; added a phone profile to browser verification.
- Excluded review/audit documents from public Netlify routes.
- See AUDIT.md for test evidence and outstanding rendered/live-service acceptance. No UI styling, clinical content or calculation rules changed in this pass.

## v6.1 form guidance and output hierarchy, 27 September 2026

- Added concise location prerequisites to Primary and SAR scene search and the Transfers sending-hospital field, linked through aria-describedby.
- Marked the additional narrative note fields as optional without adding new mandatory inputs.
- Time breakdown fields now have associated labels and explicit Editable / Read only descriptors, with a shared minutes explanation.
- Totals have a distinct labelled output row.
- Existing negative-time validation now also displays a nearby accessible message and clears it when corrected. Blank-value and calculation behaviour retained.
- Validation: 115 static checks passed. Targeted tests passed for negative, corrected and blank inputs, inline-message clearing, label associations and read-only rendering. Calculation, output-sync and total-rendering functions verified unchanged. Browser/device visual verification remains outstanding.

## v6.1 interaction and header polish, 27 September 2026

- Header gradient aligned with Clinical Hub's pine palette. Brand icon, title, status and actions have explicit sizing and wrapping behaviour. Button colours and shapes retained.
- Main tabs and supporting action hover effects apply only to fine, hover-capable pointers.
- Busy and temporary button labels retain and restore actual child nodes, preserving icons and listeners. Repeated temporary labels cancel the earlier timer. Original aria-busy state is restored.
- Replacement popups retain the original workflow return-focus target. Closing a popup falls back to the active tab if the old control is unavailable. Deferred focus ignores closed or replaced dialogs. Tab trapping handles focus on the dialog itself.
- Warning/error toasts default to five seconds, and the existing polite live region announces complete messages atomically.
- Reduced-motion mode disables smooth scrolling in guidance panels.
- Existing confirmation, error, empty-state and Citrix mechanisms retained. Map engine, map controls, data and calculations were not edited.
- Validation: 115 static checks passed. Targeted VM tests passed for repeated busy/flash labels, icon-node preservation, aria-busy restoration and popup return-focus fallback. These tests are not a browser test. Rendered and device interaction verification remains outstanding.

## v6.1 main and secondary screen consistency pass, 27 September 2026

- Main form grids use shrinkable columns and a consistent 12 px gap. Shift Notes metadata uses the white panel treatment.
- Daily Duties has more readable headings, 14 px task text, increased line spacing, larger row padding, and wrapping that respects narrow grid columns.
- SAR Coordination and Key Questions cards use the same reading density as other reference panels.
- Clinical Advice narrative textareas use DM Sans, 14 px text and 1.6 line spacing; CAD output remains monospace.
- Hospital capability panels use consistent rounded sections, more row spacing, shrinkable columns and wrapping titles. Removed excess right padding from the mobile hospital heading, where actions already occupy their own flex column.
- System Status and self-check descriptions use readable supporting text and the defined white surface token.
- All 115 static checks passed. All 314 action-button and selector CSS rules, embedded scripts, data and HTML markup remain unchanged.
- This is a source-level consistency pass. Browser binary retrieval remained unavailable, so no rendered phone, iPad, desktop or Citrix visual pass was completed. See VISUAL-REVIEW.md for the outstanding review list. Mapping controls and button redesign remain deferred.

## v6.1 mobile header fixes, 27 September 2026

- Coordination button shows "Coordination" at viewport widths up to 650 px and retains "Determining Coordination" in wide view and its accessible name.
- Land or Water and Shift Notes mobile headers use content-sized title and action columns instead of the shared 9rem title basis.
- Mobile action labels remain complete, with tighter horizontal spacing and decorative button icons hidden. Below 381 px the decorative heading icon is also hidden to preserve room for the text.
- Button colours, shapes, destinations and wide-view headers are retained.
- All 115 static checks passed. Phone visual verification remains outstanding.

## v6.1 typography and reference-panel review, 27 September 2026

- Retained DM Sans, with 15 px medium-weight workflow headings and clearer 11 px field labels, reduced letter spacing and more label separation.
- Increased main card content padding to 18 px and aligned header spacing.
- Widened standard dialogs to a maximum of 640 px within the viewport, with 20 px body padding and consistent 17 px titles. Long titles wrap, and close controls retain their size.
- Increased reference text to 14 px with more line spacing, separated reference sections, and added table row padding. Reference sections can scroll horizontally for wide tables.
- Improved Tasking and Clinical Guidance paragraph, list, rule and table readability without changing guideline wording or thresholds.
- All 313 action-button and selector CSS rules are unchanged. The close control only gained a flex sizing constraint to prevent shrinking. No HTML, JavaScript, clinical content, calculation or mapping logic changed.
- Validation: all 115 existing static checks passed. Confirmed unchanged markup/scripts outside styles and unchanged action-button/selector rules. Live browser/device visual verification remains outstanding because a browser binary could not be downloaded in this environment.

## v6.1 card and spacing review, 27 September 2026

- Matched the surrounding canvas to Clinical Hub's warm neutral surface.
- Made workflow cards and resource panels white, with quieter borders and softer card shadows.
- Aligned card headings and content to 16 px side padding.
- Standardised resource and skill-section inner padding and gaps to 12 px, retaining the compact responsive layout.
- Softened resource action-row dividers and aligned their spacing.
- Buttons, pills, tabs and skill selector CSS rules are unchanged. No HTML, JavaScript, calculation or mapping logic was changed.
- Validation: all 115 static checks passed; verified identical HTML/JavaScript outside style blocks and all 313 button/selector CSS rules unchanged. Browser and device visual validation remains outstanding because the browser download failed in this environment.

## v6.1 working-file completion, 27 September 2026

- Fixed sticky white hover highlights on touch devices for clinical skill, transporting unit skill, CAD time format and shared segmented controls. Hover feedback now requires a fine pointer that supports hover. Active selections retain their green styling.
- Restricted resource-pill hover lift and shadow feedback to hover-capable fine pointers.
- Updated the IHT maternity facilities legend to "Bold facilities indicate tertiary maternity facilities". Existing bold tertiary facility names are retained.
- Kept app version 6.1 and the existing splash behaviour. AirDesk schedules dismissal after DOM readiness and at least 550 ms from navigation, followed by a 400 ms fade. Clinical Hub Resources(3).html schedules dismissal 950 ms after its splash script runs, with a 450 ms fade. These are source timings, not measured device timings.
- Validation: all 115 existing static checks passed. Browser touch and visual checks could not run because a browser binary could not be downloaded in this environment. Please confirm EMT to CCP selection on iPhone/iPad, both clinical and transport rows, and open Transfers > Recognised Hospital Facilities.
- Design review: the next restrained polish pass could reduce coloured pill shadows, reserve strong colour for key actions and statuses, and standardise button spacing. No broad visual redesign is included in this maintenance update.

# AirDesk release notes

## v6.1 - 2026-09-26 - Polish from v6.0, replacing the abandoned 6.1-6.3

This is the release that follows v6.0 in production. Ryan tried a button-colour
exploration under the working numbers 6.1-6.3, decided it had gone too far, and
asked to start again from v6.0 -- keeping only non-button polish. That work
continued under working numbers 6.4 and 6.5 while he reviewed it; both are
retired now that it's finished, and this entry describes the whole of what
changed since v6.0, so the project has one clean release to sit on top of the
baseline rather than a trail of intermediate version numbers. **Button colours
are exactly v6.0's, throughout** -- pending a separate decision. **v6.0 is the
immediate rollback release.**

**Layout.** Heli Status Board: solid `#163f24` header (each sticky `th` had
drawn its own gradient, making stripes) and a real gutter (a later `padding:0
!important` had cancelled the intended one). Calculation Summary: cards share
row tracks with `grid-template-rows:subgrid`, so boxes and verdicts line up
whatever wraps; the verdict keeps "2 min" together and balances a wrapped line.
Response Plan on iPad: pills in a wrapping row share each line instead of
orphaning one. Board View: the Aircraft column is never clipped (every tail was
clipped at 1920 Split and on an iPad in Wall; 1920 Map is unchanged) and the
resize grips are short, matching the main view's.

**Controls.** One close button for every dialog: a 32px circle with a CSS-drawn
X in place of the × character, which stays in the markup at zero size so
accessible names are unchanged. One segmented control -- a track with a solid
green selection, the colour of the active tab -- used by the skill pills, the
CAD times format and the System Status Standard/Citrix switch, which no longer
uses blue as a second, unrelated "selected" signal.

**Labels and icons.** Status chips read in one case ("Live", "Error", "Online"
beside "Configured"). Key Questions counts 1, 2, 3 instead of 01, 02, 03. The ▾
picker chevron and the ↺ Reset icon are drawn, not text characters.

**Decoration removed.** The gradient stripe down the side of every card and SAR
tile, and the per-screen micro-title ("PRIMARY TASKING") that only repeated the
tab already selected above it. Header status chips are flat tints; the action
buttons (Board View, Recent Taskings, Reset Forms) keep v6.0's look, and the
divider between the two groups is now a visible rule instead of a 4px speck.

**Launch and fonts.** A launch splash in the header's green, structured like
Clinical Hub Resources' (mark, name, Hato Hone St John), with no fake progress
bar. It leaves once the app is ready and never before 550ms, and a CSS
failsafe removes it at 3.2s even if its script never runs, so it cannot trap
the app the way an older Air Desk splash once did. On iOS Safari it also draws
matching portrait and landscape launch images at runtime (re-add AirDesk to the
Home Screen once to pick them up). DM Sans and Roboto Mono are embedded as
woff2, so type is identical offline, in Citrix, and when Google Fonts is
unreachable; the CSP no longer allows an external font. `theme-color` matches
the header's top edge. Shimmer placeholders replace "Looking up…", the pending
road-ETA line and the weather spinner while each is loading.

**Tokens.** The app stylesheet's literal values sit on one scale: type
10/11/12/13/14.5/16/18.5/22px (39 sizes reduced to 8), radii 6/10/14/18px plus
pill and circle (20 reduced to 8), and `--shadow-sm/md/lg` for plain drop
shadows (46 reduced to 3; insets, focus rings and coloured glows stay
explicit). Font weights needed no further change: embedding the fonts already
required remapping every weight to 400-800 in hundreds, the only weights
actually loaded, so this pass found nothing left outside that set.

**What's new.** A small card appears once after AirDesk updates to a version
listed in its `NOTES`, dismissed with Got it and keyed `whats-new-seen` (the
one new storage key). A first install stays quiet; the wall board never shows
it.

**Response Plan card footers (new in this pass).** The Helicopter and
Destination Hospital cards are stretched to equal height, and each one's
button row is pinned to the card's bottom edge so the button doesn't move
around; when one card has less content than the other, the shorter card was
left with an empty gap above its button. A divider now sits above the button
row on every `.resource` card, turning that space into a visible footer rather
than a gap that reads as a mistake. The name-to-detail spacing above it (e.g.
"NRHL Auckland" to "19 NM · approx 19 min to scene") is also a touch more open,
so the top of the card breathes more evenly against the new footer below.
Checked at 1024, 1440, iPad and phone widths, with and without a wrapped
hospital address.

**Calculation Summary subtitles (new in this pass).** "Time until arrival at
scene", "Time until required clinical skill arrives" and "Total time to
hospital" are no longer shown: the icon and bold title already say it, and nothing
in this app teaches a first-time reader anything the label doesn't. The text
is kept for screen readers only (the existing `.sr-only` pattern), so the
accessible name is unchanged. Removing it also let two now-unnecessary rules
go: the two-line height the subtitle used to reserve, and its two responsive
font-size overrides. The three cards still align: their shared height now
comes from the bold title's own reserved height, which every card already had.

**Checks.** Static 115/115, jsdom 43/43 and Chromium 147/147 including Axe. The
Calculation Summary cards were measured at desktop, iPad and phone widths and
report identical row positions across all three cards, with and without the
subtitles. Response Plan cards were checked at four widths for the divider and
spacing. `visual-check compare` was not the gate for the token portion of this
work, since a sizing pass changes every screen by design; a text-overflow probe
and an eye review with the real fonts stood in for it, as they did when this
work was staged under 6.4 and 6.5.

**Not verifiable here.** Live map tiles, providers, and real iPad, iPhone Home
Screen and Citrix rendering. Repeat the post-deploy live-origin smoke test for
v6.1.

## v6.0 - 2026-09-24 - Stable Production Baseline freeze

v6.0 is the deliberate freeze of the final audited AirDesk line, promoted from
v5.56 rather than used as another exploratory development cycle. The objective
is a durable production baseline with every runtime difference from v5.56
accounted for, stable metadata, owner-confirmed operational records and a clear
future maintenance contract. **v5.56 is the immediate rollback release.**

**Operational records closed by the operational owner.** Ryan Lemmens confirmed
on 2026-09-24 that the SH6 Haast-to-Lake-Moeraki closure remains current until
further notice, the PARAPARA 30-minute road-time adjustment is permanent, and
Waihi Bowling Club should be active now as the preferred LZ replacing inactive
Morgan Park. Only those corresponding embedded records were changed. The old
Haast 26 December 2025 end-date text, PARAPARA "foreseeable future" wording and
future-dated Waihi transition were removed. `APP.dataVersion` is now
`2026.09.24`; protected feature ids and counts are unchanged.

**Stable release metadata adopted.** `APP.version`, filename, build chip,
package metadata and Netlify rewrites now identify v6.0. `APP.baseline` is
`6.0 Stable Production`, System Status reports the v6.0 Stable Production
Baseline, and the in-file maintainer header records v5.56 as the rollback ZIP.
The baseline is intentionally independent of future routine patch versions and
should move only when a later release is formally adopted as a replacement
stable baseline.

**External production controls accepted by the current owner.** Ryan Lemmens
confirmed ownership of the production provider accounts and that the required
Google/LINZ/Firebase controls are in place. He also confirmed the existing
TracPlus Cloudflare Worker arrangement is acceptable for production. These are
owner attestations rather than facts a static ZIP can inspect. Firebase client
configuration remains non-secret and Realtime Database Security Rules remain
the authoritative server-side access control.

**Maintenance runtime corrected.** The package had declared Node >=18 while its
locked `@playwright/test` 1.63.0 package declares Node >=20. v6.0 raises the
project engine to Node >=20 in both package metadata files and adds a static
compatibility check against the locked Playwright engine. This changes only the
developer/test environment, not the browser application.

**Freeze safeguards added.** The static production suite now verifies the
stable-baseline header and `APP.baseline` agree, the dataset baseline date and
`APP.dataVersion` agree, and the three newly confirmed operational records stay
in their approved v6.0 state. The duplicate-ID audit was also corrected so ids
on void, script and style elements are included rather than silently skipped.
Current handover prose now avoids duplicating brittle code-count figures where
the audit output itself is the authoritative live count. This is deliberately
narrow protection around the facts changed for the freeze, not a second copy
of the whole operational dataset.

**What did not change.** No operational calculation, Tasking & Clinical
Guidance source/template, Tasking dialog styling, map engine, provider endpoint,
Firebase path, storage key, privacy boundary, Heli Status model, Board View
workflow or service-worker behaviour was changed. The v5.55 phone-edge guidance
border fix is preserved unchanged.

**Final acceptance boundary.** The versioned package can prove static,
structural and packaged-code invariants. It cannot prove live provider quotas,
server-side Firebase rules or the behaviour of the final Netlify origin. The
post-deploy smoke test in README therefore remains the final operational
acceptance step after upload, not an invitation to reopen the frozen codebase.

## v5.56 - 2026-09-24 - Final pre-freeze handover reconciliation

This release is deliberately maintenance-only. The objective was to remove the
remaining ways a future maintainer could be misled by stale current
documentation or incomplete regression checks before the next release is
formally designated as the stable production baseline.

**Current documentation reconciled to the actual package.** The HTML maintainer
header and `ARCHITECTURE.md` now describe the visual suite that actually ships:
18 maintained screens across desktop, iPad and phone profiles, 54 screenshots
in total. Architecture now correctly says the service catalogue contains six
providers after the v5.53 DOC live-API removal. The header no longer pins
external-control wording to an old v5.50 deployment.

**Netlify release-gate wording made consistent.** README already treated local
`npm run test:all` as authoritative. The same rule is now stated in the HTML
header and `netlify.toml`: the configured `node tools/check.mjs` is a useful
additional safeguard on deploy paths that actually invoke a Netlify build, but
manual upload behaviour varies and must not be treated as a substitute for the
local jsdom/Chromium suites.

**Credential regression coverage completed.** `tools/check.mjs` previously
called its Google-format scan "all API keys" even though it could not see the
two LINZ values added to `runtimeConfig`. The check now asserts all four
expected client configuration values by owner: Google Maps, LINZ Basemaps,
LINZ Data Service and Firebase. It also requires the LINZ credentials to remain
distinct, requires Google Maps and both LINZ values to remain single-source,
and verifies that the Powerlines module consumes
`AirDesk.runtimeConfig.linzDataServiceApiKey` rather than carrying another
hidden copy.

**Dependency/attribution wording corrected.** `NOTICE.md` no longer lists the
Department of Conservation API as a live runtime dependency. DOC-derived huts
and campsites are described as embedded static source data, while LINZ Data
Service is explicitly named for the live Powerlines WFS layer.

**Stale external pricing removed from the current handover.** Firebase plan
ceilings and Google price/free-allowance numbers were not runtime contracts and
would age independently of the code. README now preserves the application
behaviour that matters for support, which workflows call which provider and
how failures degrade, while requiring the production owner to confirm current
pricing, quotas and billing in the provider consoles.

**Production sign-off made explicit.** The existing Google, LINZ and Firebase
external controls remain. The checklist now also records the TracPlus
Cloudflare Worker ownership/support dependency and the three dated operational
records identified in the final handover review: SH6 Haast to Lake Moeraki
Closure (embedded end date 26 December 2025), PARAPARA Drive Time (dated
1 November 2021, "for the foreseeable future"), and the Morgan Park LZ / Waihi
Bowling Club transition (30 September / 1 October 2026). No operational wording
or status was guessed or changed in this software-only release. Those records
must be confirmed from an approved source before a long-term frozen baseline.

**Future baseline procedure added.** README now gives a durable promotion
sequence: close/accept sign-off items, version from the last tested ZIP, update
baseline metadata only when formally adopting a new rollback point, run the
full suite, package without `node_modules`/temporary artifacts, record the ZIP
SHA-256, deploy through the approved Netlify path, perform the live HTTPS
desktop/iPad/offline smoke test, and retain the immediately previous release as
rollback.

Two additional static drift guards were added: current visual-regression counts
must agree with `tools/visual-check.mjs`, and `NOTICE.md` must not regress to
calling DOC a live API dependency.

v5.56 preserves the v5.55 Tasking & Clinical Guidance dialog edge-margin
correction exactly as supplied. Beyond that carried-forward layout fix, no
application calculations, routing rules, approved Tasking & Clinical Guidance
wording, protected map/reference datasets, Firebase paths, storage keys,
service-worker behaviour or provider endpoints changed in v5.56.

## v5.55 - 2026-09-24 - Guidance dialog edge margin on phones

Reported from a phone screenshot: the guidance dialog sat hard against the right edge, asymmetric with its left margin. Measured directly: the dialog's width was set by `.dialog:has(.tg-shell)` as a viewport-percentage (`96vw` at base, `98vw` under 1050px), but the surrounding `.backdrop` that centres it has its own `padding:16px`, which those percentages never accounted for. At narrow widths the dialog ended up wider than the space actually left inside that padding, so it ran past the edge rather than sitting centred. Fixed by sizing both rules as `min(<cap>, calc(100vw - 32px))`, matching the backdrop's 16px-per-side padding exactly at any viewport width. Confirmed: the gap is now 16px on both sides at 390px width, and desktop/iPad are unaffected since their fixed-pixel caps (1360px, 1050px) are unchanged and still smaller than the new formula at those widths.

## v5.54 - 2026-09-24 - Final audit: accessibility closed out

A final production review of v5.53. All three suites passed as delivered (98 static, 43 jsdom, 147 Chromium), ESLint and CSS validation were clean, the Netlify security headers were confirmed production-grade (revalidating cache policy on HTML and `sw.js`, `nosniff`, framing denied, strict referrer policy, enforced CSP), and the service worker correctly carries no version literal. The one area not re-examined since v5.29 was accessibility, and a lot of UI has been added since then, including the entire guidance module and the Heli Status additions.

**Method matters here.** An Axe sweep (WCAG 2 A and AA, serious and critical only) was run on every workflow tab, the guidance dialog and Heli Status, at desktop (1440) and phone (390) width. The first pass sampled too soon after each tab switch and dialog open: it reported one false positive (the inactive Transfer label, sampled while the sliding active-tab indicator passed behind it) and *missed* three genuine failures, because Axe skips text that is still fading in. Every finding was therefore re-measured after animations settled before anything was changed.

**Fixed: keyboard access to scrolling content.** Three containers scroll but held nothing focusable, so a keyboard user could not scroll them: `.tg-content` (the guidance content column), `.tg-table-wrap` (wide guidance tables, which scroll sideways on narrow screens) and `.airdesk-hsb-tablewrap` (the Heli Status table on phone). Each is now `tabindex="0"` with `role="region"` and an `aria-label`. The guidance tables are numerous, so this is applied once by the renderer rather than repeated in every table's markup.

**Fixed: small helper text below AA contrast.** Measured at rest against its real background: guidance search hint `#87938c` on white (3.19:1), guidance footer `#6d7a72` on white (4.49:1, just under), Heli Status legend footer `#7A8A80` on `#f4f7f5` (3.37:1), all at 10-10.4px where 4.5:1 is required. Each now uses `#5f6f66`, the grey the app already uses for tab labels, so no new colour entered the palette. Each colour was confirmed to be set by exactly one rule before changing it, so nothing else could shift. Visual regression against v5.53 changed exactly the eight expected screens (Heli Status live/edit and the guidance dialog, across sizes; the phone guidance screen hides the search hint and did not change) and no others.

**Not changed:** the Transfer tab label measures correctly at rest; its reported failure was animation timing.

**Documentation:** ARCHITECTURE.md's named-function count (762 to 756) and listener count were refreshed after the v5.53 DOC code removal; all other figures in README and ARCHITECTURE were re-checked against the package.

Verification: 98 static, 43 jsdom runtime and 147 Chromium checks pass; Axe reports no serious or critical findings on any tested screen at either size; 25-cycle soak stable with zero page errors.

## v5.53 - 2026-09-24 - Four items from an independent review, each checked before acting on it

A second reviewer (ChatGPT) went through the v5.52 package and reported four remaining items. Each was independently verified against the actual code, and for the two involving claims about external providers, against those providers' own current documentation, before anything was changed -- consistent with how every other external review in this project's history has been handled.

### 1. Dead DOC (Department of Conservation) code, confirmed and removed

`#airdesk-outdoor-access` declares `const IDS=['powerlines']`, and `state` is built by mapping over `IDS`. A parallel DOC-huts-and-tracks implementation still lived in the same module: a second embedded API key (`docKey`), the `huts`/`tracks` endpoint URLs, `fetchDoc()`, three GeoJSON-conversion helpers (`hutsGeo`, `tracksGeo`, `listPayload`, plus `pick`/`coords` which only those two used), a `doc-huts` marker-icon-drawing branch inside `install()`, a `doc-huts` click-wiring branch inside `wire()`, and `openPoint()`. None of it was reachable: `state.get('doc-huts')` returns `undefined` given the current `IDS`, so `fetchDoc('doc-huts')` would throw on its first line if anything ever called it, and nothing did. This was not a working alternate feature sitting idle -- it was unreachable by construction, confirmed by reading `IDS` and tracing every call site.

Removed entirely, rather than left in place "in case it's wanted later": DOC huts and campsites are already served by the separate embedded static dataset elsewhere in the app, so a live DOC feed here would only recreate the exact duplicate-source-of-truth problem this project has spent multiple releases eliminating in other areas (the guidance-content consolidation, the map dataset-baseline split). If a live DOC layer is genuinely wanted in the future, it should be built and reviewed as its own feature, not resurrected from this.

Closing the loop meant touching four places, not just the module: the now-unused `doc` entry in the services catalogue, `api.doc.govt.nz` in the CSP `connect-src` (confirmed nothing else referenced either before removing them), and `tools/verify.mjs`'s `EXPECTED_SERVICES` list, which tracked `doc` as one of seven providers and now tracks six. README's "seven providers" claim was updated to match, with a pointer to this changelog entry rather than trying to explain the history inline.

### 2. A second, unnamed LINZ key -- confirmed genuinely separate, not a duplicate

The Powerlines fetch used a base64-encoded LINZ key baked directly into the outdoor-access module, distinct from `runtimeConfig.linzApiKey`. Decoding both confirmed they are different values, not the same key stored twice: `linzApiKey` (`d01kkytq...`) drives LINZ Basemaps tile requests (`basemaps.linz.govt.nz`); the hidden key (`103427f3...`) drives the LINZ Data Service WFS query behind Powerlines (`data.linz.govt.nz`). These are two different LINZ products with separate key issuance, which is a legitimate reason for two keys to exist -- the problem was never that a second key existed, only that it was hidden in a module rather than declared where every other provider key already lives.

Moved into `runtimeConfig` as `linzDataServiceApiKey`, alongside a rewritten comment explaining why there are two LINZ keys and naming which service each is for, so a future maintainer does not mistake one for a leftover duplicate of the other.

The reviewer also flagged the comment's claim that a LINZ Developer key is "unrestricted by design" with "no console to scope them in" as too categorical. Checked directly against LINZ's own current documentation (`basemaps.linz.govt.nz/docs/user-guide/technical-documentation`, "Security" section): *"Developer level access enables the allocation of static API keys which we can restrict to your nominated website."* The technical-specifications table on the same page marks Developer access as having an "API key nominated site restriction" of "Yes". The old comment's claim was factually wrong, not just imprecise. The corrected comment states plainly that restriction is available by contacting LINZ, that neither key here is confirmed restricted, and adds this as its own item in the README's Production sign-off checklist -- the same treatment the Google Maps key restriction already gets -- rather than continuing to assert it away.

### 3. One stale README instruction, confirmed as the only one

The production smoke-test step told the maintainer to "confirm the v5.50 build chip" -- three releases behind by the time this was read. Checked every other v5.50 reference in the file first, per the reviewer's own caveat that some are legitimate historical explanations (they are: frozen-baseline notes and past-release context that should not be touched). Found exactly one stale instructional reference, matching what was reported. Rather than simply swap in "v5.53" -- which would only be accurate until the next release -- reworded the instruction to check the chip against the package's own version and `APP.version`, so it cannot go stale at the next version bump the way this one did.

### 4. Netlify's build-on-upload behaviour, checked against Netlify's current documentation

README stated plainly that "Netlify re-runs the static check on upload." `netlify.toml` does configure `command = "node tools/check.mjs"` under `[build]`, so the claim was not baseless -- but checking Netlify's own current documentation (`docs.netlify.com/deploy/create-deploys`) found: *"When you create a deploy manually without continuous deployment, Netlify does not run a build command."* Netlify's own knowledge base adds that behaviour differs by upload path -- a logged-in Netlify Drop detects and runs a build, while CLI deploys and other manual paths do not, and the documentation does not equate all of these. Given this project's workflow is exactly "manual deploy, no continuous deployment, versioned ZIPs," the accurate position is that a Netlify-side re-check cannot be assumed to happen on every upload.

Reworded both places this was claimed: `npm run test:all`, run locally before the ZIP is created, is now stated as the authoritative pre-upload gate; any Netlify-side build/check is described as an additional safeguard when it happens to run, never as a substitute for the local suite.

### Verification

Functionally re-tested the rewritten outdoor-access module directly, not just checked that it parses: `AirDesk.data.outdoorAccess.config` now has exactly two keys (`linzKey`, `powerLayer`, no leftover DOC fields), the relocated key resolves to the same value it always fetched with, `AirDesk.services.catalog.doc` is gone, the catalogue has exactly six keys, and calling `setVisible('powerlines', true)` completes without throwing. A source-text search confirmed `doc.govt.nz` no longer appears anywhere in the application's JavaScript.

ESLint clean across all 75 app script blocks; CSS parse and declaration validity unchanged; security-pattern scan unchanged from every prior audit. 25-cycle soak test held DOM size, interval count and listener count constant, zero page errors. Visual regression against the unmodified v5.52 baseline: all 54 screens match exactly -- expected, since nothing in this release touches CSS or visible markup.

Verification: 98 static, 43 jsdom runtime and 147 Chromium checks all pass.

## v5.52 - 2026-09-24 - The guidance dialog had no mobile layout at all

Reported directly from a phone screenshot: the Tasking & Clinical Guidance dialog's version pill sat on top of its own subtitle text, and body content ran off the right edge of the screen instead of wrapping. This was reproduced exactly, at the same viewport width shown in the screenshot (390x844), before touching any code.

### Two independent root causes, both in CSS only

**Content silently clipped, not wrapped.** Measuring every element in the header and body showed `.tg-content` rendering at 674px wide inside a 382px-wide dialog -- nearly double -- with the excess clipped by `overflow:hidden` rather than causing a visible scrollbar, which is exactly why the earlier "does the page scroll horizontally" check gave a false negative. Tracing the width up the DOM tree led to three CSS rules: `.tg-searching .tg-main{grid-template-columns:1fr}` and two copies of `.tg-main{grid-template-columns:1fr}` inside the narrow-screen media queries. A bare `1fr` grid track does not shrink below the *min-content* size of what is inside it -- a well-documented CSS Grid behaviour, not a bug in the browser -- so if anything inside that track wants to be wider than the viewport, the whole track (and everything in it) is forced wider too. The desktop rule for the same column already used `minmax(0,1fr)`, which does allow full shrinking; the narrow-screen overrides had never received the same treatment. Changed all three to match. Verified by walking the full DOM tree under the rendered section and confirming zero elements exceed the dialog's actual width, at 390px, 360px, and every other tested size.

**Version pill overlapping the title.** The header is a three-column CSS grid (`auto minmax(0,1fr) auto`) at every tested width, including the narrow breakpoint -- and at every width except the narrow one, that grid places the version pill and close button cleanly in their own third column with no overlap. Only the narrow-screen rule then added `.tg-hero-meta{position:absolute;right:55px;bottom:8px}`, which pulls the pill out of that already-correct grid position entirely and floats it over the second column instead, colliding with whatever subtitle text happens to be there. Removed the one declaration; the pill falls back to the same in-flow grid position already proven correct at desktop, iPad landscape and iPad portrait.

Both fixes are subtractive or match an existing, already-working pattern elsewhere in the same file -- neither introduces new layout logic, which kept the risk of this touching anything else low. Confirmed with a full functional pass at 390px width: tab switching, search, and the close button (verified genuinely hittable via `elementFromPoint`, not just visually present) all work; and with a five-viewport sweep (1440, 1180, 820, 600, 360) showing zero overflowing elements at any width.

### Closing the gap that let this ship three times

`tools/visual-check.mjs` -- the project's own visual regression suite -- had never rendered anything narrower than iPad width (1180px), and had never once captured the Tasking & Clinical Guidance dialog at any width, despite it being one of the most content-heavy parts of the app. Both gaps meant this exact class of bug was structurally invisible to the existing regression suite, regardless of how carefully any single release was reviewed. Added a `phone` profile (390x844, matching the reported device) and a guidance-dialog capture alongside the existing dialog screenshots. The baseline grew from 34 screenshots (17 screens x 2 profiles) to 54 (18 screens x 3 profiles); regenerated and confirmed stable (two consecutive runs match exactly, aside from normal anti-aliasing noise).

### Verification

98 static, 43 jsdom runtime and 147 Chromium checks all pass. ESLint clean across all 75 app script blocks; CSS has no parse errors, invalid declarations, or dead rules. 25-cycle soak test showed no growth in DOM size, timers, or listeners, zero page errors. Visual regression against the unmodified v5.51 baseline: all 34 of the previously-existing screens match exactly (confirming desktop and iPad are untouched); the new phone and guidance-dialog screens were then baselined fresh, since no prior version had ever captured them to compare against.

## v5.51 - 2026-09-24 - Final production audit before live use

Independent production-readiness review of the v5.50 handover, treated as a
professional pre-release code review rather than a re-read of the changelog.

**What was run, not assumed.** The v5.47 notes record that only the
dependency-free static audit ran in that environment, so all three suites were
re-run here on the package exactly as delivered: 98 static, 43 jsdom and 147
Chromium checks, all passing before any change. Beyond the bundled suites:
ESLint over all 75 application script blocks (0 findings); CSS parse and
declaration validation (0 errors); an always-overridden-declaration scan (0);
a security-pattern scan (no live `eval`/`new Function`, `document.write`,
`debugger`, `console.log` or plaintext `http://`); tag-balance and structure
checks across the whole Tasking & Clinical Guidance template (balanced; 7
categories matching 7 tab buttons; 96 sections; the only duplicate section
number is the source PDF's own 4.14); and a soak test.

**Findings that turned out not to be defects**, recorded so they are not
re-investigated: 49 of the 96 guidance sections carry no `id` in markup, but
the renderer assigns `tg-section-N` ids at runtime, so every section remains
navigable. The single "TODO"-style hit is the literal `ZK-XXX` in a comment.
Two style classes a static scan reports as dead, `.tg-rule-skill` and
`.tg-rule-hospital`, are built at runtime (`'tg-rule-'+kind`) and colour every
time-saving badge. Deleting them would have silently stripped that colour
coding, which is exactly the class of mistake that removed a live style at
v5.21. They now carry an explanatory comment.

**Changed.** The genuinely dead `.tg-source-copy` rule was removed (its markup
went at v5.44). The v5.50 road-route retry was reviewed line by line: bounded
(80 x 250 ms), single timer cleared before every reschedule, and properly
cancelled when a scene is cleared, so no stale route can reappear. One gap:
the retry counter reset only on a *successful* draw, so a new route could
inherit an exhausted budget from a previous one. It now resets whenever a
different polyline arrives. A reproduction with a never-ready map followed by
a new route showed v5.50 already recovered via another redraw path, so this is
recorded as hardening, not a fixed user-facing fault.

**Documentation.** README, ARCHITECTURE, CHANGELOG and this file were
checked against the package, not against each other: 31 namespaces, 7
providers, 20 reference data modules and 3,693 protected ids across 8 dataset
entries all confirmed at runtime or from the baseline. The README's guidance
update route, category list and coverage statement are current for the
seven-category v2.01 guidance. No further consolidation was needed.

## v5.50 - 2026-09-24 - Final route reliability and map contrast

This release closes the last observed Primary map issue before live handover.
The scope is deliberately narrow: the scene-to-hospital road route, its visual
contrast, and regression coverage.

### Corrections

- The road-following Google Routes polyline now renders in teal (`#008a8f`)
  with the existing white halo. The previous ochre/brown treatment could be
  mistaken for the base map's road styling. The direct operational
  scene/LZ-to-hospital line remains blue and dashed, so the two meanings stay
  distinct.
- An unchanged scene search no longer becomes a dead end after a transient
  Routes API failure. Pressing Enter again reuses the existing coordinate,
  avoids another geocoding request, and explicitly refreshes the response
  calculation so the road route can be fetched again. This refresh is targeted
  at the calculation module rather than broadcasting a new scene, preserving
  deliberate manual base/hospital selections and breakdown overrides. The same
  recovery applies when an unchanged coordinate pair is entered directly.
- Route drawing now has a bounded map-style readiness retry. The fetched encoded
  polyline and decoded geometry are retained, and drawing is retried every
  250 ms for up to 80 attempts (20 seconds) if the map or style is not ready.
  The existing `style.load` redraw remains, and clearing/resetting the route also
  clears the retry timer. This prevents a successful Routes response from being
  visually lost during a map-style transition.

### Production audit

- Added dependency-free static assertions covering the route colour, targeted
  same-scene retry, direct-coordinate retry and bounded style-readiness redraw.
  The final source passes all 98 static production checks.
- Ran targeted Chromium runtime tests with the Google endpoints mocked. A first
  Routes response was forced to fail, producing the documented estimate fallback;
  pressing Enter again on the same address made a second Routes call without a
  second geocode and replaced the estimate with the real result. The same direct-
  coordinate recovery path also passed.
- Exercised `drawRoadRoute()` against a delayed mock map style. It registered its
  style-load listener, retained the fetched geometry and, once the style became
  ready, created the route with `#008a8f`, 4 px width and the white halo.
- Loaded the final shell in Chromium at 1440x900, 1180x820 and 820x1180. Primary
  rendered at all three sizes with no page-level horizontal overflow. External
  services were intentionally blocked in these isolated browser checks.
- `sw.js` and every packaged `.mjs` file pass `node --check`; application CSS
  parses with zero errors; the protected-dataset JSON and `netlify.toml` parse
  successfully. The official Node jsdom/Playwright suite was not re-run because
  a fresh `npm ci` could not complete in this execution environment. The targeted
  Chromium checks above cover the runtime code changed in v5.50; the deployed
  workstation/iPad smoke test remains the final environment gate.
- No changes were made to operational timing/calculation policy, approved data,
  Tasking & Clinical Guidance wording, Firebase paths, storage/privacy keys,
  Google endpoints, or the established form workflows.

## v5.49 - 2026-09-24 - Digital & Data handover review

This release is the final handover pass over the production package as if it were
being accepted by an internal software team. Application runtime behaviour is
unchanged from v5.48. The review concentrated on maintainability, deployment
readiness, stale documentation, ownership boundaries and whether any further
code cleanup would reduce risk rather than merely change style.

### Outcome

- The single-file architecture remains intentional and maintainable for the
  established ZIP-to-Netlify workflow. Module ownership, canonical update routes,
  dataset id protection and regression tooling provide clear maintenance boundaries.
- No dead-code, patch-layer or duplicate-ownership cleanup was identified that
  justified changing operational runtime code at handover.
- README handover material was condensed so resolved historical decisions no longer
  read like current blockers. The remaining production sign-off items are explicit:
  Google key restrictions, Firebase rules, deployed workstation/iPad smoke testing,
  and formal ownership/support transfer if Digital & Data accepts the application.
- NOTICE no longer refers to GitHub or a repository, matching the actual versioned-ZIP
  release workflow.
- Historical CHANGELOG and RELEASE-NOTES remain intentionally preserved as audit
  history. They are not the current operating instructions, which live in README,
  ARCHITECTURE and the source header.

### Deployment gate

The code package can be promoted once the external console controls are evidenced
and the deployed smoke test passes. Those controls cannot be proven from the ZIP
itself and should not be represented as code defects.

## v5.48 - 2026-09-24 - Final production audit

This is the final production-readiness audit built from v5.47. No operator
workflow, visual layout, operational calculation, approved dataset, clinical or
Tasking Guidelines wording, Firebase path, storage key, privacy behaviour, map
behaviour or provider endpoint was changed. The only operator-visible release
change is the version identity moving to v5.48.

### Audit and tidy-up

- Re-ran the dependency-free structural audit across the source-of-truth HTML,
  deployment configuration, service worker, protected datasets, Tasking &
  Clinical Guidance manifest, version identity, CSP coverage and API-key
  accounting.
- Re-parsed the application stylesheet independently with `tinycss2`. It has
  zero CSS parse errors, zero exact duplicate same-context rules, and only the
  two documented progressive-fallback duplicate properties (`html,body` height
  and `.dialog` max-height). No stylesheet cleanup was justified.
- Reviewed app-owned JavaScript for debug residue, TODO/FIXME markers, native
  alerts, executable `eval`/`new Function`, duplicated maintained operational
  constants and unreferenced named functions. No new dead code or patch layer
  was found. Existing local distance helpers are one-line delegates to the
  canonical `AirDesk.util.haversineKm`, not duplicate formula ownership.
- Tidied maintainer-only wording: obsolete `AirDesk Next` labels were removed
  from the Netlify and service-worker comments, and the audit helper's stale CSP
  report-only example was replaced with a current generic non-blocking-review
  description. Runtime code is unchanged.
- Added one low-risk maintenance guard to `tools/check.mjs`: README,
  ARCHITECTURE, CHANGELOG and RELEASE-NOTES must now identify the same current
  release as `APP.version`. This prevents handover documentation being left one
  edition behind during a future version bump.
- Standardised the handover install instruction on `npm ci` so the verification
  toolchain uses the versions pinned by `package-lock.json`.

### Verification

- The final v5.48 package passes all 95 checks in the dependency-free static suite,
  including the new documentation-version guard.
- `sw.js` and every packaged `.mjs` tool pass `node --check`;
  `tools/dataset-baseline.json` and `netlify.toml` parse successfully.
- The ZIP is checked for a single correctly named root folder, exactly one
  versioned application HTML file, no `node_modules`, and compressed-data
  integrity before handover.
- A fresh jsdom/Node Playwright run could not be completed in this execution
  environment because dependency installation did not complete. A separate
  Chromium fallback was also blocked from navigating to local content by the
  environment's browser policy. This is recorded rather than represented as a
  fresh runtime pass. The full visual pass was completed on v5.47 immediately
  before this audit, and v5.48 changes no presentation or operational runtime
  logic.

## v5.47 — 2026-09-24 — Final handover consolidation

This is a maintenance-only release built from v5.46. The application behaviour
and approved operational content are unchanged. The work completes the
documentation/code-review pass that was in progress: remove stale duplication,
reconcile current package figures, and decide whether any further consolidation
would materially improve maintainability.

### What changed

- `README.md` now has one authoritative **Tasking & Clinical Guidance update
  route** instead of two overlapping sections. It keeps the useful rule that a
  replacement guideline PDF must also be checked for changes owned by other
  modules such as SAR, hospital/reference data, CAD quick-reference material or
  operational timing rules.
- Stale handover figures were corrected to the current package: eight dataset
  baseline entries protecting 3,693 feature ids, and a CSP with 15 external
  `connect-src` entries plus `self`. The static audit currently discovers 11
  fetched origins and verifies that all are covered.
- `ARCHITECTURE.md` was reworked so the file-size split and structural review
  describe the current build without relying on low-value counts that quickly
  become stale. The durable warning remains: stylesheet duplication, generated
  inline styles and best-effort `catch` blocks are not candidates for bulk
  cleanup without component-level regression evidence.
- The in-file maintenance header now carries the same cross-module guidance-PDF
  review rule, so the source-of-truth HTML remains sufficient even when the ZIP
  documentation is not beside it.
- `APP.buildDate` was reconciled to 2026-09-24 and `tools/check.mjs` now requires
  it to match the file-header build date. This turns another previously manual
  release-identity detail into a mechanical version-bump safeguard.

### Consolidation decision

No further broad code consolidation was applied. `tools/check.mjs`,
`tools/verify.mjs`, `tools/browser-check.mjs` and `tools/visual-check.mjs` test
different failure classes and already share the common filename/reporting logic
through `tools/lib.mjs`. Merging them would reduce separation of concerns more
than it would reduce maintenance. The application itself already passes named
function reachability checks and has clear module ownership, so a large
"condense the code" pass would create unnecessary regression risk in a finished
operational tool. Future refactors should stay local to a component that is
already being changed.

### Verification

- **94/94 dependency-free static checks passed** on `AirDesk-v5.47.html`,
  including script parsing, markup/comment balance, function reachability,
  version/deployment agreement, protected dataset ids, guidance structure and
  source metadata, CSP coverage, service-worker safeguards and API-key
  accounting.
- No application CSS, operational calculations, approved datasets, clinical or
  tasking wording, Firebase paths, storage keys or provider endpoints were
  changed, so a visual baseline was not regenerated for this release.
- The jsdom/Playwright dependencies could not be freshly installed in this
  execution environment within the available package-install window. As with
  v5.46, the suites remain packaged for local execution before deployment; this
  limitation is recorded rather than represented as a fresh pass.

## v5.46 — 2026-09-24 — Area Specific Considerations completed

This release closes the one substantial Tasking Guidelines content gap left
explicitly open by v5.45. The supplied **National Air Desk Tasking & Operating
Guidelines, version 2.01** was used as the source. Section 5.0-5.14, pages
51-61, is now included in the existing Tasking & Clinical Guidance viewer as
a seventh category, **Area Specific Guidance**. The source PDF and its pinned
SHA-256 are unchanged; only the module's declared coverage expands.

The new category preserves the issued location-specific guidance for Auckland;
the Hauraki Gulf, Waiheke, Kawau and Great Barrier Islands; Coromandel and
Cathedral Cove; Matakana Island; Taranaki Oil & Gas operations; Tairāwhiti;
Picton and Marlborough Sounds; Aoraki/Mt Cook; Otago; Fiordland; Rakiura
Stewart Island; the Chatham Islands; the Sub Antarctic Islands; and Ski-fields.
The Ski Field Information table was checked against the source page image as
well as extracted text because it is multi-column source material.

The content was added to the same inert `#airdesk-tasking-clinical-guidance-
content` template used by every other guidance category. No contextual copy was
created elsewhere in the app. Search, category navigation and source metadata
therefore continue to operate through the existing generic renderer. The
template-level source pages/sections, Source Details panel, and all three
independent regression suites were updated together.

No operational calculation, mapping dataset, Heli Status behaviour, Firebase
path, storage key, provider endpoint or existing guideline section was changed.
The remaining guideline material intentionally not restated in this viewer is
owned by other application workflows: section 10 by the calculation engine,
most of section 17 by CAD procedures, and section 20 by external application
usage.

### Verification

- **93/93 dependency-free structural checks passed** against the final v5.46
  HTML, including JavaScript parsing, HTML/tag balance, unique ids, function
  reachability, Heli Status invariants, maintained timing/default routes,
  protected dataset ids, Netlify/version agreement, CSP/API-key accounting,
  service-worker safeguards, and the expanded guidance source manifest.
- The new Area Specific category was rendered in system Chromium at desktop,
  iPad landscape and iPad portrait sizes. All three showed seven categories,
  all 17 location sections, working cross-category search, zero page-script
  errors and no unintended shell/dialog horizontal overflow. The two Ski Field
  tables render all 21 issued rows without overflowing their section.
- The Ski Field Information source table was checked against the rendered PDF
  page as well as extracted text. The Area Specific source text was taken only
  from pages 51-61 of the supplied approved v2.01 PDF.
- A fresh `npm ci` was attempted so the packaged jsdom and Node Playwright
  suites could be rerun, but dependency installation timed out in this
  execution environment. Those suites remain updated and packaged; this note
  records the limitation rather than representing them as freshly executed.

## v5.45 — 2026-09-23 — Six categories, grouped by purpose not by section adjacency

Follow-up to v5.44: the desk found 11 categories still overwhelming and asked for "5 or 6, or the smallest number possible whilst making it clear and simple." Rather than mechanically merge whatever was still adjacent, each of the 11 was reconsidered from the operator's perspective -- what question is this category actually answering -- and regrouped around five distinct answers, plus Clinical Conditions kept deliberately alone.

### Why Clinical Conditions was not merged into anything

It is the single largest category (29 sections) and, by every signal available (its position first in the original v5.31 build, its size relative to everything else), the most frequently opened. Folding anything else into it -- ANTS, Specific Skills, or any other candidate -- would have made the busiest category longer to scroll through, which works against the same "clear and simple" goal a merge exists to serve. A consolidation that reduces the tab count but makes the most-used tab worse is not actually progress. It stays exactly as it was at v5.31.

### The five other categories

**ANTS Criteria & Specific Skills** (3.0-3.5, 4.29): the decision framework and what "skill" means within it -- these were already adjacent in the source's own logic (4.29 elaborates the "S" in ANTS), just not adjacent in section numbering.

**Tasking, Landing & Destinations** (6.0-6.1, 9.0-9.6, 11.0-11.2, 17.9-17.9.1): everything about executing a tasking once the decision is made -- the four tasking methods, where to land, which hospital, and the callsign/airframe-change process that goes with actually doing it.

**Escalation, Coordination & Major Incidents** (13.0-14.0, 15.0-16.4, 18.0-18.1, 19.0-19.2): what happens when an incident gets bigger or more complex than a routine tasking -- CIMS, the Police/RCCNZ SAR authority split, Ambulance Centre coordination, clinical escalation and review, and major/mass-casualty incidents. This absorbs the v5.44 "Escalation & Coordination" merge (itself already combining Coordination Frameworks into Escalation & Review) plus Major Incidents, giving it a four-part non-contiguous range -- the most fragmented single category in the module, but every part of it answers the same underlying question.

**Other Agencies & RCCNZ Advice** (7.0-8.0, 12.0-12.3, 21.0): who else the CSO-AD works with directly -- requesting a fixed-wing or RRV, tasking for Police/RCCNZ/NEMA/FENZ, inter-hospital and inter-facility transfers, and RCCNZ's own clinical-advice line.

**Principles & Definitions** (1.0-1.2, 2.0-2.2): unchanged from v5.44's merge.

### Mechanics: extracting from categories that were themselves already merges

Four of the nine categories folded into these five (`landing`, `callsigns`, `major`, `rccnz`, `otheragency`) were straightforward single-purpose categories from v5.43. But `ants` and `tasking` needed their sections extracted and re-spliced in a new order (ANTS's own three-way-expanded 3.1/3.1.1/3.1.2/3.1.3 structure from v5.44 had to move as one intact unit), and `escalation` was already a merge from v5.44 (`coordination` folded into `escalation`) that now needed `major` appended to it -- extracting sections from an already-merged category and confirming the extraction still produced the exact right section list, rather than assuming a smaller, single-purpose category would be simpler to work with every time.

Each merge used the same mechanical process as v5.44: extract a donor category's `<section>` elements by matched-depth div parsing (not a naive string match, since nested `<div>` elements inside a section would break a simple search-for-closing-tag approach), repoint `data-tg-category-section` to the new target id, splice into the target's content in the chosen reading order, then delete the donor's now-empty wrapper `<div>` and tab `<button>` entirely.

### The mistake this release caught, that v5.44 also made

Both v5.44 and v5.45 had to fix the same category of bug: a category merge that changes or removes a category id, but where one of the several places that id is referenced doesn't get updated. At v5.44 this was a `JSON.stringify` key-order mismatch. At v5.45, after the first full round of edits produced a clean `npm run check` pass, `npm run verify` failed three checks -- not because the merge was wrong, but because two checks left over from *before* the v5.44 merge (clicking `data-tg-category-button="skills"` and `="ants"`, and checking `data-tg-category="skills"` was hidden as the definition of "Clinical Conditions is the default category") had survived the v5.44 edit entirely unnoticed, because v5.44's own new checks happened to test adjacent, still-passing things. `npm run check`'s static source-parsing did not catch this, because `data-tg-category-button="skills"` is a syntactically valid selector whether or not any element in the page still has that attribute -- it does not fail to parse, it fails to find anything at runtime, which only `verify.mjs` and `browser-check.mjs` can catch.

The fix: grep all three test files for every category id being removed or renamed, immediately after making the template change and before trusting a clean `check.mjs` pass as evidence the merge is complete. This is now written into the README's guidance-update documentation directly, since it is exactly the kind of mistake likely to recur on the next category change if only "run the suite once" is the standing instruction.

### Verification

Tag-balance confirmed across the full template after all nine categories were removed and five rebuilt. ESLint clean across all 75 app script blocks; CSS validity unchanged (no new parse errors, invalid declarations, or always-overridden rules -- expected, since no CSS was touched this release). Security scan unchanged from every prior audit. 25-cycle soak test held DOM size, interval count and listener count constant, zero page errors. Visual regression against the unmodified v5.44 baseline: all 34 screens match exactly -- the standard screenshot set opens the default Clinical Conditions category, which did not change, so this confirms nothing outside the guidance dialog's own category structure moved.

Verification: 91 static, 42 jsdom runtime and 144 Chromium checks all pass (down from 96, 46 and 156 at v5.44 -- fewer categories means fewer per-category click-through and sequence assertions, covering the same underlying sections in fewer, more thorough checks rather than testing less).

## v5.44 — 2026-09-23 — Fixing a raw-text section, consolidating categories, two UI requests

Desk feedback on three screenshots: the guidance tab strip had become overwhelming (11 categories added at v5.43, one of which was itself already a merge, pushed the total from 10 to 15), the search bar looked narrow inside the dialog, and the "Access Criteria Guidance" section's layout looked visibly broken. A fourth, unrelated request: a draggable divider between the fleet table and the map/Windy pane on Board View when only one of them is showing.

### The Access Criteria Guidance bug was real, and predates this session's own additions

Section 3.1 (Access Criteria Guidance) rendered as a single collapsed `<details>` box containing roughly 2,500 words of plain, unformatted text -- literal bullet characters and newlines with no `<ul>`, `<table>`, or heading markup, so the browser's default text flow collapsed everything into a run-on paragraph. Worse, subsections 3.1.1 (When Urgent Search and/or Rescue is Required), 3.1.2 (Marine Incidents) and 3.1.3 (Land Incidents) did not exist as their own `data-tg-section` elements at all -- they were plain text inside 3.1's box, invisible to the "In this category" navigator and unreachable by precise search, even though the category's own section count already implied they should be there.

Rebuilt all four as proper sections: bullet lists, `tg-example` callouts, a `tg-keypoint` box, and two genuine checklists (Information for Incidents on Vessels; Information for access incidents) using the same `tg-subsection`/`tg-list` pattern already used elsewhere. While rebuilding the SAROP coordination table inside 3.1, found that the source PDF contains this same conceptual table twice -- once in section 3.1 (page 16), once in section 14.0 (page 90) -- with slightly different wording in the last row (3.1's version: "Close to shore Water Rescue" / "Offshore Water Rescue" plus an extra "All MEDEVACs" entry; 14.0's version: "Close to shore (<12nm)" / "Offshore MEDIVAC", no fifth row). Rather than assume one was more correct and copy it into both places, the page image for 3.1 was rendered and read directly to confirm its own exact wording, then transcribed as its own, independent copy. This is the same category of finding as the duplicate section 4.14 caught at v5.42 -- the issued source has small internal inconsistencies, and the right response is to transcribe each occurrence faithfully where it appears, not to silently reconcile them.

### Fifteen categories back down to eleven

Every category added at v5.43 was reviewed for whether it justified its own tab against the desk's "overwhelming" feedback. None of the content was found to be low-value -- the problem was tab count, not scope -- so nothing was removed, only regrouped: General Principles folded into Definitions & Acronyms (now Principles & Definitions), Hospital Destinations into Landing Sites (now Landing & Hospital Destinations), Other Resource Requests combined with Tasking for Another Agency into one category (now Other Agencies & Resources), and Coordination Frameworks folded into Escalation & Review (now Escalation & Coordination, which already had a non-contiguous range from the coordination merge -- now three-way non-contiguous: `13.0-14.0;15.0-16.4;18.0-18.1`).

Each merge physically relocated the donor's `<section>` elements into the target category's `<div>`, in an order chosen for readability rather than strict source-numbering (Principles' 2.0-2.2 was placed before Definitions' own 1.1-1.2, since operational content reads better before a glossary even though 1.0 precedes 2.0 in the source). `data-tg-category-section` on each moved section was updated to the new category id for anyone reading the source later, even though nothing in the running app actually reads that attribute -- confirmed by searching for it outside the template before relying on that assumption.

This touched `tools/check.mjs`'s `expectedTgCategories`, `expectedTgCategoryMap` and `CATEGORY_ORDER`, and the `seq()` expectation for each of the four merged categories had to list sections in their new DOM order, not source order -- getting this wrong once already, in the opposite direction, at v5.43 (a `JSON.stringify` key-order mismatch) made this easy to get right the second time. The matching assertions in `tools/verify.mjs` and `tools/browser-check.mjs` were updated to click the surviving tab and check for content from both the donor and the target section, rather than two separate tab-click tests. One test-writing mistake caught by actually running the suite rather than assuming the fix was correct: an assertion checked for a `<table>` inside section 3.1.2, which was wrong -- 3.1.2's two checklists are genuinely single-column lists in the source (confirmed from the PDF, not assumed), and the table lives in 3.1. Fixed to check what is actually there.

### Two smaller, independent fixes

**Search bar width.** `.tg-search-row` was capped at 920px and centred, inside a dialog that opens up to 1360px wide -- visible empty margin either side, while the category tab strip above it (no max-width at all) already spanned the full available width. Removed the cap so the two now match exactly (measured: both 1326px in a 1440px-wide test window). The actual guidance text content keeps its own 980px reading-width cap, which exists for line-length readability, not because of the same underlying issue -- that one was left alone.

**Board View divider for single-pane modes.** Split mode already had a working `#board-splitter` handle with a `--board-left` CSS variable driving a resizable grid-template-columns track -- built and working before this release. Plain Map-only and Windy-only modes used a fixed `minmax(0,1fr) minmax(0,1fr)` 50/50 grid with no divider at all. Rather than build a second mechanism, the existing one was extended: both single-pane layouts now use the same three-column `minmax(240px,var(--board-left,50%)) 10px minmax(0,1fr)` grid Split mode's own left column already used, and the one line hiding the handle outside Split mode (`splitEl.hidden = mode !== 'split'`) was changed to always show it. `--board-left` is shared across all three modes rather than tracked separately per mode, matching how Split mode's value was already not persisted across reloads -- a deliberate choice to keep the three modes consistent with each other rather than introduce new asymmetric behaviour. Verified live: dragging in Map mode changes `--board-left` and the measured pane widths correctly, the same value carries into Windy mode when switched, and Split mode's own already-working divider is unaffected.

### Verification

Tag-balance checked across the entire rebuilt template (every `<section>`, `<div>`, `<table>`, `<ul>`, `<li>` etc. opens and closes an equal number of times) before running any test suite. ESLint clean across all 75 app script blocks; CSS unchanged in validity (no parse errors, no invalid declarations, no new always-overridden rules). Security scan unchanged from every prior audit. 25-cycle soak test held DOM size, interval count and listener count constant, zero page errors. Visual regression against the unmodified v5.43 baseline: exactly the four Board View screens the divider affects changed (desktop and iPad, desk and wall), and nothing else -- confirming the category merge and the search-bar width fix, despite touching a great deal of markup, have no effect on any screen outside the guidance dialog itself.

Verification: 96 static, 46 jsdom runtime and 156 Chromium checks all pass (down from 99, 47 and 159 at v5.43 -- fewer categories means fewer per-category assertions, not weaker coverage; the ANTS structural-integrity check and the merged categories' combined content checks are new).

## v5.43 — 2026-09-23 — Five more guidance categories, verified against the source

Following the completeness question raised in v5.42's audit, the desk asked whether anything else from the source guideline should be added. Every section then excluded from the app was read in full: all of it turned out to be genuine operational content, not filler. Five compact, well-bounded sections were added this release, following the guidance-update route documented at v5.42 exactly, as a live test of whether that route was actually usable.

**Added:** General Principles (2.0-2.2 — tasking philosophy, the CSO-AD role, the RAS radio-request acronym, and the audit process for deviating from the guidelines), Hospital Destinations (6.0-6.1 — catchment rules and staging), Other Resource Requests (7.0-8.0 — fixed-wing and RRV requests, short enough to combine into one category), Tasking for Another Agency (12.0-12.3 — Police/RCCNZ/NEMA/FENZ tasking, IHT and IFT rules, a response-colour table with an "ability to delay" column distinct from the one already in Tasking Methods 9.5, and a new Recognised Hospital Facilities table), and Coordination Frameworks (13.0-14.0 and 18.0-18.1, grouped because all three are genuinely about multi-agency coordination even though 18.0 sits 30 pages later in the source — CIMS, the Police/RCCNZ Search and Rescue authority split, and coordination between Road and Air dispatchers).

**Not added, deliberately:** Area Specific Considerations (source section 5) is the one remaining substantial gap — roughly 11 pages across 14 named locations, each with real access and transport guidance. It was read in full and confirmed valuable, same as everything else, but its size warranted its own careful pass rather than being rushed alongside five other additions in a single release. Section 12.2.2's maternity-facilities table is the same table already transcribed under Clinical Conditions at 4.25.1 (confirmed by comparing both); rather than copy it a second time, Tasking for Another Agency names it and points to where it already lives, so the two cannot silently drift apart on a future edit.

### One table confirmed by reading the page, not the text extraction

`pdftotext` garbles multi-column tables in this source PDF — the 12.2.1 Recognised Hospital Facilities table's four regional columns came out interleaved and unreadable as plain text. Rather than guess at the correct column assignment, page 87 was rasterised and read directly as an image, matching the same approach already used successfully for the 4.25.1 maternity table when this module was first built. The table was then generated programmatically from the four column lists (9, 12, 7 and 13 hospitals respectively) rather than hand-typed row by row, to remove the chance of a manual row-alignment slip on a 13-row, 4-column table.

### Two mistakes caught before anything shipped

Both were caught by this session's own verification, not found later — worth recording because they are exactly the kind of thing the guidance-update route now warns about.

**A key-order mismatch.** `check.mjs`'s category-map check compares two objects with `JSON.stringify`, which is sensitive to key insertion order, not just key-value content. The five new categories were inserted into the DOM after `major` and `rccnz` (immediately before `definitions`), but the first attempt at updating `expectedTgCategoryMap` inserted the new entries textually after `escalation` instead — same key-value pairs, different order, and `JSON.stringify` produced different strings. The check's own diagnostic dump (which prints the actual map on failure) showed a map that looked identical to the expected one at a glance, which is precisely why this is worth naming: an order bug can look, to a quick read, like no bug at all. Fixed by matching the expectation's key order to the true DOM order, and the `CATEGORY_ORDER` adjacency map documented in `check.mjs` now has a comment recorded in README pointing future editors at this exact failure mode.

**A collided marker attribute.** The new Recognised Hospital Facilities table was given `data-tg-keep-table="true"`, copying the attribute from the nearby 4.25.1 maternity table without checking what it was for. It turned out to have no CSS or JS behaviour attached at all — its only purpose is to let three separate checks (in check.mjs, verify.mjs and browser-check.mjs) assert `count() === 1` to confirm the maternity table is present exactly once. Adding a second table with the same marker made that count 2 and failed all three checks simultaneously across every browser profile. Removed from the new table, which does not need it.

### Verification

All four places from the v5.42 guidance-update route were updated together: the template's own metadata (`data-source-sections`/`data-source-pages`, extended to the new ranges; SHA-256 unchanged, since this is the same source PDF), the human-readable Source Details panel text, and the matching assertions independently maintained in `tools/check.mjs`, `tools/verify.mjs` and `tools/browser-check.mjs`. Every new category was opened and screenshotted; the response-colour table, the new hospital-facilities table, and the SAR coordination guide table were all visually checked, not only asserted against in code. Search was tested against four new terms ("RCCNZ callsign", "Kaitaia", "staging", "HOTEL callsign") and correctly found matches in the new content. The category tab strip now scrolls horizontally rather than wrapping, consistent with how the existing ten categories already behaved before this release added five more.

25-cycle soak (tab switching, Heli Status, Tasking & Clinical Guidance, Board View) held DOM size, interval count and window/document listener count constant, zero page errors. All 34 `tools/visual-check.mjs` screens pixel-match a baseline taken from the unmodified v5.42 before any change in this release — the standard screenshot set does not open every guidance category, so this confirms nothing outside the guidance module moved, not that the new categories themselves are pixel-correct; that was confirmed separately, by eye, for each one.

Verification: 99 static, 47 jsdom runtime and 159 Chromium checks all pass (up from 88, 42 and 144 — the difference is the new category-sequence and content-fidelity assertions this release added, one set per new category, in all three files).

## v5.42 — 2026-09-23 — External audit: map-data safety net and the missing guidance-update route

Independent review of v5.41, requested to confirm the recent changes were correct and that the tasking guidelines and mapping layers specifically are maintainable going forward. The user supplied the actual source PDF for the Tasking & Operating Guidelines; its SHA-256 matches the fingerprint already pinned in the app exactly, confirming it is the same document the guidance module was built from, not a newer edition. That let several things be checked against ground truth rather than only for internal consistency.

Two real gaps were found in what "maintainable" actually requires here, both fixed. Nothing else in the app changed — no clinical or tasking content, no calculations, no Firebase paths, no storage keys, no map data beyond the id assignments described below.

### Map data: closing the id-retention safety net

The map update contract states plainly that a feature which survives an approved re-import keeps its existing `properties.id`, and that `tools/dataset-baseline.json` exists specifically to catch a silent violation of that rule. Two things undermined it in practice.

**18 features had no id at all.** The 12NM Territorial Sea Limit line and all 17 Major Trauma 40km road-distance rings — pre-existing features, not part of the v5.41 import — carried only `name`, `category` and `note`. A feature with no id can never be protected by an id-retention check; it would simply not appear in the tracked set, in either direction. All 18 now have a stable id (`twelve-nm-limit`, `trauma-ring-christchurch`, and so on for each of the 17 rings), generated from the existing name following the same convention already used elsewhere in this dataset (`adg-N`), with the id placed first in each feature's `properties` object to match. Names, coordinates, notes and rendering are otherwise untouched, and the total feature count is unchanged at 274.

**The baseline conflated two unrelated datasets.** `#airdesk-aviation-guidance` is one script block holding two separately-registered layers with their own `dataVersion` strings: `IFR_DATA` (405 features — waypoints and named airways, ported from a reference app and not part of the ongoing map-update workflow) and `GUIDANCE_DATA` (274 features — the actively-maintained Air Desk Guidance layer this session's import touched). `tools/dataset-baseline.mjs` and the matching logic in `tools/check.mjs` baselined the whole script block as one id space of 679, because both tools keyed off the `<script id="...">` attribute rather than the logically distinct dataset each constant represents.

This matters because the check's protection is a 90% retention floor: below that, the id space is judged replaced rather than edited, and above it, only a non-blocking diff note is shown. Combined, a large loss confined entirely to the 274-feature Guidance set could still clear 90% retention on the strength of the untouched 405-feature IFR set sitting alongside it in the same bucket — the exact scenario the floor exists to catch, hidden by an unrelated dataset's bulk. This was not a hypothetical: simulating a 60-id (22%) loss confined to `GUIDANCE_DATA` showed the old combined accounting would have kept the combined pool at 90.9% retained, at or above the floor, while the same loss viewed on its own dataset is 78% retained — a clear failure. `tools/dataset-baseline.mjs` and `tools/check.mjs` now resolve `ifr-routes` and `air-desk-guidance` to their own `const` inside the shared script block and baseline, check and diff each independently. Verified live: the simulated 60-id loss now correctly fails `dataset ids retained across 8 datasets` (78%, "the id space was replaced, not edited") and is fully restored to a clean pass once the corruption is reverted. The baseline was regenerated after both fixes: 8 tracked datasets instead of 7, `air-desk-guidance` now showing 274/274 ids where it previously showed 256/274.

### Guidance content: the missing update route, and what the source PDF confirmed

The v5.40 changelog claimed the maintenance contract had been expanded to cover "three recurring update paths: mapping/reference-data replacement, whole Tasking Guidelines replacement, and operational timing/default changes." Only two of the three existed anywhere in the header comment or README — mapping and timing both have a named, worked-through section; guidance replacement had none. Given the desk's stated workflow is exactly this — upload a new approved PDF, have an AI or maintainer bring the app up to date from it, as one source of truth — this was the more consequential of the two gaps, not a paperwork omission.

Both the header (`GUIDANCE UPDATE ROUTE`) and README (`### Guidance update route`) now document the four places a whole-document replacement touches: the template's own pinned metadata (version, dates, section/page ranges, SHA-256 — computed fresh from the replacement PDF, since a stale fingerprint silently defeats every check that compares against it rather than against the file), the core document catalogue's `tasking-guidelines` entry, the guidance-specific assertions in `tools/check.mjs`, and the further, independently-written copies of those same assertions in `tools/verify.mjs` and `tools/browser-check.mjs` — three files, none generated from the others, each capable of drifting out of agreement with what the template actually contains if only one or two are updated.

Having the actual source PDF (not just its recorded fingerprint) allowed two things this session had previously had to leave as open questions to be checked directly:

- **The duplicate section 4.14** ("Trauma - Burns" and "Non-Traumatic Haemorrhage") is confirmed present in the source's own table of contents and in the body text on page 39 — the issuing authority's numbering, not a transcription slip introduced anywhere in this app. It is documented as such in both the header and README, with an explicit instruction not to renumber it without the issuing authority doing so first. It causes no functional fault: `tools/check.mjs` already scopes its structural sequence checks to explicit category windows for exactly this reason, and navigation/search key off each `<section>`'s unique `id`, never the visible number.
- **Two of the four v5.38 additions were spot-checked word-for-word against the source**: section 11.0 Landing Sites (all eleven source bullets accounted for, one sensibly promoted to a highlighted callout, the Landing Site Definitions table intact) and section 21.0 RCCNZ Clinical Advice (complete, including the closing sentence about Maritime Rule 50 and Yachting NZ Safety Regulations, correctly reformatted into two visually distinct urgent/non-urgent callouts without losing any content). Both fully faithful.

**What the module does not cover**, written into README for the desk to confirm rather than assumed here: the source PDF has 21 numbered top-level sections; 10 map onto the app's 10 categories. Excluded are General Principles (2), Area Specific Considerations (5), hospital-destination and other-resource-request sections (6-8), Estimation of Time Savings (10 — implemented as the app's own calculators rather than restated as reference text), tasking-for-other-agencies/CIMS/SAR-operations (12-14), most of the CAD-system section (17.0-17.8, 17.9.2 onward), and two sections that were not reached in detail (18, 20). This was a deliberate scope decision made when the module was built, not something discovered as an oversight here — but "one source of truth" could reasonably be read as covering more of the document than it currently does, so it is worth the desk actively confirming the scope is still right rather than assuming it.

### Also independently re-verified, not only re-read from earlier changelogs

The v5.40 aviation-rules consolidation has no remaining duplicate `kmToNm` literal (`grep` for the literal value across the whole file returns exactly one hit, the canonical `AirDesk.rules.aviation` definition). The document catalogue's `tasking-guidelines` entry reads `versionLabel: 'v2.01 · 15 May 2026'` / `reviewedDate: '2026-05-15'`, matching the v5.40 claim exactly. The v5.39 Winch display change was checked visually in both live and Edit views: live correctly shows only active Land/Wets/Decks chips per period with an explicit "No Winch" badge where a period has none, while Edit mode keeps all six toggles including dashed inactive states, exactly as described. The v5.37 pool-base typed-callsign fix (Auckland, Whangarei, Christchurch, Dunedin, Queenstown, Nelson) was re-tested live and still holds after the intervening releases.

One thing caught only by the existing version-agreement check, not by hand: this release's own version bump initially missed the static `id="build-version"` chip text (a hard-coded fallback shown before the JS override at boot sets it from `APP.version`) and `package-lock.json`'s version field. Both are fixed; the check's own comment already recorded that exactly this drift shipped once before, at v5.0.

### Audit coverage

ESLint: 0 findings across all 75 app script blocks. CSS: 0 parse errors, 0 invalid declarations, 0 always-overridden rules across 1,846 rules. Security scan unchanged from prior audits: no eval/new Function beyond the comment recording its own past removal, no document.write, no debugger statements, no plaintext http:// URLs, no window.open without noopener; the one target="_blank" without an explicit rel is inside the bundled MapLibre library. 25-cycle soak (tab switching, Heli Status, Tasking & Clinical Guidance, Board View) held DOM size, interval count and window/document listener count constant, zero page errors. All 34 `tools/visual-check.mjs` screens pixel-match a baseline taken from the unmodified v5.41 before any change in this release — confirming the id assignments, baseline-tooling split, and documentation additions have no visible effect on anything rendered.

Verification: 88 static, 42 jsdom runtime and 144 Chromium checks all pass.

## v5.41 — 2026-09-23 — Approved MapIT operational-point import and final production audit

This release makes one scoped operational mapping update, then re-audits the complete production package. The user confirmed that Airstrips and Jet A1 fuel are not used in this workflow, that only the existing 40 km road-distance Major Trauma rings are wanted, and that Rafting Evac Sites, Makara Peak Evac Sites and Taranaki Basin Oil Rigs belong inside the existing **Air Desk Guidance** layer rather than as additional map controls.

### Mapping update

The canonical `GUIDANCE_DATA` in `#airdesk-aviation-guidance` now contains 274 features. The previous 238-feature dataset is unchanged in-place and receives 36 approved MapIT points: 11 from `8C. Rafting Evac Sites.kmz`, 16 from `8D. Makara Peak Evac Sites.kmz`, and 9 from `8F. Taranaki Basin Oil Rigs.kmz`. These points use stable source-specific ids (`adg-rafting-*`, `adg-makara-*`, `adg-oil-*`) and carry their source-layer provenance. They render through the existing Air Desk Guidance source, styling, popup and visibility toggle, so no duplicate FeatureCollection, late patch script or extra layer control was introduced.

The existing 17 features categorised `Major Trauma 40km Ring` remain the only trauma rings in Air Desk Guidance. The MapIT backup's separate 40-minute trial rings were deliberately excluded. Airstrips and Jet A1 fuel were also deliberately not imported.

### Maintainability

The Air Desk Guidance manifest now names the selected MapIT 8C/8D/8F source files and the explicit 40 km road-distance-only trauma-ring rule. The static audit checks the three imported group counts, their stable ids, the 17-ring count, and the absence of 40-minute trial-ring data. The approved dataset baseline was regenerated only after confirming the 36-feature addition, preserving all prior ids. `tools/dataset-baseline.mjs` now stamps the current app version and generation date automatically for future approved imports.

### Scope protection

No Tasking & Clinical Guidance content or source metadata changed. No operational timing/default values changed. No response calculations, Firebase paths, storage keys, Heli Status/Board View behaviour, provider endpoints, service-worker policy, LZ/hospital/pathway datasets or external integration behaviour changed.

### Final verification

- 88/88 dependency-free structural checks pass with the approved v5.41 dataset baseline.
- The exact HTML assembles in system Chromium at desktop (1440×900), iPad landscape (1180×820), iPad portrait (820×1180) and Citrix-sized (1280×720) profiles with valid configuration, no missing core namespaces, no unintended page overflow and no page-script errors.
- All ten Tasking & Clinical Guidance categories and cross-category search remain operational; its inert source template is byte-identical to v5.40.
- Heli Status live/edit Winch rendering and the full additional-aircraft → callsign → tail → type → map-identity → Done workflow pass directly.
- CSS parses with zero errors. The only two duplicate CSS declarations are the intentional `dvh`/`min()` compatibility fallbacks already documented by the project.
- Diff audit shows only `#airdesk-core-config` (version/data manifest) and `#airdesk-aviation-guidance` changed among application script modules. The original 238 Air Desk Guidance features are byte-for-byte identical to v5.40 and the 36 approved MapIT points are appended with source-specific ids.
- The packaged npm/jsdom verifier could not be rerun in this environment because dependency installation timed out and left an incomplete jsdom package. The incomplete `node_modules` directory was removed and is not included in the release. Direct system-Chromium validation above was completed independently of that package.

# V5.40 FINAL PRODUCTION READINESS AUDIT

**Date:** 23 September 2026

This release is the final maintenance and handover audit requested before live deployment. It deliberately avoids feature churn. The application was reviewed for structure, duplicate logic, maintenance traps, stale metadata, fallback calculations, mapping update routes, Tasking Guidelines ownership, Heli Status behaviour, deployment configuration, service-worker update behaviour, CSS integrity and responsive browser assembly.

## Code consolidation completed

The audit found a small number of remaining fallback literals that duplicated maintained operational values. These were not separate workflows, but they were a future drift risk because a later timing update could change the main calculation while leaving a fallback path behind. They are now resolved from `AirDesk.rules` in `#airdesk-core-config`:

- km-to-NM conversion now has one maintained literal.
- default daytime takeoff allowance is read by Primary, IHT, SAR and live-aircraft fallback paths rather than repeated as `10`.
- live-aircraft cruise fallback reads the maintained NM/minute rule.
- the airborne fallback threshold reads `rules.aircraft.airborneKnots`.

No calculation formula or approved timing value was changed. Representative checks still return 10 minutes day, 15 minutes standard night, 20 minutes Dunedin/Queenstown night, 35 minutes Te Anau day/night, and the existing 120-knot cruise conversion. Hospital-specific `helipadToEDMin` remains owned by the canonical hospital records rather than being copied into the global rules object.

The Tasking Guidelines document entry in the core registry also had stale legacy metadata (`Embedded v4.4 baseline`). The actual embedded guidance source has been v2.01 since the guidance rebuild. The registry now states `v2.01 · 15 May 2026` and `reviewedDate: 2026-05-15`, matching the maintained guidance source. The inert Tasking & Clinical Guidance template itself is byte-identical to v5.39.

## Maintenance paths hardened

The in-file maintenance contract and README now make the three recurring update routes explicit:

1. **Mapping/reference data:** replace the canonical dataset in its owning module, preserve surviving feature ids, inspect the dataset-baseline diff, and never layer a second FeatureCollection or late override over stale data. The documented routes cover aerodromes/LZs, aviation guidance, clinical pathways, hospitals, HEMS bases, maternity/medical centres, emergency resources, Marlborough jetties and huts/campsites.
2. **Tasking & Clinical Guidance:** use the complete approved Tasking & Operating Guidelines PDF as the maintenance input, update only the single inert guidance template and its version/date/page/section/hash manifest, preserve issued wording/numbering, and separately review any changed guideline sections owned elsewhere in the application.
3. **Operational timing/defaults:** update `AirDesk.rules` once for shared aviation/road/response defaults, or the owning hospital record for hospital-specific transfer time, then rerun representative Primary, IHT and SAR calculations. Do not compensate with downstream formula edits or patch scripts.

New static checks make these conventions executable rather than relying only on documentation.

## Production audit results

- **82/82 dependency-free structural checks passed.** This includes JavaScript parsing, HTML/comment/tag integrity, unique ids, named-function reachability, Heli Status stability/additional-aircraft invariants, single-source timing fallbacks, mapping update documentation, guideline source metadata and coverage, dataset-id baselines, version/package/deployment consistency, CSP/API-key accounting and service-worker safeguards.
- **Browser assembly:** the exact v5.40 HTML was loaded into system Chromium with external providers blocked at desktop (1440×900), iPad landscape (1180×820), iPad portrait (820×1180) and Citrix-sized (1280×720) profiles. Configuration was valid with no missing core/Primary/IHT/SAR/map namespaces and no page errors.
- **Tasking & Clinical Guidance:** all ten categories rendered and switched correctly; representative source content from Specific Skills, Landing Sites, Callsign Management, Major Incidents and RCCNZ was present; cross-category search worked; no unintended guidance-shell overflow was found. The guidance template hash is unchanged from v5.39.
- **Heli Status Board:** live Winch renders active capabilities only while retaining explicit Day/Night empty-period `No Winch`; Edit mode retains six controls; targeted additional-aircraft testing confirmed add -> callsign -> canonical tail -> aircraft type -> map callsign lookup -> Done persistence.
- **Responsive Heli Status:** no Winch-cell clipping at desktop or iPad landscape. iPad portrait retains the intentional horizontally-scrollable table rather than compressing operational columns into unreadable widths.
- **CSS:** both style blocks parse with zero syntax errors. The two same-rule duplicate properties are intentional progressive fallbacks (`height:100%` -> `100dvh`, and `max-height:84vh` -> `min(88dvh,820px)`), not patch residue.
- **Security/code hygiene:** app-owned scripts contain no executable `eval`, `new Function`, `document.write`, `console.log`, `console.debug`, `debugger`, TODO or FIXME markers. The one `new Function` text occurrence is an explanatory comment documenting its earlier removal. The only inline HTML event handler remains the intentional Google Fonts `onload` media switch already allowed by CSP.
- **Package/deployment:** `netlify.toml` points root/index rewrites to `AirDesk-v5.40.html`, blocks maintainer files from public delivery, and keeps HTML/service worker revalidated. `sw.js` remains version-independent, network-first for navigation only, and does not cache live-service responses.

## Verification limitations recorded

The environment allowed direct `set_content` execution in real system Chromium, which is what the browser checks above use. Direct navigation to a local HTTP server is blocked by administrator policy in this environment. An attempt to install the packaged npm dev dependencies also timed out, so `tools/verify.mjs` and the packaged Node Playwright navigation suite are not claimed as freshly rerun for v5.40. This does not change the shipped test tooling; it remains in the ZIP for a maintainer or workstation with npm access.

## Release conclusion

v5.40 is intended as the production baseline. Further refactoring is not recommended without a demonstrated defect or approved source change. In particular, the remaining CSS `!important` declarations are concentrated in intentional dialog/breakpoint competition and should not be stripped globally. Future releases should be limited to genuine defects, operational rule changes, approved dataset/guideline replacements or required features. Provider-console settings such as Google Maps key restrictions and Firebase database rules still require confirmation by the account holder because they cannot be proven from the ZIP.

# V5.39 HELI STATUS BOARD FINAL WINCH PRESENTATION

A focused final presentation pass for the Heli Status Board and Board View. The underlying capability model is unchanged: each aircraft still stores IFR/VFR plus Land, Wets and Decks capability tokens independently for Day and Night. No Firebase path, storage key, callsign/tail mapping, aircraft type, status logic or operational data changed.

The live board previously showed all six Winch positions on every row, using pale dashed placeholders for inactive capabilities. That was useful while editing but made the operational view visually dense. Live surfaces now retain the Day and Night grouping and the existing sun/moon and Land/Wets/Decks SVG language, but render only active capability chips. When a period has no active winch capability it shows a neutral `No Winch` badge. Day and Night are never collapsed together: an aircraft with no winch capability at all therefore reads `Day · No Winch | Night · No Winch`, while an aircraft with day-only capability still states `Night · No Winch` explicitly.

Edit mode intentionally remains the six-position control used in v5.38, including dashed inactive L/W/D buttons, so the operator can add or remove any capability without changing workflow. The same live renderer is shared by Board View, preserving one presentation rule rather than introducing a separate wall-board implementation.

Regression coverage now checks that live Winch has no inactive dashed slots, that a legacy `No Winch` record renders two explicit per-period badges, and that a day-only legacy Winch record labels the empty Night period.

Verification: all 75 dependency-free structural checks pass. The exact v5.39 HTML was also executed in system Chromium using the production renderer with external services deliberately blocked: full Day/Night capability, day-only capability, mixed capability and no-winch cases all rendered as intended; Edit mode retained all six controls; no Winch cell clipped at desktop or iPad-landscape widths; iPad portrait retained the existing intentional horizontally-scrollable table with pinned Status/Base columns; and no inline-script page errors were raised. Both app CSS blocks parse with zero CSS syntax errors. The packaged jsdom verifier was not rerun in this environment because its npm `jsdom` dependency is not installed; that environment limitation is recorded rather than treating the structural/browser renderer checks as a substitute.

# V5.38 TASKING GUIDANCE COMPLETION + VISUAL REFINEMENT

**Date:** 23 September 2026

This release keeps the Tasking & Clinical Guidance feature as one source of truth and expands it with the remaining high-value guideline sections agreed for AirDesk. The source remains the supplied National Air Desk Tasking & Operating Guidelines v2.01 PDF, fingerprint `e46521c06de475024639dd5df7a501fdde18eaf48b70f50685c94f1298facda2`.

Added source mappings: 11.0-11.2 (pages 82-84), 17.9-17.9.1 (pages 115-116), 19.0-19.2 (pages 123-127), and 21.0 (pages 130-131). The viewer now uses an integrated green title bar, icon category cards, stronger section hierarchy, and clearer tables/lists/callouts so long guideline content is not presented as compressed text. Existing clinical, ANTS, tasking, escalation and definitions content stays in the same inert template and generic renderer.

No duplicate contextual copies were added to Resources, the map, SAR or Heli Status. Future guideline replacement remains a single update route: compare the replacement PDF against the pinned manifest, update the one structured template and metadata, rerun checks, then bump the app version.

**Verification:** 74 dependency-free static checks pass. The exact v5.38 HTML was also rendered in Chromium at desktop, iPad landscape and iPad portrait viewport sizes by loading the full document into the browser context. All ten guidance categories switched correctly, Landing Sites rendered, cross-category search returned expected results, no page errors were raised, and the guidance shell had no unintended horizontal or vertical overflow. Direct browser navigation is blocked by this execution environment's administrator policy, so the packaged Playwright navigation suite was not rerun here.

# V5.37 EXTERNAL AUDIT: ADDITIONAL-AIRCRAFT FIXES + GUIDANCE REVIEW

Independent review of the v5.36 handover, requested before further live testing. Three real defects found and fixed in Heli Status additional aircraft; Tasking & Clinical Guidance reviewed in depth and one content issue flagged (not altered). Also noted: this file's own entries stop at V5.33 -- CHANGELOG.md has one-paragraph summaries for v5.34 through v5.36, but the full reasoning for those three releases was never appended here. Not reconstructed in this entry, since it would be guessing at reasoning this reviewer did not do; worth someone with access to that session's context filling in, or simply accepting the CHANGELOG summaries as the record for those three.

**Pool-base callsign lockout.** `callsignControl()` only special-cased additional rows on fixed-kind bases; pool-kind bases (Auckland, Whangarei, Christchurch, Dunedin, Queenstown, Nelson -- six of the twelve bases with more than one slot) fell through to the `<select>` branch unconditionally, which only ever lists that base's own numbered pool. An additional aircraft on any of these bases therefore could not be given a callsign outside that pool, directly contradicting the desk's own stated requirement that an additional aircraft's callsign "can be a mix of call signs so should be typed." Confirmed live across all four multi-slot pool bases before and after the fix. The fixed-kind bases (Waikato, Tauranga, etc.) already worked correctly and are unchanged.

**Callsign sanitisation.** The typed callsign path (both fixed-base additional rows before this release, and now every additional row) uppercased and trimmed but did not strip other characters, so `"a2 waik!"` saved verbatim. Tail numbers already went through a dedicated character-class filter; callsign now gets the same treatment (`[A-Z0-9-]`, live as you type and again on commit), so what is on screen is always what gets saved and matched against a live feed.

**Focus never landing after Add.** The add-aircraft handler's `setTimeout` callback queried `.airdesk-hsb-panel tr[...] [data-field="callsign"]` to focus the new row. There are two `.airdesk-hsb-panel` elements in the DOM simultaneously (one dormant, one open), and the unscoped selector deterministically matched the dormant one first; `.focus()` on an invisible element is a silent no-op, so nothing ever happened. Traced with a direct DOM inspection (`panelCount: 2`, target `offsetParent: null`) rather than assumed from the symptom. Fixed to `.airdesk-hsb-panel.open`, the class the rest of this module already uses everywhere else to mean "the instance on screen." Re-verified: focus lands within one frame.

**What was independently re-verified, not just trusted from the v5.36 changelog:** the tail double-prefix fix (`formatTail` is genuinely idempotent -- tested directly against eleven inputs including `"ZK-ZK-IXP"` and `"ZK-ZK-ZK-IXP"`, both before and after round-tripping through the formatter twice); aircraft-type memory recall by tail; the 3-additional-aircraft cap per base; delete-with-native-confirm; Board View projection of an additional aircraft with its type; and the TracPlus/map identity lookup resolving an additional aircraft's tail. All confirmed by direct Playwright interaction against the running app, not by reading the bundled test suite's assertions.

One note on that suite: the V5.33 release notes record that its browser and jsdom checks could not be run in that environment (Chromium blocked by policy, jsdom dependency missing) and that "those limitations are recorded rather than treating source checks as live-device proof." This environment has a working Chromium and jsdom, and both ran cleanly against v5.36 before any changes here (66 static, 38 runtime, 126 browser, all passing) -- but it is worth knowing that at least one prior release shipped on static analysis alone.

## Tasking & Clinical Guidance

Reviewed in depth, as requested. This module's approved wording lives in one inert `<template>`, not duplicated in executable JavaScript, which is a sound design -- it keeps the content itself outside the code paths that could accidentally mangle it.

Verified: the six categories' own declared section/page ranges (`data-source-sections` / `data-source-pages` on each `.tg-category`) sum exactly to the template-level metadata (sections 1.0-1.2, 3.0-3.5, 4.0-4.29, 9.0-9.6, 15.0-16.4); category switching, the desktop "On this page" navigator with active-section highlighting, and cross-category search all work correctly by direct interaction; the 4.25.1 maternity-facilities table renders as a genuine `<table>`, not converted to cards; searching "sepsis" returns exactly section 4.19 and nothing from 4.18 Metabolic, independently reconfirming the v5.30 cross-mapping fix; the module has no horizontal overflow and correctly hides its desktop nav at true iPad portrait width (820px), matching the v5.32 claim; zero console errors through all of the above.

**Found and flagged, not altered:** section number **4.14 is used twice** -- once for "Trauma - Burns" (`id="tg-source-4-14-trauma-burns"`) and once for "Non-Traumatic Haemorrhage" (`id="tg-source-4-14-non-traumatic-haemorrhage"`), two unrelated topics with genuinely different content, confirmed by direct inspection and by screenshot. This does not cause a functional bug -- navigation and search key off the unique `id`, not the duplicated `data-tg-section` label, so both sections are independently reachable and correctly rendered -- but the visible section number is ambiguous to a reader, and would be ambiguous if cross-referenced against a printed copy of the source guideline. This was not renumbered here: doing so without the source PDF risks introducing a different error, and it is exactly the kind of change that needs sign-off against the approved document, not an inferred fix.

**Worth a second look, not flagged as an error:** the source metadata records a title-page date of 15 May 2026 alongside an approval-footer date of 15/05/2025 -- the approval date is about a year before the title page date. The app already surfaces both dates plainly in its own Source Details panel rather than reconciling them, which is the right instinct if the source document genuinely carries two different dates for two different reasons (e.g. a reissued title page against a standing approval). It is unusual enough to be worth confirming against the physical/PDF source rather than assuming either figure is a typo.

Neither of the two items above was modified. Clinical and tasking content, section text, thresholds, tables and provenance metadata are otherwise unchanged from v5.36.

## Audit coverage

ESLint: 0 findings across all 75 app script blocks (v5.36 was already clean; the earlier google.*/unused-handle findings documented in this app's history at v5.11 do not appear in this lineage). CSS: 0 parse errors, 0 invalid declarations, 0 always-overridden rules across 1,813 rules. Security scan: no eval/new Function beyond the comment recording its own past removal, no document.write, no debugger statements, no plaintext http:// URLs, no window.open without noopener; the one target="_blank" without an explicit rel is inside the bundled MapLibre library, not app code. Every callsign/tail/aircraft-type value confirmed escaped before being written into HTML, in both the pre-existing paths and the three edited in this release.

Noticed in passing and not further audited beyond a structural read, since it was not part of what was asked: an idle-timeout PHI-scrubbing module (`airdesk-phi`) clears patient-identifying fields and strips them from persisted storage and recent-taskings history after 15 minutes of inactivity, re-checked on tab visibility change so a backgrounded tab does not linger. This is new since the version this reviewer last worked from and appears to be a genuine, well-built addition; it was not present the last time this app was reviewed by this reviewer.

25-cycle soak (tab switching, Heli Status, Tasking & Clinical Guidance, Board View) held DOM size, interval count and window/document listener count constant across the run, zero page errors. All 34 `visual-check.mjs` screens pixel-match a baseline taken from the unmodified v5.36 before any change in this release.

Verification: 66 static, 38 jsdom runtime and 126 Chromium checks all pass.

# V5.33 HELICOPTER STATUS BOARD EDIT STABILITY

A focused interaction-stability release for the Helicopter Status Board. No fleet model, Firebase path, capability vocabulary, storage key, tasking logic, map logic or provider integration changed.

The editor previously rebuilt the full board with `innerHTML` after many ordinary selections. On iPad Safari this could detach the native select or winch button during the same touch/change sequence, and optimistic Firebase callbacks could trigger an additional redraw. The editor now keeps routine controls mounted, updates callsign/tail/status/winch projections in place, suppresses redraws for Firebase echoes that already match local state, and avoids full background redraws while Edit mode is open. Full redraws remain for structural actions such as entering or leaving Edit mode, moving a slot, or opening setup panels.

The 15-second live refresh continues to update aircraft status, but in Edit mode it refreshes status/count projections only. Genuine shared changes still merge into the board state immediately and are fully rendered when Edit mode closes. Existing conflict detection remains owned by the shared-sync transaction layer.

Regression coverage now checks that a winch toggle and flight-rule select remain the same connected DOM node after their value changes, and that an Edit-mode background render does not replace them.

Verification in this build environment: all 60 dependency-free static checks pass. The packaged browser regression has been extended for the stable-control behaviour, but a fresh browser run could not be completed here because Chromium navigation is blocked by administrator policy. The jsdom runtime suite also cannot run in this environment because its npm dependency is not installed. Those limitations are recorded rather than treating source checks as live-device proof.

# V5.32 TASKING & CLINICAL GUIDANCE VISUAL PASS

A focused visual refinement of the v5.31 Tasking & Clinical Guidance module. No approved guideline wording, source mapping, category structure, calculations, provider integrations, persistence keys or operational workflows were changed.

The modal now uses a lighter source-provenance header, stronger visual hierarchy, a more compact search/category toolbar, a clearly selected category state, a dedicated “On this page” desktop navigator with live section highlighting, refined card typography and spacing, and clearer Skill versus Hospital threshold accents. The underlying single-template guidance architecture and full-guideline PDF maintenance workflow remain unchanged.

Responsive behaviour was rechecked at desktop, iPad landscape and iPad portrait dimensions. The guidance shell has no horizontal overflow at those sizes. All 57 dependency-free static checks pass after the visual changes.

# V5.31 TASKING & CLINICAL GUIDANCE

The Clinical Conditions reference was broadened into a single operational guidance modal using the complete **National Air Desk Tasking & Operating Guidelines, version 2.01** as its maintenance source. The release deliberately changes the reference UI only; no tasking calculations, map data, provider integrations, persistence keys or established workflows were changed.

Mapped source sections are 1.0–1.2, 3.0–3.5, 4.0–4.29, 9.0–9.6 and 15.0–16.4. The complete PDF SHA-256 is `e46521c06de475024639dd5df7a501fdde18eaf48b70f50685c94f1298facda2`. The title page date (15 May 2026), document-control date (12/05/26) and approval-footer date (15/05/2025) are retained as separate source metadata rather than reconciled by the application.

The modal opens on Clinical Conditions to preserve the existing workflow, with category tabs for Specific Skills, ANTS, Tasking Methods, Escalation & Review and Definitions & Acronyms. Desktop uses a section navigator; smaller viewports use the category strip and natural document scrolling. Search works across all mapped categories. Clinical threshold tables retain the v5.30 card presentation; general source tables remain tables.

For maintainability, approved wording remains in one inert `<template>` and is not embedded in executable JavaScript. Future maintenance should be performed from the current ZIP plus the replacement full guideline PDF, with the source map, dates, page ranges and fingerprint updated in the same release.

Source hierarchy labels from the issued document are retained inside the curated views, including the Specific Skills criteria label, rapid-review indication heading, grouped response-code headings, ANTS/pathway code headings, 1.0 Acronyms & Definitions, 16.0 Conflicts and Escalation and the Active Incident Review process label.

Verification in this build environment: all 57 dependency-free static checks pass. The rebuilt guidance was exercised in isolated Chromium at desktop and iPad portrait sizes with zero page errors and no horizontal overflow; the iPad landscape layout was also visually exercised during the build. The packaged jsdom and Node Playwright suites could not be freshly rerun because their npm dependencies were unavailable in this environment, so provider/live-device testing remains part of deployment sign-off.

# AirDesk detailed release notes

Moved verbatim from the HTML file's header comment in v5.24, so the header stays short.
`CHANGELOG.md` has the one-paragraph summary of each release; this file keeps the
reasoning, the checks each release relied on, and the mistakes caught and corrected
along the way. Newest first. Future releases: add detailed notes here, not in the header.

```text
V5.30 CLINICAL CONDITIONS SOURCE FIDELITY
Clinical Conditions Guidance was checked line-by-line against the supplied
National Air Desk Tasking and Operating Guidelines extract, version 2.01,
approved 15/05/2025 (source pages 29-49).
- Source fidelity: restored section 4.0 and source-order sections 4.1-4.28,
  including both source sections numbered 4.14 and the 4.25.1 Secondary &
  Tertiary Maternity Facilities table. Issued wording is preserved rather than
  editorially corrected.
- Corrected mapping: the v5.29 display had 4.18 Metabolic thresholds grouped
  under 4.19 Sepsis, and 4.21 Vascular thresholds grouped under 4.22
  Anaphylaxis. Each table now sits under its source condition.
- Removed 4.29 Specific Skills from this modal because the supplied approved
  Clinical Conditions source ends at 4.28. No clinical replacement text was
  invented.
- Maintenance: clinical wording remains in a single inert HTML template, now
  carrying guideline version, approval date, page range and SHA-256 source
  fingerprint. README documents the replacement-PDF workflow. Structural and
  runtime tests guard source metadata, sequence, maternity table retention and
  the two corrected condition boundaries.
- Verification: 44 static checks passed. The modal was also exercised in
  isolated Chromium after full app assembly with zero page errors; its source
  metadata, 31 section navigation entries, 57 rule cards, preserved maternity
  table and corrected 4.18/4.19 and 4.21/4.22 boundaries all rendered as
  expected. iPad portrait and landscape stayed within the dialog, with only
  the intentionally scrollable maternity table wider than its wrapper.

V5.29 FINAL PRODUCTION AUDIT
Audit before live testing and confirmation of the new working baseline.
- Code: ESLint 11 findings, all previously reviewed (google.* guarded; three
  written-but-unread map handles; two interval handles; one compressed
  Google elevation promise). CSS: 0 parse errors, 0 invalid declarations,
  0 dead classes. Found and removed 2 always-overridden declarations: the old
  .ad-heli rule (sized/bordered for the crosshair glyph) was still drawing a
  circle round the v5.27 helicopter icon -- the whole rule removed.
- Security: no eval/new Function (one hit was a comment recording its earlier
  removal), no document.write, no console/debugger leftovers, no http://
  URLs. All 9 innerHTML/showModal writes and all 213 unescaped-looking
  template interpolations traced: every feed- or user-supplied value
  (TracPlus names, typed callsigns/tails, notes, geocoder errors) is escaped;
  the rest are app constants, numbers or embedded data. Pathways message now
  escaped anyway. The only target=_blank without rel is inside the bundled
  MapLibre library (not edited; modern browsers imply noopener).
- CSP: every origin the app contacts is allowed (connect/frame); the six
  missing origins are plain links, which CSP does not govern.
- Updates: sw.js is network-first with a 3 s timeout and a single fixed cache
  entry; Netlify serves everything max-age=0, must-revalidate. An online desk
  cannot run an old build.
- Deployment: publish = "." exposed the maintainer files publicly (README
  sections describe unconfirmed security settings). netlify.toml now forces
  404 for them; the ZIP still carries them.
- Stability: 30 cycles of every tab, four dialogs and Board View -- DOM 3,132,
  13 intervals, 150 window/document listeners, identical after cycle 5 and 30.
  Simulated-clock run with all services failing: DOM constant and at most one
  toast for 3 simulated hours (the next step was stopped; fake-clock timer
  compression, not a real-time effect).
- Accessibility: no serious/critical Axe findings on any tab or Board View at
  desktop and iPad sizes; no overflow; only DM Sans and Roboto Mono in use.

V5.28 H-IN-RING BRAND MARK
Replaced the medical-plus identity with the agreed Air Desk H-in-ring.
- Header: same <svg> element and attributes inside the unchanged 38px
  .brand-mark tile (22px mark); only its drawing changed, to a 1.8-stroke ring
  (r 9.6) and a 2.3-stroke H with butt caps, white on the existing header.
  Measured tile position/size and mark size identical before and after.
- Icons: one source drawing (192 grid): full-bleed #1F6B2A square (browsers
  and iOS round the corners themselves, as with the previous icons), 12-unit
  white ring (r 72) and a solid H (18-unit stems). The SVG favicon embeds it
  directly; the 192x192 PNG and 180x180 Apple touch icon (RGB, no alpha, as
  before) were rendered from it in Chromium. Checked legible at 48/32/16 px.
- No manifest file exists and sw.js references no icons, so nothing else
  carries the mark. Hospital and medical markers on the map are unrelated
  and unchanged.

V5.27 CALCULATION CARDS, MAP PILLS, DESK STATUS
Desk feedback on three screenshots.
- Calc cards: the helicopter (thin 48x30 outline) and car (solid 32x24 fill)
  did not match; both are now 24px outline icons, 1.8 stroke, drawn at one
  size. While verifying, found the times overflowed their cards at every
  width <=1366px (measured: one card at 1366, all six at 1024) -- a fixed 22px
  in cards ~58px wide on iPad. .calc-mode is now a container and the time is
  clamp(12px, 28cqi, 22px): realistic longest values ("~40 min", "120 min")
  measure ~3.5em, so 28cqi always fits. Card side padding 9px -> 5px. The two
  old fixed-size overrides (17px, 19px) were removed, not layered over.
  Measured: no overflow at 1440/1366/1280/1180/1024; 19px at 1440.
- Map pills: counts restyled from bordered chips to text with coloured numbers
  and dividers; the crosshair glyph replaced by an inline helicopter icon;
  flight-events label "Flight Events" (aria-label keeps "Live Flight Events").
  Title case kept for On Base / Off Base to match every other surface.
  MapLibre's attribution toggle restyled as an outlined info icon.
- Desk Status note: a tone-ok/warn/fail box with icon, title and detail;
  same wording for the degraded and offline cases, now split title/detail.

V5.26 TAB LABELS NEVER WRAP
Final visual review. "Search & Rescue" needs ~145px of tab and wrapped to two
lines whenever the tab bar was 602px or narrower (measured at 1280, 1180 and
1024px windows). .tabs is now a container (tabbar); below 630px the SAR tab
shows its short label "SAR" (the term the app already uses, e.g. SAR Key
Questions). The button's aria-label keeps the accessible name, and the SAR
panel's aria-labelledby therefore still reads "Search & Rescue". No code
reads tab text. Verified single-line labels at 1440/1366/1280/1180/1024.

V5.25 HANDOVER DOCUMENTATION
Documentation only; app unchanged apart from its version. README status box
replaced with a short current status and a Start here section for reviewers
(reading order, deliberate oddities, ownership-change checklist).
ARCHITECTURE.md re-measured and updated from its v5.6 state, including a
correction: the Google Fonts <link> onload is the one inline handler, permitted
by the CSP's 'unsafe-inline', so web fonts do load on the live site.

V5.24 MAINTENANCE CONSOLIDATION
Header condensed from 473 to 111 lines; these notes moved here verbatim.
tools/visual-check.mjs shipped (npm run visual:baseline / visual:compare),
proven deterministic on an unchanged file and to catch a 52x3 px change.
Removed the SAR block's unused top-level toRad (shadowed by a local copy in
bearingDeg) and merged one last split style rule.

V5.23 HELI STATUS: PRIORITY REORDER + NRES TAIL MEMORY
Heli Status Board Edit mode only. No calculation, dataset, rule, storage
format or Firebase path changed; the live board and wall board are
unchanged.
- Priority arrows: on bases with more than one aircraft (NRES Whangarei and
  Auckland, Christchurch, Dunedin, Queenstown), up/down arrows beside the
  role swap an aircraft with its neighbour. Roles come from row position and
  callsigns are unique, so reordering previously meant parking an aircraft
  off duty to free its callsign. The whole slot moves (callsign, tail,
  winch capabilities, OOS reason); empty slots can move too. Saves and syncs
  like any other edit; keyboard focus follows the moved aircraft.
- NRES tail memory: each desk remembers the last tail seen with each NRES
  callsign, learned from the synced board and stored locally
  (airdesk-hsb-nres-tail-memory-v1), so the shared record is untouched.
  Picking an NRES callsign fills its remembered tail unless that tail is
  already on the board under another callsign (never shown twice). Typing a
  different tail becomes the new memory. Rescue (A1/A2...) callsigns are
  not auto-filled, as their tails change more often.
- Edit-mode columns rebalanced so the arrows, full role names, 6-character
  callsigns (A2QTWN, A1NELS) and all six winch toggles fit; below 1100px
  the edit toggles show letters only (as the wall board does). Fixes
  winch-toggle clipping at 1024px that predated this release.

V5.22 SHIFT NOTES HANDLE BETWEEN CARDS
Layout only, at the desk's request. The Shift Notes drag handle moved out
of its card into the gap between Shift Notes and Helicopter Change Process,
styled like the workflow/map splitter (the same 52x3 pill, horizontal).
It is its own item in the Resources .stack grid; -12px margins pull it over
both neighbouring 12px gaps, so those two cards are now 24px apart and the
whole strip is draggable. Behaviour, saved height, keyboard control and
Board View hiding are unchanged.

V5.21 STYLESHEET CLEAN-UP, PHASE 2 (SMALL COMPONENTS) -- SWEEP CLOSED
No visual or functional change: all 34 app screenshots pixel-identical to
v5.20 before the version bump, and per-component computed styles unchanged.
- Removed 56 !important flags across eight small components: Transfers
  hospital autocomplete (hs-row/hs-box), screen-reader-only utility,
  layers toolbar button, action toast, Selected Location chip, map marker
  anchor, and the add pill.
- Excluded .act-btn-quiet after verification caught a regression: the
  Primary "Times Breakdown + Adjustments" button carries both act-btn and
  act-btn-quiet, and the quiet modifier needs !important to beat act-btn's
  own !important background. Stripping it turned the button solid green.
- Also left alone: two flags on the shared Citrix-performance rule, which
  spans ~20 unrelated classes app-wide.
WHY THE SWEEP STOPS HERE: both regressions caught in this phase (v5.20's
reference-sheet table header, and this button) had the same cause -- a
base class and a modifier class on one element, which an exact-selector
check cannot see. The ~460 remaining flags sit mostly in dialog sizing and
per-tab (Primary/SAR) layout, which is built from exactly that base-plus-
modifier pattern. Clearing them safely means reviewing each by hand,
screen by screen, for little practical gain; they are intentional
overrides, not dead code. Tidy them opportunistically when a component is
being changed anyway (verify with before/after screenshots).

V5.20 STYLESHEET CLEAN-UP, PHASE 2 (MAP LAYERS PICKER); REF-SHEET ATTEMPTED
No visual or functional change to what shipped. Two components examined.
- Map layers picker (.layer-catalogue-row and related): 25 !important flags
  proven to have no real competition and removed. Verified: computed
  styles of active, inactive and disabled rows byte-identical, and the
  open picker is pixel-identical, at 1200x1400.
- Reference sheet (.ref-sheet, used by Fixed-Wing Transfers, Recognised
  Hospital Facilities and others) was attempted and REVERTED. The check
  flagged the Fixed-Wing table header's background/colour as safe to
  strip; verification found this was wrong -- the header rendered pale
  amber instead of its usual dark green once applied. The cause was not
  fully identified before this was reverted (a plausible but unconfirmed
  lead: a same-selector-text rule can still be beaten by a more specific
  or differently-scoped rule this check does not model). .ref-sheet and
  the shared .gen-btn button class are reused across enough different
  screens that this exact-selector method is not reliable for them; they
  need one-at-a-time manual verification per screen that uses them, not
  this kind of check-then-bulk-apply pass. No file was shipped with this
  change at any point.

V5.19 STYLESHEET CLEAN-UP, PHASE 2 (MAP TYPE MENU)
No visual or functional change, proven and verified. Second by-hand
consolidation trial (see v5.18), this time on a genuinely harder
component: the map type menu has three real competing rules for its own
position and size (base, and two responsive breakpoints), unlike Hospital
Capabilities' flat, single-context styling.
- Corrected the checking method mid-task: the first pass compared
  declarations by shared class name, which wrongly treated unrelated
  selectors (e.g. a different component's .active state, or a button's own
  width inside this menu) as competing with the menu's own rules. Rebuilt
  it to compare by exact selector text only, matching how the cascade
  actually decides ties, then re-verified from scratch.
- The corrected check found 26 !important flags with no real competition
  (button styling, hover/active colours, the windy-mode hide rule, small
  text sizing) and left 14 alone -- the menu's left/top/width/max-width
  across its three breakpoints, which do genuinely compete and need the
  flag to behave correctly at each width.
- Verified computed left/top/width/max-width, active-button colours, and
  windy-mode hiding are byte-identical at four widths (1440, 900, 640, 420)
  spanning both breakpoints, plus pixel-identical screenshots at each.
- The first (later-discarded) pass did briefly strip four position
  properties that should have stayed; caught by this same verification
  before anything shipped, and never reached a package or a version bump.

V5.18 STYLESHEET CLEAN-UP, PHASE 2 (TRIAL: HOSPITAL CAPABILITIES)
No visual, functional or data change -- proven, not just tested. Trial run
of the by-hand consolidation deferred at v5.13: rather than merge rules by
cascade position (which the automated phase 1/2 passes already did
everywhere it was provably safe), this checked every !important in the
Hospital Capabilities popup (.hospital-cap-*, .airdesk-hc-*, ~150 lines)
against the ENTIRE stylesheet for any other rule touching the same class
and property. None of its 98 !important flags had one -- nothing was ever
competing with them, so they did nothing. All 98 removed. Verified
pixel-identical across 15 hospitals (every colour-coded section tone) at
desktop and iPad sizes, and with zero console errors.
This was a trial for the harder remaining consolidation (dialog sizing,
per-tab breakpoints, map type menu -- see README) rather than that work
itself: those areas have genuine multi-breakpoint competition and need the
same proof-per-declaration approach, not a bulk pass.

V5.17 MAP TOOLBAR RESIZED
Styling only. The main map toolbar (expand, layers, map type, Windy,
measure) now matches the zoom stack beside it -- 40px buttons, 17-18px
icons -- instead of its own larger 52px scale. The zoom stack's glass
finish (blur, subtle border, quiet green hover) was already applied to
this toolbar in v5.10 and is unchanged; only the size moved to match.

V5.16 SHIFT NOTES HANDLE, VISUAL POLISH
Styling only, requested after seeing v5.15 live: the drag handle below
Shift Notes was too visually heavy. Pill narrowed (52px -> 32px) and
thinned (4px -> 3px), its rest colour lightened, and the surrounding bar
tightened (16px -> 12px, no top margin). The hit area (the whole bar, not
just the pill) is unchanged in relative size, so it stays easy to grab on
a touch screen; only its visual weight changed.

V5.15 FLEET-PANE OVERFLOW FIX + SHIFT NOTES RESIZE HANDLE
No calculation, dataset, rule, storage-format or sync change (one new,
independent localStorage key).
- Root cause of the SPLIT-view overlap the v5.14 fix did not fully resolve:
  #board-pane (the fleet table's grid item) had no min-width, so its
  default min-width:auto let the table's own min-width (610px+) overflow
  the grid track -- straight past the 10px resize splitter and into the
  map -- instead of scrolling inside the pane as intended. min-width:0 on
  the pane and its two flex children (mirroring the min-height:0 already
  in place for the vertical axis) fixes this at any pane width, including
  one the desk has dragged narrower than default.
- Added a drag handle below the Shift Notes box on the Resources tab, at
  the desk's request: the native corner resize grip was a poor touch
  target on iPad. Height is a plain pixel value, independent of the
  board-notes-splitter above (which resizes a different pane by
  percentage), saved separately, and disabled while this section is
  living inside Board View, where the box's height is fixed.

V5.14 SPLIT-VIEW MAP TOOLBAR OVERFLOW
Bug fix, reported from a real iPad in a narrow Split View / Stage Manager
window. No calculation, dataset, rule, storage or sync change.
- The v5.10 grouped map toolbar has a fixed natural width (~294px). In
  SPLIT mode the map pane can be narrower than that (confirmed as low as
  ~307px on a 1024px-wide window, likely narrower on the reporter's actual
  window), and the toolbar overflowed past the map pane into the Windy pane
  beside it.
- Fixed at the layout level, not with a breakpoint tuned to one measured
  size: .map is now a CSS containment context for its own pane, and the
  toolbar's max-width is capped to that pane with flex-wrap, so it drops
  extra buttons to a second row rather than overflow, at any width.
- Investigated separately: "can't drag the map on the wall board." Enabled
  dragPan and cooperativeGestures were confirmed off, and a scripted mouse
  drag and a simulated real touch drag both panned the map correctly in
  Chromium on Desk and Wall. Could not reproduce; likely Safari- or
  device-specific. Left unchanged pending more detail from the reporter
  (see README).

V5.13 STYLESHEET CLEAN-UP, PHASE 2 (AUTOMATED PART)
No intended visual change; pixel-identical to v5.12 across the same 34
desktop and iPad screenshots.
- Merged a further 31 selectors' scattered declarations (56 moves, 10 rules
  emptied) using the cascade rule that source order only decides ties: a
  declaration may move past a rule with a related property (shorthands
  mapped, e.g. font/line-height, inset/left) when importance differs or the
  specificities cannot tie; selectors with :is()/:not()/:has()/:where() or
  nth-child are treated as unscorable and block.
- Metric correction: earlier counts split selectors on commas inside
  :is(...), which inflated "scattered" figures. Counted correctly,
  selectors styled in 4+ rules went 41 (v5.11) -> 31 (v5.13); 3+ went
  99 -> 77. Most remaining spread is responsive (desktop/iPad/Citrix media
  queries) or intentional shared interaction-state rules for all buttons.

V5.12 STYLESHEET CLEAN-UP, PHASE 1
No intended visual change. No script, data, rule, storage or sync change.
Every step was checked against 34 screenshots (17 screens x desktop and
iPad, clock frozen, animations off): pixel-identical apart from the version
label itself.
- Removed 217 declarations that a later rule for the same selector, in the
  same media context, always overrides (skipped where the later value could
  be unsupported -- dvh, env(), color-mix, prefixes -- as those are real
  fallbacks), and the 46 rules this left empty.
- Removed 41 rules and trimmed 3 selector lists for 22 classes that exist
  nowhere in the markup or scripts (old Board View capability chips, old
  Heli Status layouts, retired calc/scene widgets). Classes built in code
  (ad-slot-*, duty-*) were checked by hand and kept.
- Merged 29 selectors' scattered declarations into their final rule where
  no rule in between sets the same or a related property (46 moves).
- Result: 200 KB -> 190 KB, 1831 -> 1733 rules, 6783 -> 6414 declarations,
  501 -> 469 !important. Phase 2 (by hand, per component): consolidate the
  remaining multi-rule components (buttons, pills, dialogs, map, left
  panel) and remove !important where the cascade no longer needs it.

V5.11 CODE AUDIT
Defect fixes only. No calculation, dataset, rule, storage key, Firebase
path, map behaviour or provider endpoint changed.
- Method: ESLint over all 75 app script blocks (~12,600 lines; MapLibre and
  the embedded datasets excluded as vendor/generated), css-tree validation
  of every declaration in #airdesk-styles, html-validate on the markup, then
  a scripted run of every workflow and dialog in Chromium.
- Heli Status sync messages ("Firebase sync connected/disconnected",
  "Sync error") called a showToast() that no longer exists and so never
  appeared; they now use AirDesk.ui.feedback.toast.
- Heli Status refreshMaps(): removed a legacy block whose map globals no
  longer exist (it never ran) and replaced it with the second map refresh
  it was meant to provide.
- Two CSS rules used "font:<size> inherit", which is invalid, so browsers
  dropped them: the emergency-resource popup action buttons and the map
  info-pill labels now get their intended size and weight. npm run check
  now fails on the pattern.
- Tidied an unused destructured variable and two promise executors.
- Left as reviewed and harmless: google.* uses (guarded, loaded on demand),
  three assigned-but-unread map variables, one unused SAR helper, and 13
  <div> elements inside <label> (invalid HTML, rendered identically by every
  browser; changing them would risk form layout).

V5.10 POLISH AND AUDIT
Styling only. No data, calculation, rule, storage key, Firebase path, map
behaviour or provider endpoint changed.
- Typography: DM Sans is the one UI face (IBM Plex Sans no longer loaded);
  Roboto Mono stays for callsigns and tails. 19 older Heli Status rules that
  hard-coded system-ui or a generic monospace now use var(--font) and
  var(--mono). MapLibre's own CSS and the canvas-drawn map "H" keep theirs.
  npm run check now fails if any other family is loaded.
- Map tools: one grouped card matching the zoom card, with dividers
  (expand | layers, map type, Windy | measure). Button sizes unchanged.
- Board View on-call line reads "No on-call doctor set" instead of a dash.
- Audit: every tab and Board View at 1440 desktop and 1180 iPad sizes --
  no page overflow, no page errors, no serious/critical Axe findings, only
  DM Sans and Roboto Mono in use. Header chips were already flat; no change.

V5.9 CAPABILITY COLOURS
Styling only. No data, calculation, rule, storage key or Firebase path
changed. Winch slots are coloured by type -- Land green, Wets blue, Decks
yellow -- the same by day and night. IFR moves to indigo so it no longer
matches the Wets/night blue; VFR stays a neutral light grey.

V5.8 SECTOR WINCH CAPABILITIES
Presentation and capability-model change requested by the desk. No
calculation, dataset, operational rule, map behaviour, provider endpoint,
storage key or Firebase path changed.
- Winch now records the sector's six capabilities: Land, Wets and Decks,
  each by Day or by Night. Shown as two fixed groups (sun, moon) of three
  slots (L mountain, W water, D deck), letters left of icons. Unavailable
  slots stay as dashed outlines so columns line up. Set daily in Edit mode
  by tapping each slot.
- Stored in the same slot caps list that already syncs through Firebase.
  Older values convert on read, conservatively: Wet Winch -> Land and Wets
  by day; Dry Winch -> Land by day; No Winch -> none. Blood is removed.
  Upgrade every active desk together: a v5.7 desk saving the shared record
  drops the new values (its own normaliser does not know them).
- Heli Status Board: Status, Base, Role, Callsign, Tail, Flt, Winch. The
  OOS and "+" columns are gone from the live view; the OOS reason now reads
  in the status pill ("OOS · Mechanical"). Edit mode keeps OOS as a column.
- Board View: Status, Base, Aircraft, Flt, Winch. The Airborne column and
  its TracPlus lookup are removed; TracPlus still drives On/Off Base and
  the live map. Column widths measured at the 1920 wall and the iPad desk
  pane; narrow panes show letters only, the narrowest scrolls sideways.
- IFR/VFR restyled to the same slot shape: IFR with a cloud (blue), VFR
  with an eye (neutral).
- tools/browser-check.mjs now runs (AIRDESK_CHROMIUM may point at an
  installed Chromium), reads the expected version from the filename, and
  checks both boards, the legacy conversion and unclipped Winch cells.
  Two stale test lines that had never executed were corrected.

V5.7 INDEPENDENT AUDIT
Verification-only edition. No calculation, dataset, operational rule,
storage key, Firebase path, map behaviour or provider endpoint changed.
- Independent review of the v5.6 package: reconfirmed all 35 static and 29
  jsdom runtime checks pass with no errors or new OPEN items.
- Structural CSS audit of all 1,736 rules in #airdesk-styles found no
  accidental duplicate-property declarations; the two matches surfaced by
  an automated scan (.dialog's dvh/vh fallback pair) are intentional
  progressive enhancement, not cruft.
- Recomputed WCAG contrast for every text colour token in :root against
  its production backgrounds (surface, surface-soft, canvas, g50): all
  pass AA (>=4.5:1) except --amber on --canvas, which passes AA for large
  text (4.42:1) and was already documented as tuned in the v5.0 pass.
- No dead code, no TODO/FIXME markers, and no functional gaps found
  against ARCHITECTURE.md or the AI maintenance contract below. Did not
  change application logic on the strength of this audit alone, per that
  contract's requirement for explicit scope and regression evidence.
- Correction recorded in v5.8: a local Chromium was available and the
  browser suite could have run; it did so from v5.8 onward.

V5.6 HANDOVER HARDENING
Maintenance and documentation change. No calculation, dataset, operational
rule, storage key, Firebase path, map behaviour or provider endpoint changed.
- Moved Clinical Conditions Guidance from an executable JavaScript template
  literal into an inert HTML template. Guideline text can now contain normal
  backticks or ${...} text without becoming program code.
- Added CHANGELOG.md as the concise release history for future editions.
- Aligned the handover with the actual filesystem workflow: versioned ZIP,
  local checks, then whole-package Netlify upload. No GitHub Actions workflow
  is active or required.
- Documented which Google and Firebase controls are proven by this package
  and which require console evidence before formal ICT sign-off.

V5.5 SELF-CHECK CORRECTION
Diagnostic-only change. No calculation, dataset, operational rule, storage
key, Firebase path, map behaviour or provider endpoint changed from v5.4.
- Embedded dataset verification now uses the canonical AirDesk.data module
  registry rather than the map layer registry, whose lazy registration can
  be incomplete when an operator runs the check immediately after startup.
- HTTP localhost and 127.0.0.1 are reported as Local Test information rather
  than insecure deployment failures. Non-local HTTP hosting still fails.

V5.4 OPERATIONAL ASSURANCE
No calculation, dataset, rule, geometry, storage key, Firebase path, map
behaviour, provider endpoint or service-worker caching strategy changed.
- System Status now shows when each live subsystem was last confirmed.
- TracPlus is visibly marked stale when no successful poll has been
  confirmed for three minutes, including after a suspended browser resumes.
- Added a non-billable deployment self-check for release identity, core
  configuration, application shell, embedded datasets, map runtime, shared
  sync state and secure hosting. It uses already-loaded state and makes no
  provider requests.

V5.3 VERIFICATION HARDENING
Test and documentation changes only. No operational logic, dataset, rule,
geometry, storage key, Firebase path, map behaviour, provider endpoint or
service-worker caching strategy changed from v5.2.
- Added a deterministic Chromium regression suite for desktop, iPad-sized
  and Citrix-profile layouts, core dialog interaction, page overflow and
  serious or critical Axe accessibility findings.
- Added a browser suite for local and automated regression checks.
- Fixed the map container's invalid standalone aria-label by identifying it
  as a labelled region. No visual or map behaviour changed.
- Corrected the handover's stale offline section to describe the existing
  v5.1 service worker accurately.

V5.2 VERIFIED EDITION
Packaging and release metadata only. No operational logic, dataset, rule,
geometry, storage key, Firebase path or provider endpoint changed from v5.1.
The supplied v5.1 archive passed the structural check. The v5.2 package was
then version-aligned and passed both the structural and jsdom runtime checks.

V5.1 OFFLINE SHELL
Deployment layer only. No operational logic, dataset, rule, geometry, storage
key, Firebase path or provider endpoint was changed from v5.0.
- Added a same-origin service worker (sw.js) and a best-effort registration
  block (#airdesk-offline-shell). The worker caches THIS FILE only, network
  first with a 3s timeout. A reload during an outage still brings up the
  datasets, the reference content and the response calculation, both of whose
  ETAs are typed rather than fetched.
- Nothing else is cached, deliberately: map tiles, Firebase, TracPlus, the
  NZTA proxy and the Google endpoints always go to the network. A cached live
  response is stale operational data shown as current. #airdesk-health
  already reports each subsystem's real state and toasts on the transition.
- The worker carries no version or filename literal; the shell is stored
  under a fixed cache key, so a version bump needs no edit in sw.js.
- netlify.toml now sends Cache-Control: max-age=0, must-revalidate. A stale
  worker cannot replace itself.
- Registration is best-effort: no service-worker support, a missing sw.js or
  a file:// open all fall through silently and the desk behaves as before.

NOT VERIFIED IN v5.1
The service worker has never executed -- there is no browser in the build
environment and jsdom has no service-worker support. Install it on the
deployed site, then pull the network and reload to confirm. The v5.0 visual
changes below likewise remain unverified at 1366 and 1024.

V5.0 PRE-PRODUCTION AUDIT AND VISUAL POLISH
Presentation only. No operational logic, dataset, rule, geometry, storage key,
Firebase path or provider endpoint was changed from v4.7.3.
- Calculation Summary tile headings wrap instead of ellipsising. They lost words
  from 1600px down: at 1366 "Time until required clinical skill arrives" lost 55px,
  and at 1024 all six titles and subtitles clipped. Two heading lines are reserved
  so the Helicopter/Road boxes and verdict pills align across the three tiles.
- Four tile colours brought to WCAG AA: the tile subtitle (3.52:1), the
  Helicopter/Road mode labels (3.98:1) and the pending "--" placeholder (2.01:1),
  which has to be legible because it marks a value the dispatcher has not entered.
- Response Plan card stopped overflowing at 1024. Capabilities/Pathways/Compare
  measured 240px inside a 188px column and ran 26px past the card -- min-width:auto.
  Only rows of adjacent pills may wrap; the Helicopter card's row is excluded by
  selector because it carries the Live Aircraft button and .tracplus-live-line,
  and wrapping that row moves the button.
- ETA to Scene keeps its value="0" default. Verified that the 0 cannot mislead the
  Appropriate Skill tile: when the scene out-ranks the crew on scene the tile uses
  the separate backup ETA, and with no road backup it reads "Helicopter only option".
- Header version chip literal corrected; the markup still read v4.6.1.
```

## v5.36, 23 September 2026

### Final production audit

This edition is a final audit release rather than a feature release. The review covered the single-source HTML structure, all inline JavaScript parsing, HTML/tag/id integrity, CSS parse integrity and duplicate-property fallbacks, deployment rewrites, service worker boundaries, dataset-id baselines, Tasking & Clinical Guidance source structure, Heli Status persistence and editor stability, additional-aircraft map identity, Board View projection, and desktop/iPad responsive behaviour. No TODO/FIXME/debugger leftovers or new patch/override layers were found.

The audit did find one real Heli Status defect. `formatTail()` was not fully idempotent: a registration already formatted as `ZK-XYZ` could pass through a second formatting path and become `ZK-ZK-XYZ`. The row remained saved, but exact-tail lookup for `ZK-XYZ` then failed, so a user-added aircraft could lose the intended map callsign ownership. The formatter now removes every leading `ZK`/`ZK-` prefix before adding one canonical `ZK-` prefix. `XYZ`, `ZKXYZ`, `ZK-XYZ` and the malformed legacy form `ZK-ZK-XYZ` all resolve to `ZK-XYZ`.

The regression suite now executes the isolated Heli Status model during the dependency-free static audit and checks that tail formatting remains canonical. The browser suite also records the persisted extra-aircraft tail and asserts that the same row resolves through Heli Status and the TracPlus map callsign API. A stale v5.6 URL in `tools/verify.mjs` was also replaced with the dynamically discovered `APP_NAME`; this changes test metadata only, not the application.

### Verification

- 66 dependency-free structural checks pass after the v5.36 changes.
- A real Chromium functional audit passed the complete desktop workflow used for this release: boot/configuration, all main tabs, System Status/self-check, Tasking & Clinical Guidance categories/search/overflow, legacy winch conversion, stable Edit-mode FLT/winch controls, additional-aircraft persistence before tail entry, canonical `ZK-XYZ` persistence, map callsign resolution to `A2WAIK`, Board View projection and zero page errors.
- A separate Chromium responsive pass succeeded at both iPad landscape and iPad portrait sizes for boot/viewport, Tasking & Clinical Guidance horizontal overflow, additional-aircraft tail/map identity and zero page errors.
- CSS parses with zero errors. The only duplicate properties are the deliberate progressive fallbacks for dialog `max-height` and `html, body` height.
- The packaged jsdom and Node Playwright suites remain included and parse cleanly. Their npm runtime dependencies are not installed in this execution environment, so their results are not represented as freshly executed v5.36 results.

This release deliberately makes no changes to calculations, operational wording, approved datasets, Firebase paths/rules, storage keys, provider endpoints, map datasets, clinical guidance or established desk workflows.

## v5.35, 23 September 2026

### Heli Status additional-row visibility correction

A v5.34 user test exposed a narrow live-view defect: an additional aircraft row was persistent in state, but the live Heli Status renderer still applied the legacy "hide rows without a real tail" rule to every row. A newly added aircraft such as `A2WAIK` with a tail field still at `ZK-` therefore disappeared when Edit mode was closed, even though it remained saved.

v5.35 keeps that filtering rule for configured roster slots but exempts persistent additional rows. An additional row now remains visible in the live Heli Status Board until explicitly deleted, matching the feature contract. Additional rows with no callsign also no longer fall back to the configured base callsign.

The map identity lookup remains deliberately tail-based. Once a real tail is entered, the added row participates in the same callsign-to-tail map identity mapping as configured aircraft.

## v5.34, 23 September 2026

### Heli Status: additional aircraft and aircraft type

This release extends the existing Heli Status model rather than layering a second roster system on top of it. Edit mode can add up to three **Additional** aircraft at any base. Additional rows persist locally and through the existing `airdesk/heliStatus/v1` Firebase record until an operator explicitly deletes them. Configured roster rows remain protected and cannot be deleted.

Additional rows use the same tail/callsign identity indexes as configured rows. As a result, when an additional row assigns a callsign to a physical tail, the live-map label resolves that callsign in the same way as the original aircraft rows. Board View also includes the added aircraft.

An optional **Aircraft Type** field is now stored on each Heli Status slot and displayed in the status board and Board View. Type is also remembered locally by physical tail, so a known aircraft can repopulate its type when its tail is entered again.

The shared record path, storage key, configured `maxSlots`, existing priority-arrow model, capability model and map identity API remain unchanged. v5.33's in-place edit-control behaviour is retained to avoid reintroducing iPad jumpiness.

### Verification

- 63 dependency-free static checks pass.
- A local Chromium functional run verified add, edit, map identity lookup, Board View projection, stable FLT/winch controls, and deliberate deletion of an additional row with no page errors.
- The packaged jsdom/Node and Playwright suites remain included. In this build environment their npm dependencies are unavailable, so they were not represented as freshly executed results for this release.

