## Canvas and divider refinement, 28 September 2026

v6.1 build `20260928.2`. Canvas lightened to #F4F6F3. The desktop splitter
column is 24px, with card padding and scrollbar allowance balanced against
the map edge. Tabs align with the card edge. The resize and keyboard logic
are unchanged, and expanded map mode removes the extra edge allowance.

Mouse/trackpad desktop layouts retain a slim, quiet scrollbar and stable
scrollbar space. Touch layouts use native scroll indicators without a reserved
gutter. No scrollbar is forcibly hidden and scrolling remains enabled.

115 static checks passed; source comparison confirms that operational and map
scripts are unchanged (only the build identifier changed in configuration).
Rendered spacing and native scrollbar behavior still need device acceptance.

## Final consistency pass, 28 September 2026

v6.1, build `20260928.1`. The build identifier appears in System Status, the phone-accessible Desk Status
panel, and the deployment self-check, without changing the main header version. Future
working packages should increment APP.buildId and keep buildDate aligned with
the file header. Build identity is diagnostic, not a cache invalidation mechanism.

- Desk Status now says Connecting to services until every service confirms;
  it no longer reports All feeds live while a service is still connecting.
- SAR Water now shares Land's guarded copy feedback and retains generated text
  for manual copying on failure. Successful retry closes that recovery output.
- Land/Water generators bind only their own messages. Copy controls avoid
  duplicate listeners when sections are revisited.
- Clinical Advice uses the shared copy feedback and retry behavior, restoring
  its action label. Generated wording is unchanged.
- Both Primary skill rows expose their selected state through aria-pressed,
  including deselection, draft restoration and reset.
- Removed an obsolete selected-pill shadow rule and corrected the in-file
  design guidance to describe individual skill pills.

The accepted visual design, map behavior, calculation rules and data remain
unchanged. Real browser and live-service acceptance are separate from automated
checks; no new rendered or Citrix certification is claimed.

Verification: all 247 automated checks passed across seven suites (115 static,
43 runtime, 56 workflow, 9 offline, 7 asynchronous-state, 6 map-policy and
11 aircraft-advisory). The new workflow checks cover secondary copy recovery,
selected-state accessibility, build identity and connecting-service messaging.
The runtime suite passed before the final status-summary correction; static and
workflow suites were rerun after that correction. No rendered/live certification
is implied. Archive integrity passed.

Earlier results below describe their named passes.

## Phone header action, 28 September 2026

At the existing compact-header breakpoint (700px and narrower), Reset Forms
now occupies the header action position instead of Board View. Wider layouts
retain all existing actions. The existing two-tap confirmation is unchanged:
first tap shows Confirm Reset?, second tap resets; confirmation expires after
12 seconds. No reset logic changed. Static checks passed (115); rendered phone
acceptance remains open.

## IHT/SAR aircraft advisories and FENZ preview, 28 September 2026

- All three workflows now resolve their own location and selected resource for
  the amber Closer aircraft advisory. IHT uses the sending hospital; SAR uses
  its scene. Primary uses its selected base or live aircraft.
- The pill opens the matching Live Aircraft panel and remains advisory only.
  It does not assert availability or change resource selection. Only airborne
  fixes within the existing five-minute response freshness threshold qualify,
  and failed/stale feeds suppress the advisory.
- IHT/SAR selection and reset changes refresh the advisory immediately.
- FENZ LZ Request now has a three-row, vertically resizable preview with an
  accessible label. Longer messages remain scrollable and fully copyable.
- Targeted verification: 115 static, 44 workflow and 11 new advisory checks
  passed. Prior full review passed 224 checks; unaffected suites were not rerun
  for this focused change. Real browser layout and live feed checks remain open.

# AirDesk v6.1 current audit

Reviewed 27 September 2026. Source: newly supplied `AD-Resources-v6.1(1).zip`.
This is the current working version, not a promotion of APP.baseline from v6.0.

## Corrected defects

1. Auto island-label policy could change Topo label visibility. It now runs only
   for Auto/topolite, and its first-paint policy retains stricter native minimum
   zoom levels instead of lowering them to 7.
2. Coordinate and shortcode copies used separate temporary-label handlers with
   inconsistent failure feedback. They now use shared guarded copy feedback;
   icon-only controls preserve their original nodes.
3. SAR generated-message copy failures hid the output needed for manual recovery.
   Failed copies now expose the generated preview; a successful retry hides it.
4. Supporting documents contradicted current rollback, test and deployment
   behavior. Current instructions and audit status are consolidated. An unused
   copied-icon CSS rule was removed.

## Verified scope

`npm test` passed all 224 checks:

| Suite | Passed | Evidence boundary |
| --- | ---: | --- |
| Static | 115 | Parsing, source/configuration, data structure and package rules |
| Runtime | 43 | jsdom initialization and reference content |
| Workflow | 44 | Simulated forms, arithmetic, keyboard eligibility and copy recovery |
| Offline worker | 9 | Mocked fetch/cache failures, ownership and fallback |
| Async state | 7 | Simulated weather loading, stale responses, failure and retry |
| Map policy | 6 | Mocked label-layer API and first-paint minimum zoom rules |

The new upload's header, skill-chip, footer-pill and national-view choices are
preserved. Source comparison confirms no changes to embedded datasets, clinical
calculation rules, generated message wording or Firebase paths in this review.
Archive contents and ZIP integrity are checked before delivery.

## Outstanding acceptance

This is not a completed visual, clinical or production operational sign-off.
Local browser preview was previously rejected by the browser service URL policy
and was not bypassed. No new rendered screenshots, real-browser accessibility
results, deployed service checks or actual Citrix session were obtained.

- Run `npm run test:all` in an authorized browser environment. The packaged Citrix
  viewport profile is not an actual Citrix session.
- Confirm Auto below/above zoom 7 and transitions to Topo/Aerial on device.
- Confirm clipboard denial exposes a selectable SAR message and retry succeeds;
  check coordinate copy feedback and keyboard return focus.
- Follow README production smoke checks for LINZ, live aircraft freshness,
  routing, weather, designated test shared-note saves and CAD outputs.
- Verify online deployment refresh, offline fallback and reconnect. An older
  saved shell may appear during a network timeout or host failure.
- Operational owners still confirm current references and clinical data.

Prior per-pass release history remains in CHANGELOG.md and RELEASE-NOTES.md.
