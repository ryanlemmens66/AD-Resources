import {readFileSync} from 'node:fs';
import assert from 'node:assert/strict';
import {JSDOM} from 'jsdom';
import {APP_FILE} from './lib.mjs';
const html=readFileSync(APP_FILE,'utf8');
const start=html.indexOf('async function showSceneWeather(){');
const end=html.indexOf('\nfunction boot(){',start);
const dom=new JSDOM('<div id="modal" hidden><div id="modal-body"></div></div>',{runScripts:'outside-only'});
const w=dom.window,d=w.document;let count=0;
const check=(name,fn)=>{fn();count++;console.log('PASS '+name)};
try{
 w.eval(`
 const $=id=>document.getElementById(id);
 const CAA_VFR_MINIMA_HTML='<p>Reference retained</p>';
 function windyEmbedHtml(){return ''}
 function civilTwilightEnd(){return null}
 function formatNZTime(){return ''}
 function fieldsFromResponse(){return [['Temperature','12 C']]}
 const requests=[];
 function fetchWeather(){return new Promise((resolve,reject)=>requests.push({resolve,reject}))}
 const AirDesk={primary:{sceneLocation:{getCoordinate:()=>({lat:-36,lng:174})}},ui:{showModal:(title,body)=>{$('modal').hidden=false;$('modal-body').innerHTML=body}}};
 ${html.slice(start,end)}
 window.openWeather=showSceneWeather;window.requests=requests;
 `);
 let pending=w.openWeather();
 check('weather loading state announced',()=>assert.equal(d.getElementById('scene-weather-loading').getAttribute('role'),'status'));
 w.requests.shift().resolve({});await pending;
 check('weather success replaces loading',()=>{assert.match(d.getElementById('modal-body').textContent,/12 C/);assert.equal(d.getElementById('scene-weather-loading'),null)});
 pending=w.openWeather();d.getElementById('modal').hidden=true;w.requests.shift().resolve({});await pending;
 check('late weather success does not reopen closed dialog',()=>assert.equal(d.getElementById('modal').hidden,true));
 pending=w.openWeather();d.getElementById('modal-body').innerHTML='<p>Another dialog</p>';w.requests.shift().reject(new Error('Unavailable'));await pending;
 check('late weather failure cannot replace another dialog',()=>assert.equal(d.getElementById('modal-body').textContent,'Another dialog'));
 pending=w.openWeather();w.requests.shift().reject(new Error('Unavailable'));await pending;
 check('weather failure retains references and offers retry',()=>{assert.ok(d.getElementById('scene-weather-retry'));assert.match(d.getElementById('modal-body').textContent,/Reference retained/)});
 d.getElementById('scene-weather-retry').click();
 check('weather retry starts a fresh request',()=>{assert.equal(w.requests.length,1);assert.ok(d.getElementById('scene-weather-loading'))});
 w.requests.shift().resolve({});await new Promise(r=>setTimeout(r,0));
 check('weather retry recovers successfully',()=>assert.match(d.getElementById('modal-body').textContent,/12 C/));
 console.log(`All ${count} state checks passed (simulated service responses)`);
}finally{w.close()}
