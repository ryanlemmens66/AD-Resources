import { readFileSync } from 'node:fs';
import { runInNewContext } from 'node:vm';
import assert from 'node:assert/strict';
const source = readFileSync('sw.js','utf8');
let count=0;
async function scenario(name, options={}, action){
 const handlers={},deleted=[],stored=[];
 const cached={kind:'cached'},live={ok:true,status:200,clone(){return this}};
 const cache={put:async(k,v)=>{if(options.writeFail)throw Error('quota');stored.push(k)},match:async()=>options.noCache?undefined:cached};
 const context={URL,setTimeout,clearTimeout,fetch:async()=>{if(options.offline)throw Error('offline');return options.response||live},caches:{open:async()=>{if(options.openFail)throw Error('storage');return cache},keys:async()=>['airdesk-shell','airdesk-shell-old','other-app'],delete:async k=>deleted.push(k)},self:{location:{origin:'https://desk.test'},addEventListener:(name,fn)=>handlers[name]=fn,clients:{claim:async()=>{}},skipWaiting:async()=>{}}};
 runInNewContext(source,context);
 await action({context,handlers,deleted,stored,cached,live});
 console.log('PASS '+name);count++;
}
const request={url:'https://desk.test/',method:'GET',mode:'navigate'};
await scenario('live response cached',{},async x=>{assert.equal(await x.context.shellNetworkFirst(request),x.live);assert.deepEqual(x.stored,['/__airdesk-shell'])});
await scenario('cache quota failure preserves live response',{writeFail:true},async x=>assert.equal(await x.context.shellNetworkFirst(request),x.live));
await scenario('unavailable cache preserves live response',{openFail:true},async x=>assert.equal(await x.context.shellNetworkFirst(request),x.live));
await scenario('offline returns saved shell',{offline:true},async x=>assert.equal(await x.context.shellNetworkFirst(request),x.cached));
await scenario('host 503 returns saved shell',{response:{ok:false,status:503}},async x=>assert.equal(await x.context.shellNetworkFirst(request),x.cached));
await scenario('404 is not masked',{response:{ok:false,status:404}},async x=>assert.equal((await x.context.shellNetworkFirst(request)).status,404));
await scenario('offline without saved shell fails visibly',{offline:true,noCache:true},async x=>assert.rejects(x.context.shellNetworkFirst(request),/offline/));
await scenario('activation preserves unrelated caches',{},async x=>{let promise;x.handlers.activate({waitUntil:p=>promise=p});await promise;assert.deepEqual(x.deleted,['airdesk-shell-old'])});
await scenario('live APIs, cross-origin requests and writes are not intercepted',{},async x=>{for(const req of [{...request,mode:'cors'},{...request,method:'POST'},{...request,url:'https://other.test/'}])x.handlers.fetch({request:req,respondWith:()=>assert.fail('unexpected interception')})});
console.log(`All ${count} offline-worker checks passed`);
