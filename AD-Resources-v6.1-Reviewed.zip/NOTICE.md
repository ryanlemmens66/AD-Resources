# Notice — copyright and use

**© Ryan Lemmens and/or Hato Hone St John. All rights reserved.**

Ownership of this work has not yet been settled, and that is deliberate. It was
built for the Hato Hone St John National Air Desk and contains St John's
operational rules, clinical pathways and dispatch geometry, so copyright may sit
with the organisation rather than the author under ordinary employment terms.

**No licence is granted.** This repository has no `LICENSE` file, and the
absence of one is not an oversight. Under copyright, work with no licence is the
*most* restrictive state, not the most open: no one has permission to use, copy,
modify or redistribute it. Distribution of the package does not grant a licence to reuse, modify or
redistribute the work outside the authority under which it is supplied.

If you want to use any part of this, ask first — contact the author or Hato Hone
St John. A licence can only be added once ownership is confirmed, because
granting rights you do not hold grants nothing.

## Third-party components

The deliverable embeds and calls on work owned by others. None of it is covered
by the statement above, and each carries its own terms:

- **MapLibre GL JS 4.5.0** — bundled inline, BSD-3-Clause.
- **DM Sans** (© 2014 The DM Sans Project Authors) and **Roboto Mono** (© 2015
  The Roboto Mono Project Authors) — embedded as woff2 subsets from Fontsource,
  SIL Open Font License 1.1.
- **LINZ Basemaps and LINZ Data Service** — map tiles and the live Powerlines
  WFS layer. Land Information New Zealand licensing and attribution terms apply,
  and required in-app attribution must not be removed.
- **Google Maps Platform** — Routes, Geocoding, Maps JavaScript, Elevation and
  Weather, under the Google Maps Platform Terms of Service.
- **Firebase** — Realtime Database, under the Google Cloud terms.
- **OpenStreetMap / Nominatim** — geocoding fallback only. ODbL, and Nominatim's
  usage policy applies to how often it may be called.
- **Department of Conservation source data** used by the embedded static huts
  and campsites dataset, **NZTA Waka Kotahi** highway and journey data, and
  **Windy** weather embeds — each under its own terms and attribution
  requirements. AirDesk does not currently call the DOC API at runtime.
- **TracPlus** — live aircraft positions, via the operator's own agreement,
  proxied through a Cloudflare Worker.

Operational datasets — landing zones, aviation guidance, clinical pathway
boundaries, hospital and resource locations — derive from approved St John and
third-party sources and follow those sources' terms, not this notice.

## Related status

Operational and technical ownership remains with Ryan Lemmens; formal
transfer only if requested. AirDesk v6.0 was frozen on 2026-09-24 as the Stable
Production Baseline, with v5.56 retained as the immediate rollback release.
Provider/account controls and the TracPlus Worker arrangement were confirmed by
the current owner for this freeze. Browser/device and live-origin verification
are recorded separately from the release package after deployment.

See `README.md` for deployment, credentials and the production acceptance record.
