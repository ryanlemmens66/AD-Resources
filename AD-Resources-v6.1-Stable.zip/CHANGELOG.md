# Release history

Full per-build notes for v5.0–v6.1 are preserved in the earlier release ZIPs
(`AD-Resources-v6.1-Reviewed.zip` and before), kept on the owner's computer.

## v6.1, 2026-09-28 — Stable Production Baseline (build 20260928.15)

Signed off by the owner on 2026-09-28 for official live use at
<https://airdeskresources.netlify.app/>; v6.0 is the rollback release. No
dataset content, clinical rule, calculation, CAD wording, provider key, Firebase
path, storage key or CSP origin changed from v6.0 except as listed below;
`APP.dataVersion` remains `2026.09.24`.

**Operation**

- Map layers: *Hospitals* and *Air Desk Guidance* start on and now stay off when
  switched off (until switched on or the next reload). The layer restore no
  longer stops part-way through a pass, which the old always-on hook had masked.
- Transfers and SAR fit their points on a small map pane (SAR previously fell
  back to the scene alone); the map renders at up to 2x on phones (was 1.5x).
- Fixed the iOS Home Screen launch showing two different screens.
- Build identity in System Status and Desk Status; SAR and Clinical Advice copy
  recovery; IHT/SAR closer-aircraft advisories; FENZ preview; road-time override
  and CAD destination ordering; Auto island-label policy; "What's new" note.

**Presentation**

- One close button, one segmented selection style, flat status chips, a single
  type/radius/shadow scale, embedded DM Sans and Roboto Mono, and a launch
  splash; equal-height Response Plan cards and aligned calculation rows.
- Slim one-row phone header; card-header actions share the title line when
  they fit; Board View title stays on one line on phones; the Heli Status OOS
  reason menu fits "Mechanical"; the form fades under the tab bar on desktop
  and iPad; keyboard focus keeps each control's shape.
- The *Overdue Aircraft* pill pulses as designed (its animation never ran);
  paused on hover and focus, off for reduced motion and in Citrix mode.

**Code and maintenance**

- Stylesheet rebuilt into one definition per component with no legacy
  overrides: rules 1,942 → 1,529, declarations 7,195 → 6,366, media blocks
  65 → 55, `!important` 298 → 96 (all in the categories in ARCHITECTURE.md).
  Dead rules, dead script branches, patch modules, the retired Map Layers panel
  and version history in comments removed.
- Map data moved out of code into JSON data blocks; `tools/data.mjs` exports and
  imports them with validation, id retention and a reviewable diff. The id
  baseline protects 4,947 ids across 13 datasets.
- The approved guideline issue is recorded once for the checks; documentation
  consolidated into README, ARCHITECTURE and this file; the small mocked suites
  merged into `tools/unit-check.mjs`.

**Verification and sign-off**

- `npm run test:all`, the 54-screen visual comparison, and a computed-style
  comparison of every element across 930 recorded states (19 viewports, forced
  hover, focus and active) show only the changes above. Every tab, dialog and
  workflow at 19 screen sizes raises no script error.
- Owner sign-off: content and clinical catalogue entries reviewed 2026-09-28,
  real-device checks complete. Ownership is Ryan Lemmens's unless formally
  handed over; release and rollback ZIPs are kept on the owner's computer.

## v6.0, 2026-09-24 — Stable Production Baseline

Promoted the audited v5.56 candidate. Applied the three operational-data changes
confirmed by the owner (SH6 Haast–Lake Moeraki closure, permanent PARAPARA
adjustment, Waihi Bowling Club replacing Morgan Park) and advanced
`APP.dataVersion` to `2026.09.24`. Recorded the Google, LINZ, Firebase and
TracPlus production attestations.

## v5 series, 2026-09-09 to 2026-09-24

- **v5.48–v5.56:** production audits and handover reconciliation; teal
  scene-to-hospital route; full Axe sweep; phone layout for the guidance dialog;
  dead DOC live-API code removed.
- **v5.30–v5.47:** Tasking & Clinical Guidance rebuilt against the approved
  v2.01 PDF in one inert template, grouped into operator-facing categories,
  including Area Specific Considerations; approved MapIT operational points
  imported; dataset-id retention baseline added. Heli Status gained additional
  aircraft, in-place editing for iPad and priority arrows.
- **v5.22–v5.29:** H-in-ring brand mark; scaling calculation cards; tab labels
  that never wrap; maintainer files blocked from public delivery; documentation
  restructured.
- **v5.12–v5.21:** stylesheet clean-up (always-overridden declarations, dead
  rules and provably unneeded `!important` removed with screenshot proof); map
  toolbar grouped and resized; Shift Notes drag handle; Split-view overflow
  fixes.
- **v5.8–v5.11:** winch recorded as Land/Wets/Decks by Day and Night with type
  colours; DM Sans as the single UI face; full code audit fixes.
- **v5.0–v5.7:** production promotion of v4.7.3; offline shell worker; Chromium
  and Axe checks; deployment self-check and TracPlus stale detection; clinical
  guidance moved into an inert template.
