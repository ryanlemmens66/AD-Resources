# Release history

Full per-build notes for v5.0–v6.1 are preserved in the retained release ZIPs
(`AD-Resources-v6.1-Reviewed.zip` and earlier).

## v6.1, 2026-09-28 — Stable Production Baseline

v6.1 is the Stable Production Baseline for official live use; v6.0 is the
immediate rollback release. No dataset, clinical rule, calculation, CAD wording,
provider key, Firebase path, storage key or CSP origin changed from v6.0 beyond
the presentation work below; `APP.dataVersion` remains `2026.09.24`.

**Build 20260928.10 — code consolidation.**

- Stylesheet rebuilt from its accumulated override layers into one definition
  per component: rules 1,942 → 1,621, declarations 7,195 → 6,451, media blocks
  65 → 57, `!important` 298 → 109 (the remaining uses are listed in
  ARCHITECTURE.md). Removed 53 declarations that could never apply, 84 dead
  rules for retired markup (the standalone Heli Status button, the old Heli
  Status list layout, unused loading states), 20 redundant `[hidden]` rules and
  the inert overdue-pill animation (its keyframes held only `!important`
  declarations, which browsers ignore, so the pill never pulsed). One consistent
  format; comments rewritten without version history.
- Scripts: the map attribution is collapsed by the map manager as the control
  is added (so it no longer shows expanded for the first seconds), replacing a
  separate module that re-applied it on timers; dead branches for the retired
  basemap switcher, Heli Status map button, list layout and events portal
  removed, along with the unused `lzPriorityIcons` alias. Comments rewritten in
  the present tense.
- Two intentional visual fixes: on phones the two-option SAR *Receiving agency*
  grid keeps two columns (it inherited three), and the map *Layers* button shows
  the same hover and press tint as the other toolbar buttons.
- Documentation consolidated into README (deployment and sign-off),
  ARCHITECTURE (maintenance) and this file; RELEASE-NOTES, AUDIT and
  VISUAL-REVIEW retired. The four small mocked test suites merged into
  `tools/unit-check.mjs`; the visual check waits for the *What's new* card so
  its first screen is deterministic.
- Verified with the full `npm run test:all` gate and a computed-style comparison
  of every element across 930 recorded states (19 viewports straddling every
  media breakpoint, plus forced hover, focus and active states): no differences
  other than the two fixes above and properties with no visual effect.

**Build 20260928.9 — freeze.** Fixed the iOS Home Screen launch showing two
different screens (translucent status bar with safe-area insets, launch image
matching the splash tile, no second splash entrance). Repaired the browser gate
at phone size, where the compact header hides the version chip and Board View
by design.

**Builds 20260926–20260928.8 — polish from v6.0.** Header, controls and tokens:
one close button, one segmented selection style, flat status chips, a single
type/radius/shadow scale, embedded DM Sans and Roboto Mono, and the launch
splash. Layout: equal-height Response Plan cards with footers, aligned
calculation rows, Heli Status board header and gutter, Board View column
protection, wide-layout tab alignment, compact timing rows, phone Reset Forms
placement. Function: build identity in System Status and Desk Status; SAR and
Clinical Advice copy recovery; IHT/SAR closer-aircraft advisories; FENZ preview;
road-time override and CAD destination ordering; Auto island-label policy;
"What's new" note.

## v6.0, 2026-09-24 — Stable Production Baseline

Promoted the audited v5.56 candidate. Applied the three operational-data changes
confirmed by the owner (SH6 Haast–Lake Moeraki closure, permanent PARAPARA
adjustment, Waihi Bowling Club replacing Morgan Park) and advanced
`APP.dataVersion` to `2026.09.24`. Recorded the Google, LINZ, Firebase and
TracPlus production attestations.

## v5 series, 2026-09-09 to 2026-09-24

- **v5.48–v5.56:** production audits and handover reconciliation; teal
  scene-to-hospital route; full Axe sweep; phone layout for the guidance dialog;
  dead DOC live-API code removed.
- **v5.30–v5.47:** Tasking & Clinical Guidance rebuilt against the approved
  v2.01 PDF in one inert template, grouped into operator-facing categories,
  including Area Specific Considerations; approved MapIT operational points
  imported; dataset-id retention baseline added. Heli Status gained additional
  aircraft, in-place editing for iPad and priority arrows.
- **v5.22–v5.29:** H-in-ring brand mark; scaling calculation cards; tab labels
  that never wrap; maintainer files blocked from public delivery; documentation
  restructured.
- **v5.12–v5.21:** stylesheet clean-up (always-overridden declarations, dead
  rules and provably unneeded `!important` removed with screenshot proof); map
  toolbar grouped and resized; Shift Notes drag handle; Split-view overflow
  fixes.
- **v5.8–v5.11:** winch recorded as Land/Wets/Decks by Day and Night with type
  colours; DM Sans as the single UI face; full code audit fixes.
- **v5.0–v5.7:** production promotion of v4.7.3; offline shell worker; Chromium
  and Axe checks; deployment self-check and TracPlus stale detection; clinical
  guidance moved into an inert template.
