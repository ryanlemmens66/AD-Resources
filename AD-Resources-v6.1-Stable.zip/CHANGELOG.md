# Release history

## v6.1, 2026-09-28 — Stable Production Baseline freeze

v6.1 build `20260928.9` is adopted as the Stable Production Baseline for
official live use, replacing v6.0 (frozen 2026-09-24), which becomes the
immediate rollback release. `APP.baseline`, the file header, `GOVERNANCE`
release status, README, NOTICE and AUDIT move together. `APP.version` stays
6.1 and `APP.dataVersion` stays 2026.09.24: no embedded dataset, clinical rule,
calculation, generated CAD wording, provider key, Firebase path or CSP origin
changed.

This build fixes the iOS Home Screen launch showing two different screens.
The app now draws under a black-translucent status bar, so the HTML splash
fills the same area as the iOS launch image; the header, map grid row,
expanded map, dialogs and error banner clear the status bar with
`env(safe-area-inset-top)`, which is zero on every other device. The drawn
launch image uses the splash tile's 18px radius and shadow, and the splash no
longer re-animates in over a launch image that already shows it. Two static
checks keep the three aligned.

The browser suite had been failing at phone size because the compact phone
header deliberately hides the version chip and Board View. It now asserts that
design and still exercises System Status and Board View at phone size.

Verification: `npm run test:all` passed — 117 static, 43 runtime, 66
workflow, 9 offline, 7 state, 6 map-policy, 11 advisory and 200 browser
checks. Against build 20260928.8, 51 of 54 visual-regression screens are
unchanged; the three System Status screens differ only in the build and
baseline line.
Live-origin sign-off is recorded in README.md after upload.

v6.1 working builds `20260928.1` to `.8` (27–28 September) are summarised in
RELEASE-NOTES.md: build identity in System Status and Desk Status, SAR and
Clinical Advice copy recovery, phone Reset Forms placement, IHT/SAR closer
aircraft advisories, FENZ preview, wide-layout and card refinements, compact
timing rows, road-time override and CAD destination ordering.

## v6.1, 2026-09-26 — Polish from v6.0, replacing the abandoned 6.1-6.3

### Phone header action, 28 September 2026

At the existing compact-header breakpoint (700px and narrower), Reset Forms
now occupies the header action position instead of Board View. Wider layouts
retain all existing actions. The existing two-tap confirmation is unchanged:
first tap shows Confirm Reset?, second tap resets; confirmation expires after
12 seconds. No reset logic changed. Static checks passed (115); rendered phone
acceptance remains open.

### IHT/SAR aircraft advisories and FENZ preview, 28 September 2026

- All three workflows now resolve their own location and selected resource for
  the amber Closer aircraft advisory. IHT uses the sending hospital; SAR uses
  its scene. Primary uses its selected base or live aircraft.
- The pill opens the matching Live Aircraft panel and remains advisory only.
  It does not assert availability or change resource selection. Only airborne
  fixes within the existing five-minute response freshness threshold qualify,
  and failed/stale feeds suppress the advisory.
- IHT/SAR selection and reset changes refresh the advisory immediately.
- FENZ LZ Request now has a three-row, vertically resizable preview with an
  accessible label. Longer messages remain scrollable and fully copyable.
- Targeted verification: 115 static, 44 workflow and 11 new advisory checks
  passed. Prior full review passed 224 checks; unaffected suites were not rerun
  for this focused change. Real browser layout and live feed checks remain open.

### Updated upload review, 27 September 2026 (same v6.1)

Reviewed the newly supplied ZIP as the working version. Preserved its header,
skill chips, map-footer pills and zoom 4.7 national view. Corrected Auto island
label handling so Topo is untouched and stricter native zoom thresholds remain.
Consolidated coordinate/shortcode copy feedback and restored a manual-copy SAR
message preview when clipboard access fails, with a guarded successful retry.
Removed the unused copied-icon style. No clinical datasets, calculation rules,
generated message wording, button styling or Firebase paths changed.

`npm test`: 224 checks passed (115 static, 43 runtime, 44 workflow, 9 offline,
7 asynchronous-state and 6 map-policy). These include DOM simulations and mocked
services, not rendered or live-service certification. Updated deployment, rollback
and test documentation; AUDIT.md and VISUAL-REVIEW.md now contain current status.
Browser, actual Citrix and deployed-origin sign-off remain outstanding.

### 2026-09-27 desk presentation (same v6.1 identity)

Presentation-only packaging pass before live Netlify upload. Button colours,
datasets, calculations, CAD text, Firebase paths and APP.version are unchanged.

- Header remains 68px. Pine wash, grain and glow hairline sit on the existing
  fill. H-in-ring mark unchanged.
- Auto / topolite-v2 hides Place-Label-Island-4/6/8 below zoom 7 in the style
  JSON and again on load, idle and zoom so country and island names do not
  cover aircraft on first paint. Topo and Aerial are untouched.
- Default and Reset view is zoom 4.7 at [172.8, -41.05].
- Map footer: Live Flight Events; Heli Status Board counts are separate pills.
- Primary skill rows are loose hairline chips on the card (no grey well);
  selected state remains solid green. Guidance stays dashed.
- Tab strip, What's New / Citrix cards, Guidance chrome, scale bar and
  accordion empty-states were reviewed and left as in v6.1.


This is the release that follows v6.0. The original 6.1-6.3 button-colour
exploration was tried, judged to have gone too far and set aside; this entry
folds in the layout, controls, launch and token work built afterwards (staged
along the way as working iterations 6.4 and 6.5, now retired) plus two more
fixes, as one release. Button colours throughout are exactly v6.0's,
untouched, pending a separate decision.

- Layout: Heli Status Board header one colour and a real gutter; Calculation
  Summary rows aligned (subgrid) with "2 min" kept together; Response Plan pills
  share a wrapped line on iPad; Board View Aircraft column never clipped (every
  tail was clipped at 1920 Split and on iPad Wall); short Board View resize grips.
- Controls: one round close button with a drawn X on every dialog; one
  segmented control with a solid green selection (skill pills, CAD times format,
  Standard/Citrix, which no longer uses blue as its selected marker).
- Labels and icons: status chips in one case ("Online", "Error"); Key Questions
  numbered 1, 2, 3; drawn chevron and Reset icon instead of ▾ and ↺.
- Removed the green stripe on every card and SAR tile, and the micro-title that
  repeated the active tab. Header status chips are flat; action buttons keep
  v6.0's look; the divider between them is a visible rule.
- Launch splash with matching iOS launch images; DM Sans and Roboto Mono
  embedded; status bar colour matches the header; loading placeholders for
  weather, road ETAs and SAR lookups.
- One scale for the app stylesheet's literal values: 39 font sizes to 8
  (10/11/12/13/14.5/16/18.5/22px), 20 corner radii to 8, and 46 plain drop
  shadows onto `--shadow-sm/md/lg`. Font weights needed no further change: the
  embedded-font remap above already put them at 400-800 in hundreds.
- A "What's new" note appears once after an update (not on first install or the
  wall board); dismissed with Got it, keyed `whats-new-seen` (the one new
  storage key).
- A Response Plan card's button row is bottom-anchored and the two cards in a
  row are stretched to equal height, so a shorter card opened a gap above its
  button with nothing in it. A divider now sits above the button row on every
  card, turning that space into a footer. The gap between a card's name and its
  detail line is also a little more open.
- Calculation Summary's repeated subtitles ("Time until arrival at scene" etc.)
  are no longer shown -- the icon and bold title already say it -- and are kept
  for screen readers only.
- No change to data, calculations, CAD text, guidance wording, Firebase paths
  or providers. v6.0 is the immediate rollback.

## v6.0, 2026-09-24 — Stable Production Baseline

- Promoted the fully audited v5.56 release candidate to **v6.0 Stable Production
  Baseline**, frozen for production deployment. v5.56 is the immediate rollback
  artifact.
- Applied only the three operational-data changes explicitly confirmed by Ryan
  Lemmens on 2026-09-24: SH6 Haast to Lake Moeraki remains closed until further
  notice; the PARAPARA 30-minute road-time adjustment is permanent; and Waihi
  Bowling Club is active/preferred now with Morgan Park inactive.
- Advanced `APP.dataVersion` to `2026.09.24` and refreshed the protected dataset
  baseline metadata after the approved records were reverified. Feature ids and
  dataset counts are unchanged.
- Set `APP.baseline` and governance release metadata to the v6.0 stable baseline,
  updated package/version/Netlify identity, and preserved all established
  calculation, Tasking & Clinical Guidance, mapping, Firebase, storage and
  provider contracts outside the authorised data changes.
- Recorded the production-owner attestations that Google/LINZ/Firebase account
  controls are in place and that the existing TracPlus Worker arrangement is
  accepted for production. The live-origin device/provider smoke test remains a
  post-deploy acceptance step.
- Corrected the maintenance runtime contract from Node 18+ to **Node 20+** because
  the locked Playwright 1.63 dependency itself requires Node 20 or newer, and
  added a regression check so the declared Node engine cannot drift below the
  locked browser-test requirement again.
- Added stable-baseline/data-version and owner-confirmed operational-record
  regression checks so future editions cannot silently reintroduce the expired
  Haast date, temporary PARAPARA wording, or future-dated Waihi transition.
- Hardened the duplicate-ID audit so it also covers ids on void, script and style
  elements, not only container markup. Removed brittle implementation-count
  figures from current handover prose where the audit itself is the better live
  source, reducing documentation drift in future editions.

## v5.56, 2026-09-24

- Final pre-freeze handover cleanup. No operational calculation, approved
  clinical/guidance wording, protected dataset, Firebase path, storage key,
  provider endpoint or established workflow changed.
- Reconciled current maintainer documentation with the package: the visual
  regression suite is now correctly documented as 18 screens across desktop,
  iPad and phone (54 screenshots), the service catalogue as six providers, and
  current-version references as v5.56.
- Removed the final stale live-DOC wording from `NOTICE.md`; DOC huts/campsites
  are an embedded static source, while LINZ Data Service is now explicitly
  listed as the live Powerlines dependency.
- Standardised Netlify wording everywhere: local `npm run test:all` is the
  authoritative release gate; the configured deploy-side `check.mjs` is an
  additional safeguard only when the chosen Netlify upload path actually runs
  a build.
- Strengthened `tools/check.mjs` so credential ownership covers all four
  expected client configuration values: Google Maps, LINZ Basemaps, LINZ Data
  Service and Firebase. The two LINZ keys must remain distinct; Google Maps and
  both LINZ values must remain single-source; Powerlines must read the canonical
  `runtimeConfig.linzDataServiceApiKey`.
- Added drift guards so current visual-regression counts and the DOC dependency
  description cannot silently become stale again.
- Removed volatile provider price/free-tier figures from the current README.
  The handover now documents stable request/failure behaviour and directs
  maintainers to current provider consoles/documentation for pricing, quotas
  and billing.
- Expanded the production sign-off checklist to include the TracPlus
  Cloudflare Worker ownership/support arrangement and three dated operational
  source records requiring owner confirmation before a long-term frozen
  baseline: SH6 Haast to Lake Moeraki Closure, PARAPARA Drive Time, and the
  Morgan Park LZ / Waihi Bowling Club transition.
- Added a version-agnostic stable-baseline promotion procedure for the next
  formally frozen production release.

## v5.55, 2026-09-24

- Fixed the Tasking & Clinical Guidance dialog sitting hard against the
  right edge on phones. Its width was set as a viewport percentage
  (96vw/98vw) that did not account for the surrounding backdrop's own 16px
  padding, so at narrow widths the dialog was wider than the space actually
  available and ran past the edge. Now sized as calc(100vw - 32px), which
  matches that padding exactly at any width. Desktop and iPad unaffected --
  the same fixed-pixel caps (1360px / 1050px) still apply there.

## v5.54, 2026-09-24

- Final production audit of v5.53. Beyond the three regression suites, ran
  the first full accessibility sweep since v5.29 (Axe, WCAG 2 A/AA, every
  workflow tab, Tasking & Clinical Guidance and Heli Status, at desktop and
  phone width), plus lint, CSS, security-header, service-worker, soak and
  visual checks.
- Fixed three keyboard-access gaps: the guidance content column, wide
  guidance tables on narrow screens, and the Heli Status table on phone could
  scroll but could not be reached by keyboard. Each is now a focusable,
  labelled region.
- Fixed small helper text that failed WCAG AA contrast (4.5:1): the guidance
  search hint (3.19:1), the guidance footer (4.49:1) and the Heli Status
  legend footer (3.37:1). All now use `#5f6f66`, the grey already used for tab
  labels, so no new colour entered the palette.
- A reported contrast failure on the inactive Transfer tab label was traced to
  the sliding tab indicator passing behind it mid-animation; it measures
  correctly at rest and was not changed.
- Refreshed ARCHITECTURE.md's function and listener counts after the v5.53
  DOC code removal. No operational logic, clinical/guidance wording,
  datasets, Firebase paths, storage keys or provider endpoints changed.

## v5.53, 2026-09-24

- Removed genuinely dead DOC (Department of Conservation) live-API code from
  `#airdesk-outdoor-access`: a second embedded API key, `huts`/`tracks`
  endpoint config, `fetchDoc()`, `hutsGeo()`/`tracksGeo()`/`listPayload()`
  converters, marker-icon drawing and click-wiring branches for a `doc-huts`
  layer that `IDS` (`['powerlines']`) could never reach. DOC huts/campsites
  are already served by the existing embedded static dataset; this dead code
  was a second, never-enabled path to the same information, not a working
  feature. Also removed the now-unused `doc` entry from the services
  catalogue, `api.doc.govt.nz` from the CSP `connect-src`, and `'doc'` from
  `tools/verify.mjs`'s tracked-provider list (six providers, not seven).
- Named and documented the LINZ key that was previously hidden as a bare
  base64 string inside the outdoor-access module. It is a real, separate
  LINZ Data Service (WFS) key, distinct from the existing Basemaps tile key
  -- moved into `runtimeConfig` as `linzDataServiceApiKey`, next to
  `linzApiKey`, with a comment explaining why there are two.
- Corrected a factually wrong claim in the runtime-config comment: LINZ's own
  current documentation states a Developer-access key can be restricted to a
  nominated website by contacting LINZ. The comment previously said this was
  "unrestricted by design" with "no console to scope them in" -- neither key
  has been confirmed restricted, and this is now tracked as its own item in
  the README's Production sign-off checklist rather than assumed away.
- Fixed a stale README instruction that told the maintainer to confirm a
  specific hardcoded build-chip version number in the production smoke-test
  step. Reworded to check the chip against the package's own version instead,
  so the instruction cannot go stale at the next release the way this one did.
- Corrected two README claims that Netlify "re-runs the static check on
  upload" / "runs the dependency-free structural check" as a guaranteed
  behaviour. Per Netlify's own current documentation, a manual deploy without
  continuous deployment does not necessarily run a configured build command.
  `npm run test:all`, run locally before the ZIP is created, is now stated as
  the authoritative gate; any Netlify-side check is described as an
  additional safeguard that may or may not run, not something relied on.
- Full audit: ESLint clean across all 75 app script blocks, CSS unchanged in
  validity, no unescaped or insecure patterns, `doc.govt.nz` confirmed absent
  from application JS. 25-cycle soak test showed no growth in DOM size,
  timers, or listeners, zero page errors. All 54 `visual-check.mjs` screens
  match the unmodified v5.52 baseline exactly (no visible-layer change).
- Passed 98 static, 43 jsdom runtime and 147 Chromium checks.

## v5.52, 2026-09-24

- Fixed a real phone-width layout bug in Tasking & Clinical Guidance, reported
  from an actual phone screenshot: the header's version pill overlapped the
  subtitle text, and body content silently ran off the right edge of the
  screen (clipped, not scrolled) rather than wrapping to fit.
- Root cause of the content overflow: three `grid-template-columns:1fr` rules
  (search mode and two narrow-screen breakpoints) used a bare `1fr` track,
  which does not shrink below its content's natural minimum width -- a
  well-known CSS Grid default. Changed to `minmax(0,1fr)`, matching what the
  desktop layout already used for the same column. Verified: zero elements
  now exceed the viewport width at 390px, 360px, or any wider tested size.
- Root cause of the header overlap: a narrow-screen rule pulled the version
  pill out of its already-correct three-column grid position with
  `position:absolute`, floating it over the title text instead of beside it.
  Removed; the pill now sits in the same grid column that already worked
  correctly at every wider breakpoint.
- Added a phone-width (390x844) profile and a Tasking & Clinical Guidance
  capture to `tools/visual-check.mjs`, which previously only ever rendered
  screens at desktop and iPad widths and never once captured this dialog --
  meaning this exact bug class could not have been caught by the existing
  regression suite before now. The baseline grew from 34 to 54 screenshots.
- Confirmed unaffected: desktop, iPad landscape and iPad portrait layouts
  (0 pixel differences beyond anti-aliasing noise), all interactive behaviour
  (tab switching, search, close), and every other test suite. No operational
  logic, clinical/guidance wording, datasets, Firebase paths, storage keys or
  provider endpoints changed.

## v5.51, 2026-09-24

- Final production audit of v5.50 before live operational use. All three
  suites re-run independently (98 static, 43 jsdom, 147 Chromium, all
  passing as delivered), plus ESLint, CSS validation, dead-style,
  security-pattern, guidance-template integrity and soak checks.
- Hardened the v5.50 road-route retry: a genuinely new route now gets a fresh
  retry budget, rather than inheriting whatever an earlier route used up. A
  targeted reproduction showed the app already recovered in the tested case
  through another redraw path, so this is defensive, not a proven fault.
- Removed the one confirmed-dead style rule (`.tg-source-copy`, left over from
  the raw-text guidance block rebuilt at v5.44). Kept `.tg-rule-skill` and
  `.tg-rule-hospital`, which a static scan flags as unused but the guidance
  renderer applies at runtime to colour every time-saving badge, and added a
  comment beside them so a future clean-up does not remove them.
- Re-verified every numeric claim in the maintainer docs against the running
  app. No operational logic, clinical/guidance wording, datasets, Firebase
  paths, storage keys or provider endpoints changed.

## v5.50, 2026-09-24

- Changed the real scene-to-hospital driving route from ochre/brown to a solid
  teal (`#008a8f`) with the existing white halo, keeping it visually distinct
  from underlying map roads, the blue dashed direct operational line, and
  red/amber alert semantics.
- Fixed route recovery after a transient Google Routes failure: pressing Enter
  on the already-resolved scene now retries the response route calculation
  without re-geocoding the address or resetting manual resource/calculation
  choices. Re-entering the same direct coordinate behaves the same way.
- Hardened route drawing across map-style transitions. A valid fetched polyline
  is retained and retried for up to 20 seconds while the MapLibre style becomes
  ready, in addition to the existing `style.load` redraw path.
- Added static regression checks for the teal route role, same-scene route retry
  and style-readiness retry, then completed the production audit and packaging
  checks. No operational timing rules, clinical/guidance content, datasets,
  storage keys, Firebase paths or provider endpoints changed.

## v5.49, 2026-09-24

- Completed the final Digital & Data style handover review of application code,
  deployment configuration, service worker, test tooling and maintainer documentation.
- No further runtime refactor was justified. The application remains functionally
  unchanged from v5.48 apart from release identity.
- Replaced the README's accumulated resolved/open-decision section with a concise
  production sign-off checklist covering Google restrictions, Firebase rules,
  deployed smoke testing and formal ownership/support transfer.
- Removed stale GitHub/repository wording from NOTICE and clarified that the
  remaining pre-deployment items are external governance/environment controls,
  not unresolved application defects.

## v5.48, 2026-09-24

- Completed the final production-readiness audit from v5.47 with no changes to
  approved operational behaviour, calculations, clinical/guidance content,
  mapping data, Firebase paths, storage/privacy behaviour or provider endpoints.
- Rechecked JavaScript/HTML structure, CSS validity and duplication, protected
  datasets, service-worker boundaries, Netlify deployment/security configuration
  and release metadata. No further broad application refactor was justified.
- Tidied maintainer-only comments, standardised verification setup on `npm ci`,
  and added a static guard requiring README, ARCHITECTURE, CHANGELOG and
  RELEASE-NOTES to identify the same current edition as `APP.version`.
- The release remains one source-of-truth HTML file with `sw.js` and the existing
  maintenance/test files alongside it. The version chip and deployment rewrites
  now identify v5.48.

## v5.47, 2026-09-24

- Completed the final maintenance/handover consolidation pass. Removed the
  duplicated Tasking & Clinical Guidance maintenance section from `README.md`
  and replaced it with one current update route covering the inert template,
  source metadata, core document catalogue, all three regression suites and
  cross-module review when a replacement PDF changes other owned content.
- Reconciled stale documentation figures against the package: eight protected
  dataset entries with 3,693 feature ids, 15 external CSP `connect-src`
  entries plus `self` (with 11 fetched origins currently discovered by the
  static audit), and refreshed the architecture size/structural notes.
- Corrected the exported `APP.buildDate` to the release date and added a static
  guard requiring it to match the file-header build date, preventing this
  metadata from drifting silently on a future version bump.
- Reviewed the shipped tools and application structure for safe consolidation.
  The separate static, jsdom, Chromium and visual suites have distinct jobs and
  already share common helpers; no additional tool merge or broad application
  refactor was justified. No operational logic, clinical/guidance wording,
  mapping data, Firebase path, storage key or provider behaviour changed.
- Dependency-free static audit passed all 94 checks on the final v5.47 package.

## v5.46, 2026-09-24

- Added the complete approved **Area Specific Considerations** source section
  5.0-5.14 (pages 51-61) to Tasking & Clinical Guidance as one seventh
  operator-facing category. This includes Auckland, Hauraki Gulf/Waiheke/
  Kawau/Great Barrier, Coromandel/Cathedral Cove, Matakana, Taranaki oil and
  gas, Tairāwhiti, Marlborough Sounds, Aoraki/Mt Cook, Otago, Fiordland,
  Rakiura Stewart Island, Chatham and Sub Antarctic Islands, and the issued
  Ski Field Information table.
- Kept the guidance architecture single-source: wording remains in the inert
  guidance template, with source section/page manifest and the existing PDF
  SHA-256 updated only for coverage (the source PDF itself is unchanged).
- Extended static, jsdom and Chromium checks so the Area Specific category,
  its section sequence and several high-value source phrases cannot silently
  disappear in a later edit. No calculation, map dataset, Firebase path,
  storage key or external-provider behaviour changed.

## v5.45, 2026-09-23

- Consolidated Tasking & Clinical Guidance from 11 categories to 6, following
  feedback that 11 was still overwhelming after the first pass at v5.44. This
  time grouped by what an operator is actually trying to do, not by which
  source sections happen to sit near each other: Clinical Conditions kept
  alone (uniquely large, most-referenced); ANTS Criteria & Specific Skills;
  Tasking, Landing & Destinations (execution mechanics); Escalation,
  Coordination & Major Incidents (when things get bigger); Other Agencies &
  RCCNZ Advice (who else is involved); Principles & Definitions (reference).
  No content removed -- every section from all nine merged categories is
  still present and independently reachable, in a readable order.
- Caught and fixed, before shipping: several leftover checks in
  `tools/verify.mjs` and `tools/browser-check.mjs` still referenced category
  ids removed at v5.44/v5.45 (clicking a tab button that no longer exists),
  giving a plausible-looking failure rather than an obvious error. Found by
  grepping all three test files for every old category id after the merge,
  not by re-running the suite once and stopping at the first clean result.
- Full audit: ESLint clean across all 75 app script blocks, CSS unchanged in
  validity, no unescaped or insecure patterns, all HTML tags in the rebuilt
  content balance. 25-cycle soak test showed no growth in DOM size, timers,
  or listeners, zero page errors. All 34 `visual-check.mjs` screens match
  the unmodified v5.44 baseline exactly.
- Passed 91 static, 42 jsdom runtime and 144 Chromium checks.

## v5.44, 2026-09-23

- Fixed a real, pre-existing bug in Tasking & Clinical Guidance: section 3.1
  Access Criteria Guidance (and its subsections 3.1.1-3.1.3, which did not
  exist as their own navigable sections at all) rendered as an unformatted
  wall of raw text -- no bullets, no tables, sections 3.1.1/3.1.2/3.1.3
  invisible to the "In this category" navigator and to precise search.
  Rebuilt as properly structured sections matching every other part of the
  guidance module. Caught and preserved a genuine quirk in the source PDF
  along the way: the SAROP coordination table appears twice in the
  guideline, worded slightly differently each time; this occurrence was
  transcribed exactly as it appears on its own page, not copied from the
  other.
- Consolidated the guidance module from 15 categories to 11, following
  feedback that the tab strip had become overwhelming: General Principles
  folded into Definitions (now "Principles & Definitions"), Hospital
  Destinations into Landing Sites (now "Landing & Hospital Destinations"),
  Other Resource Requests and Tasking for Another Agency merged into one
  category ("Other Agencies & Resources"), and Coordination Frameworks
  folded into Escalation & Review (now "Escalation & Coordination"). No
  content removed; every section from all five is still present and
  independently reachable, in its original relative order.
- The guidance search bar no longer sits in an 920px-wide column with
  visible empty margin on either side inside a dialog that opens up to
  1360px wide; it now fills the same width as the category tab strip above
  it.
- The Board View map/Windy divider (previously available only in Split
  mode) now also works when showing just the map or just Windy: drag to
  resize the fleet table against whichever is showing, on desk or wall.
  Reuses the same handle, CSS variable and drag logic Split mode already
  had, rather than a new mechanism.
- Full audit: ESLint clean across all 75 app script blocks, CSS has no
  parse errors, invalid declarations or always-overridden rules, no
  unescaped or insecure patterns, all HTML tags in the rebuilt content
  balance. 25-cycle soak test showed no growth in DOM size, timers, or
  listeners, zero page errors. Visual regression against the unmodified
  v5.43 baseline changed exactly the four Board View screens the divider
  affects and nothing else.
- Passed 96 static, 46 jsdom runtime and 156 Chromium checks.

## v5.43, 2026-09-23

- Tasking & Clinical Guidance expanded from 10 to 15 categories: General
  Principles (2.0-2.2), Hospital Destinations (6.0-6.1), Other Resource
  Requests (7.0-8.0), Tasking for Another Agency (12.0-12.3, including a new
  Recognised Hospital Facilities table), and Coordination Frameworks
  (13.0-14.0 and 18.0-18.1 -- CIMS, Police/RCCNZ SAR authority, and Ambulance
  Centre coordination). All five verified word-for-word against the source
  PDF; one table's columns were confirmed by reading the rasterised source
  page directly, since plain text extraction garbles multi-column tables.
- Section 12.2.2's maternity-facilities table is the same table already
  shown under Clinical Conditions at 4.25.1; it is referenced there rather
  than duplicated, so the two copies cannot drift apart on a future update.
- Two real bugs caught and fixed during the build, before anything shipped:
  a key-order mismatch in check.mjs's category-map expectation (JSON.stringify
  is order-sensitive; the fix's own documentation now warns about this), and
  a reused `data-tg-keep-table` marker that collided with the existing
  maternity-table uniqueness check.
- Updated all four places a guidance change touches, per the route documented
  at v5.42: template metadata, and matching assertions in check.mjs,
  verify.mjs and browser-check.mjs.
- Area Specific Considerations (source section 5, ~11 pages across 14 named
  locations) remains the one substantial gap against the full source
  document -- confirmed valuable on review, deliberately left for its own
  pass rather than rushed alongside five other additions in one release.
- Full audit: ESLint clean across all 75 app script blocks, CSS unchanged
  (no new rules), no unescaped or insecure patterns, all HTML tags in the
  new content balance. 25-cycle soak test showed no growth in DOM size,
  timers, or listeners, zero page errors. All 34 `visual-check.mjs` screens
  pixel-match the unmodified v5.42 baseline.
- Passed 99 static, 47 jsdom runtime and 159 Chromium checks.

## v5.42, 2026-09-23

- External audit of v5.41 against the actual source PDF (SHA-256 confirmed
  identical to the pinned fingerprint) and a full independent re-run of
  every check, rather than trusting the self-reported v5.38-v5.41 notes.
  Two real maintainability gaps found and fixed; nothing else changed.
- Map data: 18 of 274 Air Desk Guidance features (the 12NM limit line and
  all 17 major-trauma rings) had no `properties.id` at all, so they sat
  completely outside the id-retention safety net described in the map
  update contract. All 18 now have stable ids following the existing
  naming convention; no name, coordinate, or behaviour changed.
- Map data protection: `airdesk-aviation-guidance` holds two unrelated
  datasets (405 IFR Route features, 274 Air Desk Guidance features) that
  were baselined as one combined bucket. This let a large id loss from the
  smaller, actively-maintained Guidance set hide behind the larger, static
  IFR set and never trip the 90% retention floor -- confirmed by simulating
  a 22% id loss in Guidance alone, which the old combined check missed and
  the new split check correctly fails. `tools/dataset-baseline.mjs` and
  `tools/check.mjs` now track and diff the two datasets independently.
- Guidance maintainability: despite the v5.40 changelog's claim, no
  procedure for replacing the whole Tasking & Operating Guidelines existed
  anywhere in the file header or README. Written now: the four places a
  future PDF replacement must touch (template metadata, the core document
  catalogue entry, and the independently-maintained assertions duplicated
  across check.mjs, verify.mjs and browser-check.mjs), plus a plain-language
  account of which of the source's 21 sections the module does and does not
  cover, for the desk to confirm scope is still right before the next update.
- Two new guidance sections (Landing Sites 11.0, RCCNZ Clinical Advice 21.0)
  independently verified word-for-word against the source PDF: complete and
  accurate. The section 4.14 duplicate (Trauma - Burns / Non-Traumatic
  Haemorrhage) is confirmed present in the source PDF's own table of
  contents and section 4 -- the issuing authority's numbering, not a
  transcription error, and documented as such rather than altered.
- Independently re-verified (not just re-read from the changelog): the
  aviation-rules consolidation has no remaining duplicate km-to-NM literal;
  the document catalogue correctly labels the source v2.01 · 15 May 2026;
  the Winch display change matches its description in both live and Edit
  views; the v5.37 pool-base typed-callsign fix still holds.
- Fixed a stale static build-version chip and package-lock.json version that
  the version bump itself had missed, caught by the existing version-
  agreement check rather than shipped and found later.
- Full audit: ESLint clean across all 75 app script blocks, CSS has no
  parse errors, invalid declarations, or always-overridden rules, no
  unescaped or insecure patterns. 25-cycle soak test showed no growth in
  DOM size, timers, or listeners, zero page errors. All 34 screens
  pixel-match a baseline taken from the unmodified v5.41.
- Passed 88 static, 42 jsdom runtime and 144 Chromium checks.

## v5.41, 2026-09-23

- Approved mapping-source import and final production audit. Merged the 11 MapIT 8C rafting evacuation sites, 16 MapIT 8D Makara Peak evacuation/pickup sites and 9 MapIT 8F Taranaki Basin oil/gas points into the existing `Air Desk Guidance` dataset, rather than adding three new map toggles or overlay layers.
- Retained the existing 17 Major Trauma **40 km road-distance** rings exactly as the operational trauma-ring set. The separate 40-minute trial rings were explicitly not imported. Airstrips and Jet A1 fuel also remain deliberately excluded because they are not used operationally in this app.
- Added stable source-specific ids and provenance on the 36 imported points, updated the canonical mapping manifest/counts, regenerated the approved dataset-id baseline, and added regression checks that fail if the selected MapIT groups disappear or 40-minute trauma-ring data is introduced.
- Improved the dataset-baseline generator so future approved map imports stamp their generation date and current app version automatically rather than carrying historical metadata.
- Re-ran the full production audit after the import. No Tasking & Clinical Guidance wording, timing rules, calculations, Firebase paths, Heli Status behaviour, storage keys, provider endpoints or unrelated map datasets were changed.
- Verification: 88/88 dependency-free structural checks passed after the approved dataset baseline was regenerated; the exact HTML assembled without page errors at desktop, iPad landscape, iPad portrait and Citrix-sized Chromium profiles; the additional-aircraft/map-identity workflow passed; CSS parsed with zero errors; and the original 238 Air Desk Guidance features were byte-for-byte unchanged before the 36 approved additions.

## v5.40, 2026-09-23

- Final production-readiness audit release. No approved operational wording, clinical/tasking content, map datasets, Firebase paths, storage keys or established workflows were changed.
- Consolidated the remaining duplicated aviation fallback literals onto `AirDesk.rules`: km-to-NM conversion, default takeoff allowance, cruise-rate fallback and airborne threshold now resolve from the same maintained configuration used by Primary, IHT, SAR and live-aircraft calculations.
- Corrected the core document catalogue so Tasking & Operating Guidelines identifies the embedded approved source as `v2.01 · 15 May 2026` with its review date, instead of the stale pre-guidance baseline label.
- Expanded the in-file and README maintenance contract for the three recurring update paths: mapping/reference-data replacement, whole Tasking Guidelines replacement, and operational timing/default changes. Each route now names the owning module and explicitly forbids duplicate overlays or downstream override patches.
- Strengthened the dependency-free audit to guard those contracts, including canonical timing/default consumption, a single km-to-NM literal, guideline catalogue metadata, map-data update documentation and the single timing-update route.
- Production verification: 82 structural checks passed; the exact HTML assembled in system Chromium at desktop, iPad landscape, iPad portrait and Citrix-sized viewports with valid configuration, complete namespaces, all ten guidance categories, Heli Status live/edit Winch states and no page errors. Additional-aircraft persistence and map identity were exercised directly. CSS parsed with zero errors. Direct localhost navigation and npm dependency installation were blocked by this execution environment, so the packaged jsdom/Playwright navigation suites were not represented as freshly rerun.

## v5.39, 2026-09-23

- Finalised Heli Status Winch presentation without changing capability data: live Heli Status and Board View now show only active Land/Wets/Decks chips for each period, while Day and Night remain explicit at all times.
- A Day or Night period with no active capability now shows a quiet **No Winch** badge. If the aircraft has no winch capability in either period, both `Day · No Winch` and `Night · No Winch` are shown so absence cannot be mistaken for missing data.
- Edit mode is deliberately unchanged and still shows all six Day/Night L/W/D toggles, including inactive dashed states, so capability entry remains one tap away. Existing SVG icons, Land/Wets/Decks colours, flight-rule styling, Firebase data, storage keys, additional-aircraft behaviour and anti-jump editing are unchanged.
- Added regression coverage for active-only live Winch rendering and explicit per-period No Winch states.

## v5.38, 2026-09-23

- Expanded the single-source Tasking & Clinical Guidance viewer with Landing Sites (11.0-11.2), Call Sign Management / Airframe Changes (17.9-17.9.1), Major Incidents (19.0-19.2), and RCCNZ Requests for Clinical Advice (21.0), all sourced from the supplied v2.01 guideline.
- Rebuilt the guidance presentation in its owning component: integrated branded heading bar, rectangular icon category navigation, clearer section hierarchy, more readable source tables/lists/callouts, and improved iPad/desktop spacing. No guideline content is duplicated elsewhere in the app.
- Extended the pinned guidance manifest so future whole-guideline updates compare the added section/page ranges against the same v2.01 PDF fingerprint.
- No operational calculations, Firebase paths, storage keys, maps, approved datasets, Heli Status behaviour, or provider endpoints changed.

Each edition is preserved as `AD-Resources-vx.x.zip`. Release numbers describe
the packaged application, not a source-control branch.

## v5.37, 2026-09-23

- Fixed a defect in Heli Status additional aircraft: on every pool-based base
  (Auckland, Whangarei, Christchurch, Dunedin, Queenstown, Nelson) the
  callsign field was a dropdown locked to that base's own numbered pool, so
  a borrowed aircraft's real callsign could not be entered at all. It is now
  a typed field on every base, as intended.
- Typed callsigns are now cleaned to letters, digits and hyphen as you type,
  matching how tail numbers are already cleaned; a stray space or punctuation
  no longer survives into the shared board.
- Fixed a silent bug where focus never moved to the new callsign field after
  adding an aircraft. Two `.airdesk-hsb-panel` elements exist in the DOM at
  once and the unscoped selector always matched the hidden one; it now
  targets `.airdesk-hsb-panel.open`, matching the convention already used
  everywhere else in this module.
- Independently re-verified the v5.36 tail-formatting fix, the aircraft-type
  memory, the 3-aircraft cap, delete-with-confirmation, Board View
  projection and TracPlus identity lookup for additional aircraft; all
  confirmed working by direct testing, not only by the packaged test suite.
- Reviewed Tasking & Clinical Guidance: content, search, category switching
  and responsive layout confirmed working correctly; the two claimed
  cross-section fixes (Metabolic out of Sepsis, Vascular out of Anaphylaxis)
  independently reconfirmed. Found and flagged (not altered, since the
  source PDF cannot be checked from here) a duplicate section number:
  4.14 is used for both "Trauma - Burns" and "Non-Traumatic Haemorrhage".
  This does not affect navigation or search, which key off unique element
  ids, but is a real citation ambiguity worth checking against the source.
- Full audit: ESLint clean across all app script blocks, CSS has no parse
  errors, invalid declarations or always-overridden rules, no unescaped
  feed- or user-supplied values, no insecure patterns. 25-cycle soak test
  (including the guidance dialog) showed no growth in DOM size, timers or
  listeners, zero page errors. All 34 screens pixel-match the pre-fix
  baseline.
- Passed 66 static, 38 jsdom runtime and 126 Chromium checks.

## v5.36, 2026-09-23

- Completed a full production audit across application structure, JavaScript parsing, HTML/ID integrity, CSS parsing/cascade hygiene, datasets, deployment rewrites, service worker, Heli Status editing/sync, Board View, Tasking & Clinical Guidance, and responsive browser behaviour.
- Fixed an idempotency defect in Heli Status tail formatting. A registration that passed through the formatter more than once could become `ZK-ZK-XYZ`, which prevented the additional-aircraft row from owning the expected live-map callsign for `ZK-XYZ`. Tail input now canonicalises repeated or missing prefixes to one `ZK-` prefix.
- Added dependency-free regression coverage for tail canonicalisation and strengthened the real-browser additional-aircraft check to assert the persisted tail itself, map callsign resolution and Board View projection.
- Removed a stale hard-coded `AirDesk-v5.6.html` URL from the jsdom verifier; it now uses the discovered current `APP_NAME`, matching the rest of the version-independent tooling.
- Re-measured and corrected handover documentation metrics. No operational rules, approved datasets, Firebase paths, storage keys, calculations, clinical/tasking guidance, provider endpoints or established workflows changed.

## v5.35, 2026-09-23

- Fixed Heli Status live-mode filtering so a persistent user-added aircraft remains visible after pressing Done even when its tail has not yet been entered.
- Configured empty roster slots remain hidden exactly as before.
- Additional rows no longer inherit a fixed base's default callsign when their own callsign is blank.
- No Firebase path, storage key, map identity rule, capability model or configured roster slot behaviour changed.

## v5.34, 2026-09-23

- Added persistent **Additional** aircraft rows to the Heli Status Board. In Edit mode each base can add up to three temporary extra aircraft, which remain until deliberately deleted.
- Additional aircraft use the existing Heli Status state and Firebase record, so they sync across desks and participate in the same tail-to-callsign identity lookup used by the live map.
- Added optional **Aircraft Type** metadata to Heli Status. Type syncs with the slot and is remembered locally by tail for easier repeat entry.
- Board View projects aircraft type with the existing Aircraft identity, without adding another wide wall-board column.
- Preserved v5.33 stable-edit behaviour: routine callsign, tail, type, FLT, OOS and winch edits do not rebuild native controls mid-interaction.
- Added regression checks covering the additional-row model, shared-sync capacity and identity/type integration.

## v5.33, 2026-09-23

- Stabilised Helicopter Status Board editing on iPad, desktop and Citrix by keeping routine edit controls mounted instead of rebuilding the full table after each selection.
- Callsign, tail, flight-rule, OOS and winch changes now update their existing row/control in place. Structural redraws are reserved for entering/leaving Edit mode, row reordering and opening/closing board setup panels.
- Optimistic Firebase echoes that already match local state no longer redraw the board. Genuine remote changes still merge immediately; while Edit mode is open their structural redraw is deferred until the editor closes.
- The 15-second live refresh now updates status/count projections in place during Edit mode, avoiding native select and touch-button disruption. Added browser regressions that verify winch and flight controls keep the same DOM node across edits and background refresh.

## v5.32, 2026-09-23

- Completed a full visual pass of **Tasking & Clinical Guidance** while preserving all approved guidance content and functionality.
- Reduced the heavy stacked-green treatment with a lighter provenance header, refined search and category controls, improved card hierarchy, clearer Skill/Hospital threshold accents, and more polished spacing and typography.
- Added a dedicated desktop **On this page** navigator with live active-section highlighting; iPad portrait keeps the compact navigation-free reading layout.
- No guideline wording, source map, calculations, provider integrations, persistence keys, datasets or operational workflows changed. All 57 static checks pass.

## v5.31, 2026-09-23

- Replaced the standalone Clinical Conditions reference with one premium **Tasking & Clinical Guidance** modal, opening to Clinical Conditions by default and adding Specific Skills, ANTS, Tasking Methods, Escalation & Review, and Acronyms & Definitions.
- The complete National Air Desk Tasking & Operating Guidelines v2.01 PDF is now the maintenance source for the mapped reference sections. One inert HTML template holds the issued content, with version/date metadata, source ranges and the full-PDF SHA-256 fingerprint.
- Restored section 4.29 Specific Skills from the complete guideline while retaining the v5.30 Clinical Conditions corrections and 4.25.1 maternity table. Search works across all six categories, with desktop section navigation and responsive tablet layouts.
- Added regression checks for the guidance source map, category/section coverage, source metadata, clinical section boundaries, Specific Skills and cross-category search. No calculation, mapping, provider, persistence or operational workflow logic was changed.

## v5.30, 2026-09-23

- Rebuilt Clinical Conditions Guidance against the supplied approved version
  2.01 PDF (approved 15/05/2025), preserving issued wording and numbering.
- Corrected two substantive cross-section mappings: Metabolic disorder
  thresholds are no longer grouped under Sepsis, and Vascular thresholds are
  no longer grouped under Anaphylaxis.
- Restored the source 4.0 general guidance and 4.25.1 Secondary & Tertiary
  Maternity Facilities table, returned Pregnancy & Birthing to source order,
  and removed the app-only 4.29 section because it is absent from the supplied
  approved source.
- Added source metadata/fingerprint and regression checks so future replacement
  PDFs can be transcribed into one inert template without duplicating clinical
  content in executable JavaScript.
- Verification: all 44 dependency-free static checks passed; the rebuilt
  guidance opened and transformed correctly in isolated Chromium with zero page
  errors, including iPad portrait and landscape overflow checks.

## v5.29, 2026-09-22

- Final production audit before live testing. No functional change.
- Netlify now returns 404 for the maintainer files the site was publishing
  (README, CHANGELOG, RELEASE-NOTES, ARCHITECTURE, NOTICE, package files,
  netlify.toml and tools/); they remain in the ZIP. The app, sw.js and the
  NZTA proxy are unaffected.
- Removed a leftover style rule that drew a cramped circle around the Heli
  Status pill's helicopter icon (from the old crosshair glyph); the icon now
  matches the approved design.
- Escaped the Pathways "no destination" message (defence in depth).
- Audit results: ESLint and CSS clean apart from documented items; no dead or
  overridden CSS; every feed- or user-supplied value escaped before HTML;
  CSP covers every service the app calls; update path confirmed network-first
  with revalidation; 30-cycle soak and a 3-hour simulated run showed no growth
  in DOM, timers or listeners.
- Passed 37 static, 29 jsdom runtime and 69 Chromium checks.

## v5.28, 2026-09-22

- Brand identity: the medical-plus mark is replaced by the Air Desk H-in-ring
  (uppercase white H centred in a white ring on #1F6B2A) in all four places:
  header brand mark, SVG favicon, 192x192 PNG icon and 180x180 Apple touch
  icon. Header tile size, position and spacing unchanged.
- Passed 37 static, 29 jsdom runtime and 69 Chromium checks.

## v5.27, 2026-09-22

- Calculation cards: helicopter and road icons redrawn as a matched outline
  pair. Times now scale with their card, so they fit on every screen; they
  previously overflowed at 1366px and below (on iPad "62 min" and "~40 min"
  ran into each other).
- Map pills: one type size; Heli Status shows a helicopter icon and plain
  counts (21 On Base | 1 Off Base | 0 OOS) with the numbers coloured instead
  of bordered chips; "Live Flight Events" shortened to "Flight Events" (full
  name kept for screen readers); the black map-credits button is now a quiet
  outlined info icon.
- Desk Status summary is a toned status box (green all live, amber naming
  what is unavailable, red offline) instead of a plain text box.
- Passed 37 static, 29 jsdom runtime and 69 Chromium checks.

## v5.26, 2026-09-22

- Tab labels never wrap: below a 630px tab bar (iPad landscape, 1280px
  laptops, Split view) the Search & Rescue tab shows "SAR" instead of
  breaking onto two lines. Screen readers still hear "Search & Rescue".
- Passed 37 static, 29 jsdom runtime and 69 Chromium checks.

## v5.25, 2026-09-22

- Documentation only, for handover review; the app is unchanged apart from
  its version number.
- README: replaced the 45-line accumulated status box with a short current
  status; added *Start here* (reading order, things that look wrong but are
  deliberate, and what to update if ownership moves).
- ARCHITECTURE.md brought up to date from v5.6: current file name, sizes and
  counts re-measured, the stylesheet findings updated for the v5.12-v5.21
  clean-up, the visual check documented, and a wrong "no inline handlers"
  claim corrected (the font loader's `onload` is the one exception).
- Passed 37 static, 29 jsdom runtime and 69 Chromium checks.

## v5.24, 2026-09-22

- Maintenance consolidation, no app behaviour or visual change. The file
  header went from 29 KB (473 lines) to 7 KB (111 lines): per-release notes
  moved verbatim to the new RELEASE-NOTES.md, replaced by a short Standing
  design decisions section.
- Shipped the screenshot comparison used since v5.12 as
  tools/visual-check.mjs (npm run visual:baseline / visual:compare).
- Removed an unused, shadowed SAR helper; merged one last split style rule.
- Passed 37 static, 29 jsdom runtime and 69 Chromium checks; all 34
  screenshots match v5.23.

## v5.23, 2026-09-22

- Heli Status Edit mode: up/down arrows on multi-aircraft bases swap an
  aircraft's priority in one tap (callsign, tail, capabilities and OOS move
  together), replacing the park-off-duty workaround.
- NRES callsigns remember their last tail (per desk, learned from the synced
  board) and fill it in when picked, unless that tail is already in use;
  typing a new tail updates the memory.
- Edit-mode column widths rebalanced; fixed winch toggles clipping at 1024px.
- Passed 37 static, 29 jsdom runtime and 69 Chromium checks.

## v5.22, 2026-09-22

- Shift Notes drag handle moved into the gap between Shift Notes and
  Helicopter Change Process, styled like the workflow/map splitter.
- Passed 37 static, 29 jsdom runtime and 69 Chromium checks.

## v5.21, 2026-09-22

- Stylesheet clean-up: removed 56 !important flags across eight small
  components. Pixel-identical across all 34 app screenshots.
- Kept the quiet-button modifier after verification showed it is needed
  (the Times Breakdown button would otherwise turn solid green).
- Broad !important sweep closed: the remaining flags are intentional
  base-plus-modifier overrides in dialogs and per-tab layout, best tidied
  when those components are next changed.
- Passed 37 static, 29 jsdom runtime and 69 Chromium checks.

## v5.20, 2026-09-22

- Stylesheet clean-up phase 2, map layers picker: removed 25 !important
  flags proven to have no real competition. Verified pixel- and
  computed-style-identical across active, inactive and disabled rows.
- Attempted the same for the reference-sheet component (Fixed-Wing
  Transfers, Recognised Hospital Facilities, and others) and reverted it:
  verification caught a real colour regression in the Fixed-Wing table
  header that the check had wrongly called safe. Root cause not fully
  identified; this widely-shared component needs manual, one-at-a-time
  review rather than the bulk check used elsewhere.
- Passed 37 static, 29 jsdom runtime and 69 Chromium checks.

## v5.19, 2026-09-22

- Stylesheet clean-up phase 2, map type menu: removed 26 !important flags
  proven to have no real competition, after correcting the checking method
  to compare exact selectors rather than shared class names. Left 14 alone
  where the menu's position genuinely competes across three breakpoints.
- Verified computed styles and screenshots identical at four widths spanning
  both breakpoints, and in Windy mode.
- Passed 37 static, 29 jsdom runtime and 69 Chromium checks.

## v5.18, 2026-09-22

- Stylesheet clean-up phase 2 trial: removed 98 !important flags from the
  Hospital Capabilities popup, each proven (not just tested) to have no
  competing rule anywhere in the stylesheet. Verified pixel-identical across
  15 hospitals and every section colour.
- Passed 37 static, 29 jsdom runtime and 69 Chromium checks.

## v5.17, 2026-09-22

- Main map toolbar resized to match the zoom stack: 40px buttons, 17-18px
  icons, same glass finish as before, just smaller.
- Passed 37 static, 29 jsdom runtime and 69 Chromium checks.

## v5.16, 2026-09-22

- Shift Notes drag handle made smaller and more discreet (narrower, thinner,
  lighter at rest); the tappable bar itself is the same relative size.
- Passed 37 static, 29 jsdom runtime and 69 Chromium checks.

## v5.15, 2026-09-22

- Fixed the real cause of the SPLIT-view overlap: the fleet pane had no
  min-width, so it overflowed its grid track (and the v5.14 fix) whenever the
  pane was narrower than the table's own minimum width.
- Added a drag handle below the Shift Notes box on the Resources tab, with
  its own saved height, since the native corner resize grip was hard to use
  on iPad. Hidden automatically inside Board View.
- Passed 37 static, 29 jsdom runtime and 69 Chromium checks.

## v5.14, 2026-09-22

- Fixed: grouped map toolbar could overflow the map pane into the Windy pane
  in SPLIT view on a narrow window (reported on iPad Split View/Stage
  Manager). Now wraps to a second row instead, capped to the pane's own
  width at any size, not just the sizes tested.
- Investigated but not reproduced: map not draggable on the wall board.
  dragPan/cooperativeGestures confirmed correct; mouse and simulated touch
  drags both worked in Chromium. See README for what to check next.
- Passed 37 static, 29 jsdom runtime and 69 Chromium checks.

## v5.13, 2026-09-22

- Stylesheet clean-up phase 2 (automated part): 31 more selectors merged using
  specificity-aware cascade analysis. Pixel-identical to v5.12.
- Corrected the scattered-selector metric (commas inside :is() were being
  split): selectors styled in 4+ rules are down from 41 to 31 since v5.11.
- Passed 37 static, 29 jsdom runtime and 69 Chromium checks.

## v5.12, 2026-09-22

- Stylesheet clean-up, phase 1, no intended visual change: removed 217 always-
  overridden declarations, 87 dead or empty rules for classes no longer used,
  and merged 29 selectors' scattered rules where provably safe.
- 200 KB to 190 KB; 501 to 469 !important. Verified pixel-identical across 34
  desktop and iPad screenshots.
- Passed 37 static, 29 jsdom runtime and 69 Chromium checks.

## v5.11, 2026-09-22

- Full code audit: ESLint on all app JavaScript, CSS declaration validation,
  HTML validation, and a scripted run of every workflow and dialog.
- Fixed: Heli Status Firebase sync messages never appeared (called a missing
  function); dead legacy map-refresh code replaced with the intended second
  refresh; two invalid CSS font rules that browsers ignored.
- New static check for the invalid font pattern.
- Passed 37 static, 29 jsdom runtime and 69 Chromium checks.

## v5.10, 2026-09-22

- One UI typeface: DM Sans throughout (IBM Plex Sans removed), Roboto Mono for
  callsigns and tails. A new static check guards this.
- Map tools grouped into one card with dividers, matching the zoom card.
- Board View on-call line shows "No on-call doctor set" when empty.
- Full audit of all tabs and Board View at desktop and iPad sizes: no
  overflow, page errors or serious/critical Axe findings.
- Passed 36 static, 29 jsdom runtime and 69 Chromium checks.

## v5.9, 2026-09-22

- Winch slots coloured by type: Land green, Wets blue, Decks yellow, the same
  by day and night. IFR badge now indigo; VFR a neutral light grey.
- Styling only; no data, rule or sync change.

## v5.8, 2026-09-22

- Winch now records Land, Wets and Decks by Day and by Night, replacing
  Dry/Wet/No Winch. Set daily in Edit mode by tapping each slot.
- Existing values convert on read: Wet Winch to Land and Wets by day, Dry
  Winch to Land by day, No Winch to none. Blood removed. Same Firebase field.
  Upgrade all active desks together; a v5.7 desk would drop the new values.
- Heli Status Board columns: Status, Base, Role, Callsign, Tail, Flt, Winch.
  OOS reason moved into the status pill; OOS column kept in Edit mode only.
- Board View columns: Status, Base, Aircraft, Flt, Winch. Airborne removed.
- IFR/VFR restyled as slot badges with cloud and eye icons.
- Browser suite now runs and covers both boards; passed 35 static, 29 jsdom
  runtime and 69 Chromium checks across desktop, Citrix and iPad profiles.

## v5.7, 2026-09-22

- Independent audit edition. No calculation, dataset, operational rule,
  storage key, Firebase path, map behaviour or provider endpoint changed.
- Reconfirmed all 35 static and 29 jsdom runtime checks pass against the
  v5.6 package with no errors and no new OPEN items.
- Structural review of all 1,736 rules in the application stylesheet found
  no accidental duplicate-property cruft.
- Recomputed WCAG contrast for every text colour token against its
  production backgrounds; all pass AA, consistent with the v5.0 pass.
- Chromium was reported as unavailable; that was incorrect (see v5.8).

## v5.6, 2026-09-19

- Moved Clinical Conditions Guidance from an executable JavaScript template
  literal into an inert HTML template while preserving the same dialog output.
- Added static and runtime checks for the inert clinical content source.
- Added this changelog and documented the manual ZIP to Netlify workflow.
- Removed the unused GitHub Actions workflow.
- Recorded the boundary between file-verifiable configuration and Google or
  Firebase controls that require provider-console evidence.
- Passed 35 static checks and 29 jsdom runtime checks. The automated Chromium
  suite is included but could not run in the packaging environment because its
  browser executable is not installed.
- No calculation, dataset, operational rule, storage key, Firebase path, map
  behaviour or provider endpoint changed.

## v5.5, 2026-09-19

- Corrected the deployment self-check to use the canonical data registry.
- Reported HTTP localhost and 127.0.0.1 as local-test information instead of a
  secure-deployment failure.
- Passed 33 static and 27 jsdom runtime checks. ZIP integrity passed.
- Operator completed a local iPhone browser check.

## v5.4, 2026-09-19

- Added live-subsystem confirmation times and TracPlus stale-state detection.
- Added a non-billable deployment self-check that makes no provider requests.

## v5.3

- Added deterministic Chromium checks for desktop, Citrix and iPad-sized
  profiles, plus serious and critical Axe accessibility findings.
- Corrected the map container accessibility role.

## v5.2

- Version-aligned and verified packaging edition.
- Passed structural and jsdom runtime checks.

## v5.1

- Added the same-origin service worker for the application shell only.
- Kept map tiles, live services, Firebase and provider APIs network-only.

## v5.0, 2026-09-09

- Promoted the audited v4.7.3 baseline to production.
- Improved responsive calculation tiles, contrast and 1024-pixel layout.
- Corrected the visible release chip.

## Earlier baseline

v4.7.3 Production remains the supplied rollback baseline named in the HTML
header. Detailed earlier history remains in the versioned source files.
