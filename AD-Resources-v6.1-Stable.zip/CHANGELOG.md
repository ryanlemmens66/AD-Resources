# Release history

Full per-build notes for v5.0–v6.1 are preserved in the earlier release ZIPs
(`AD-Resources-v6.1-Reviewed.zip` and before), kept on the owner's computer.

## v6.1, 2026-09-28 — Stable Production Baseline

v6.1 is the Stable Production Baseline for official live use; v6.0 is the
immediate rollback release. No dataset, clinical rule, calculation, CAD wording,
provider key, Firebase path, storage key or CSP origin changed from v6.0 beyond
the presentation and map-layer work below; dataset content is unchanged (build
.11 moves it into data blocks verbatim) and `APP.dataVersion` remains
`2026.09.24`.

**Build 20260928.14 — sharper phone map, map framing and sign-off.**

- The map renders at up to 2x on phones, as on iPad and desktop (was 1.5x), so
  labels, roads and markers are sharp on high-density phone screens.
- Transfers and SAR scale the zoom-to-fit margin to the map's size. On a short
  map pane (iPad landscape) the SAR search previously could not frame the scene
  and the nearest base together and fell back to the scene alone.
- Final check: every tab, dialog and workflow at 19 screen sizes raises no
  script error; the only warnings are live-service fallbacks when offline.
- The last eight legacy component `!important` rules are resolved by
  specificity (header background, calculation cards, hospital suggestion list,
  coordination note, empty states, message previews, Clinical Advice fields,
  OOS reason); `!important` 107 → 96, all in the documented categories.
  Verified identical across the computed-style comparison.
- Owner sign-off recorded: content and clinical catalogue entries reviewed
  2026-09-28, real-device checks complete, production URL
  <https://airdeskresources.netlify.app/>. Ownership is Ryan Lemmens's unless
  formally handed over; release and rollback ZIPs are kept offline on the
  owner's computer.

**Build 20260928.13 — slim phone header.** On phones the health chip and
*Reset Forms* sit beside the AirDesk name, so the header is one row (54px, was
86px) down to 360px wide; narrower phones still wrap *Reset Forms* to a second
row.

**Build 20260928.12 — final visual pass.** Every screen reviewed at desktop,
iPad and phone:

- Card headers keep their action on the title line whenever both fit (on a
  phone *Scene Weather* and *Fixed-Wing Transfers* no longer drop to a row of
  their own).
- Board View keeps "Heli Status Board" on one line on a phone; the summary sits
  beneath it.
- Heli Status edit mode: the OOS reason matches the other menus in the row, with
  its dropdown arrow, and "Mechanical" no longer clips.
- Desktop and iPad: the form fades into the page as it scrolls under the tab
  bar instead of being cut in a hard line (off in Citrix mode). Done with a
  pinned gradient rather than a mask, which would have softened all panel text.

**Build 20260928.11 — map layers and maintainability.**

- Map layers: *Hospitals* and *Air Desk Guidance* still start on, but now stay
  off when switched off, until switched on again or the next reload. They were
  forced back on by a hook that covered a real fault: the layer restore stopped
  after the first few layers of a pass, because each new layer briefly reports
  the map as loading. The restore now retries until every visible layer is on
  the map; hidden layers install when first switched on, as before. Covered by
  new unit checks.
- Map data moved out of code: all 14 static datasets (LZs, Air Desk Guidance,
  IFR routes, hospitals, HEMS bases, emergency resources, maternity and medical
  centres, jetties, huts and campsites, DHB regions) are JSON blocks, one
  feature per line, read by `AirDesk.util.dataset()`. New `tools/data.mjs`
  exports a dataset to CSV or GeoJSON and imports it back with validation, id
  retention and a reviewable diff (dry run unless `--apply`). The id baseline
  now protects 4,947 ids across 13 datasets (was 3,693 across 8).
- Guidance checks: the approved guideline issue is recorded once
  (`APPROVED_GUIDANCE` in `tools/check.mjs`); the runtime and browser checks
  read the version and date from the guidance template instead of repeating
  them.
- Stylesheet: a second, evidence-based merge pass (runtime class combinations,
  verified with the computed-style comparison) folded most remaining split
  definitions: rules 1,623 → 1,530, declarations 6,456 → 6,366, media blocks
  58 → 54, `!important` 109 → 107. Removed the retired Map Layers list, its
  dead click and change handlers, the Heli Status OOS-button branch and
  `.map-state` rules for a class nothing carries; the layer toggle attribute
  is now `data-layer-toggle`. Keyboard focus keeps the shape of pills, SAR
  controls and reference buttons.

**Build 20260928.10 — code consolidation.**

- Stylesheet rebuilt from its accumulated override layers into one definition
  per component: rules 1,942 → 1,623, declarations 7,195 → 6,456, media blocks
  65 → 58, `!important` 298 → 109 (the remaining uses are listed in
  ARCHITECTURE.md). Removed 53 declarations that could never apply, 84 dead
  rules for retired markup (the standalone Heli Status button, the old Heli
  Status list layout, unused loading states) and 20 redundant `[hidden]` rules.
  One consistent format; comments rewritten without version history.
- Scripts: the map attribution is collapsed by the map manager as the control
  is added (so it no longer shows expanded for the first seconds), replacing a
  separate module that re-applied it on timers; dead branches for the retired
  basemap switcher, Heli Status map button, list layout and events portal
  removed, along with the unused `lzPriorityIcons` alias. Comments rewritten in
  the present tense.
- Visual fixes: on phones the two-option SAR *Receiving agency* grid keeps two
  columns (it inherited three); the map *Layers* button shows the same hover and
  press tint as the other toolbar buttons; and the *Overdue Aircraft* pill now
  pulses as designed (its keyframes held only `!important` declarations, which
  browsers ignore inside keyframes, so it never ran). The pulse pauses on hover
  and focus and is off for reduced motion and in Citrix mode.
- Documentation consolidated into README (deployment and sign-off),
  ARCHITECTURE (maintenance) and this file; RELEASE-NOTES, AUDIT and
  VISUAL-REVIEW retired. The four small mocked test suites merged into
  `tools/unit-check.mjs`; the visual check waits for the *What's new* card so
  its first screen is deterministic.
- Verified with the full `npm run test:all` gate and a computed-style comparison
  of every element across 930 recorded states (19 viewports straddling every
  media breakpoint, plus forced hover, focus and active states): no differences
  other than the fixes above and properties with no visual effect.

**Build 20260928.9 — freeze.** Fixed the iOS Home Screen launch showing two
different screens (translucent status bar with safe-area insets, launch image
matching the splash tile, no second splash entrance). Repaired the browser gate
at phone size, where the compact header hides the version chip and Board View
by design.

**Builds 20260926–20260928.8 — polish from v6.0.** Header, controls and tokens:
one close button, one segmented selection style, flat status chips, a single
type/radius/shadow scale, embedded DM Sans and Roboto Mono, and the launch
splash. Layout: equal-height Response Plan cards with footers, aligned
calculation rows, Heli Status board header and gutter, Board View column
protection, wide-layout tab alignment, compact timing rows, phone Reset Forms
placement. Function: build identity in System Status and Desk Status; SAR and
Clinical Advice copy recovery; IHT/SAR closer-aircraft advisories; FENZ preview;
road-time override and CAD destination ordering; Auto island-label policy;
"What's new" note.

## v6.0, 2026-09-24 — Stable Production Baseline

Promoted the audited v5.56 candidate. Applied the three operational-data changes
confirmed by the owner (SH6 Haast–Lake Moeraki closure, permanent PARAPARA
adjustment, Waihi Bowling Club replacing Morgan Park) and advanced
`APP.dataVersion` to `2026.09.24`. Recorded the Google, LINZ, Firebase and
TracPlus production attestations.

## v5 series, 2026-09-09 to 2026-09-24

- **v5.48–v5.56:** production audits and handover reconciliation; teal
  scene-to-hospital route; full Axe sweep; phone layout for the guidance dialog;
  dead DOC live-API code removed.
- **v5.30–v5.47:** Tasking & Clinical Guidance rebuilt against the approved
  v2.01 PDF in one inert template, grouped into operator-facing categories,
  including Area Specific Considerations; approved MapIT operational points
  imported; dataset-id retention baseline added. Heli Status gained additional
  aircraft, in-place editing for iPad and priority arrows.
- **v5.22–v5.29:** H-in-ring brand mark; scaling calculation cards; tab labels
  that never wrap; maintainer files blocked from public delivery; documentation
  restructured.
- **v5.12–v5.21:** stylesheet clean-up (always-overridden declarations, dead
  rules and provably unneeded `!important` removed with screenshot proof); map
  toolbar grouped and resized; Shift Notes drag handle; Split-view overflow
  fixes.
- **v5.8–v5.11:** winch recorded as Land/Wets/Decks by Day and Night with type
  colours; DM Sans as the single UI face; full code audit fixes.
- **v5.0–v5.7:** production promotion of v4.7.3; offline shell worker; Chromium
  and Axe checks; deployment self-check and TracPlus stale detection; clinical
  guidance moved into an inert template.
