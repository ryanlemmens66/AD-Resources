# AirDesk v6.1 visual acceptance — Stable Production Baseline

Build `20260928.9`, frozen 28 September 2026. The only visual change in the
freeze build is the iOS Home Screen launch. Against build `20260928.8`, 51 of
54 visual-regression screens are unchanged on every other device; the three
System Status screens differ only in the build and baseline line.

## Device acceptance for the freeze

- **iPhone and iPad Home Screen:** remove the existing AirDesk icon, open the
  production URL in Safari, wait a few seconds, then Add to Home Screen.
  Launch it: the green launch screen and splash must read as one continuous
  screen (no jump, no second logo entrance, no colour change at the top), and
  the header must clear the status bar or notch. Check portrait and landscape,
  and open a dialog to confirm its top is clear of the status bar.
- **Safari (not Home Screen), desktop, Android and Citrix:** unchanged; confirm
  the header looks as before.
- Carry forward the checks below that are still open: long labels, Compare
  fit, modal scrolling, onscreen keyboard clearance, 200% zoom, focus
  visibility and reduced motion.

# Earlier visual reviews

### Canvas and divider refinement, 28 September 2026

v6.1 build `20260928.2`. Canvas lightened to #F4F6F3. The desktop splitter
column is 24px, with card padding and scrollbar allowance balanced against
the map edge. Tabs align with the card edge. The resize and keyboard logic
are unchanged, and expanded map mode removes the extra edge allowance.

Mouse/trackpad desktop layouts retain a slim, quiet scrollbar and stable
scrollbar space. Touch layouts use native scroll indicators without a reserved
gutter. No scrollbar is forcibly hidden and scrolling remains enabled.

115 static checks passed; source comparison confirms that operational and map
scripts are unchanged (only the build identifier changed in configuration).
Rendered spacing and native scrollbar behavior still need device acceptance.

### Final consistency acceptance, build 20260928.1

The user reports having clicked through the app successfully. This pass adds
System Status build identity, accessible skill selection state and consistent
secondary copy recovery. Confirm these focused changes on device: deny then
retry SAR Water / Clinical Advice copy, check normal skill selection and reset,
and find Build 20260928.1 under System Status or the green-dot Desk Status panel.
While services are connecting, confirm the summary does not claim all feeds live. The accepted styling is retained.
No fresh rendered browser or actual Citrix review was obtained.

### Phone header action, 28 September 2026

At the existing compact-header breakpoint (700px and narrower), Reset Forms
now occupies the header action position instead of Board View. Wider layouts
retain all existing actions. The existing two-tap confirmation is unchanged:
first tap shows Confirm Reset?, second tap resets; confirmation expires after
12 seconds. No reset logic changed. Static checks passed (115); rendered phone
acceptance remains open.

### IHT/SAR aircraft advisories and FENZ preview, 28 September 2026

- All three workflows now resolve their own location and selected resource for
  the amber Closer aircraft advisory. IHT uses the sending hospital; SAR uses
  its scene. Primary uses its selected base or live aircraft.
- The pill opens the matching Live Aircraft panel and remains advisory only.
  It does not assert availability or change resource selection. Only airborne
  fixes within the existing five-minute response freshness threshold qualify,
  and failed/stale feeds suppress the advisory.
- IHT/SAR selection and reset changes refresh the advisory immediately.
- FENZ LZ Request now has a three-row, vertically resizable preview with an
  accessible label. Longer messages remain scrollable and fully copyable.
- Targeted verification: 115 static, 44 workflow and 11 new advisory checks
  passed. Prior full review passed 224 checks; unaffected suites were not rerun
  for this focused change. Real browser layout and live feed checks remain open.

## AirDesk v6.1 visual acceptance

Current status, 27 September 2026: the user previously confirmed general device
consistency and the Times Breakdown alignment fix. The newly supplied working
ZIP carries the accepted header, loose Primary skill chips, footer count pills
and national map view. This review preserves that presentation.

No fresh rendered verification was obtained for this corrected package. The
browser service's earlier local-URL rejection was not bypassed. DOM tests do not
measure layout, contrast, touch behavior or WebGL rendering. Existing acceptance
does not certify every state of the newly supplied build.

### Focused acceptance for the corrections

- Auto: below zoom 7, island labels stay hidden; at the threshold, the policy
  allows them while respecting native minimum zoom. Switch to Topo and Aerial
  and confirm their labels are unaffected.
- Coordinate copies: repeated taps retain the copy icon, announce success or
  failure, and do not leave the control busy.
- SAR messages: deny clipboard access and confirm generated text remains
  visible/selectable; allow a retry and confirm normal copy behavior returns.

### Final release checks

Use phone portrait/landscape, iPad and the actual desktop/Citrix setup. Confirm
long hospital/base labels, Compare fit, modal scrolling, onscreen keyboard
clearance, 200% zoom, focus visibility and reduced motion. Test populated as
well as empty forms. Run the packaged browser/Axe checks in an authorized
environment and review any contrast findings.

No new button or map redesign is proposed here. Clinical Hub visual parity and
splash-duration parity require a side-by-side check of both current apps on
the same device; neither was newly measured in this review.
