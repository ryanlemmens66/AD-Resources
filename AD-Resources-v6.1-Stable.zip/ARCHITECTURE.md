# Architecture and maintenance

A map of the AirDesk HTML file (currently `AirDesk-v6.1.html`, re-checked at
the v6.1 polish release) for someone who has to maintain it and did not write
it. `README.md` covers deployment, credentials and provider usage/quota controls; the
comment block at the top of the HTML is the in-file authority for release
identity, the module index and the maintenance contract. This covers how the
file is put together and what a reviewer should know before changing it.

Where this and the in-file block overlap, **the in-file block wins** — it
travels with the deliverable.

## The short version

One HTML file, ~4.35 MB, no build step. Open it and it runs. A second file,
`sw.js`, is deployed beside it as an offline shell; it is optional and
best-effort, and the app is unchanged without it.

Most of the file weight is approved reference data and bundled map-vendor code,
not business logic. The last detailed size classification remains useful as a
directional maintenance guide:

| Part | Approx. size | Share |
|---|---:|---:|
| Data/reference-heavy modules plus the inert guidance template | ~2.49 MB | ~57% |
| MapLibre GL JS 4.5.0 plus its bundled CSS | ~0.87 MB | ~20% |
| AirDesk application CSS | ~0.22 MB | ~5% |
| Remaining application logic, shell markup and embedded icons | ~0.78 MB | ~18% |

The split is intentionally approximate because several owning modules contain
both reference data and the small amount of logic that registers it. It is a
maintenance guide, not a build invariant.

The application is heavily modularised inside the single HTML file. Unlike the
sibling Clinical Hub app, the static markup is comparatively small because much
of the UI is constructed in JavaScript. The dependency-free static audit prints
the current script, element-id and named-function counts on every run, so this
document deliberately does not duplicate those change-prone figures. Since v6.1
embedded the fonts there are no inline `on*` handlers (the last was the Google
Fonts `<link>` loader); every event is bound with `addEventListener`.

## Shared interaction ownership

`airdesk-ui-feedback` owns transient labels, busy states, announcements and document-copy feedback. Use `AirDesk.ui.feedback.copy(control, text)` for document preview copy actions. It prevents concurrent writes, permits retries and restores original child nodes. Keep calculation and document-generation logic in their owning workflow modules.

Optional sections update `aria-expanded` when shown or cleared. A user-triggered deletion restores focus to Add; programmatic resets must not move focus.

## Module layout

Every script block carries an id and owns one thing. The in-file header lists
them under *Maintenance entry points*; the shape is:

- **Core** — `airdesk-core-config` (release identity, operational rules,
  provider endpoints, governance), `airdesk-shared-utils`,
  `airdesk-platform-services`
- **Map** — `airdesk-map-manager`, `airdesk-reference-layers`,
  `airdesk-map-layer-runtime`, `airdesk-map-ui`
- **Screens** — `airdesk-primary-*` (17 blocks), `airdesk-transfer*`,
  `airdesk-sar-*`
- **Datasets** — `airdesk-aerodromes-lzs`, `airdesk-aviation-guidance`,
  `airdesk-huts-campsites`, `airdesk-marlborough-jetties`,
  `airdesk-hospitals`, `airdesk-hems-bases`, `airdesk-clinical-pathway-layers`,
  `airdesk-maternity-medical-centres`, `airdesk-emergency-resources` and the
  smaller owning resource modules. README's **Map data update routes** table is
  the handover index for replacement sources.
- **Shared state** — `airdesk-shared-sync`, `airdesk-shift-notes-sync`,
  `airdesk-heli-status`, `airdesk-form-persist`, `airdesk-phi`
- **Live** — `airdesk-tracplus-*`, `airdesk-nzta`, `airdesk-board-weather`

Modules expose themselves on frozen namespaces — `AirDesk.primary.sceneLocation`,
`AirDesk.map.referenceLayers`, `AirDesk.system.configStatus` — and reach each
other only through those. Configuration and public exports are extensively
frozen so accidental mutation is difficult. This is the main structural
difference from the previous Air Desk
lineage and from Clinical Hub, and it is what makes `tools/verify.mjs` possible:
a missing subsystem after boot names exactly which module stopped.

## The three maintained update paths

The application deliberately separates three kinds of future content change so
a maintainer does not have to hunt through downstream renderers or calculations:

- **Mapping/reference data:** replace the canonical dataset in its owning module,
  preserve ids for surviving features, inspect the automated id diff, then update
  `tools/dataset-baseline.json` only after the source-data change is approved. Air Desk
  Guidance intentionally combines 3A with MapIT 8C/8D/8F points, the 12 NM limit and
  40 km road-distance trauma rings in one canonical dataset; 40-minute trial rings remain excluded.
- **Tasking & Clinical Guidance:** replace content only in the inert
  `#airdesk-tasking-clinical-guidance-content` template from the complete approved
  guideline PDF, and update its section/page/date/hash manifest in the same release.
- **Operational defaults:** change shared timing/conversion values only in
  `AirDesk.rules` in `#airdesk-core-config`; hospital-specific `helipadToEDMin`
  remains owned by `#airdesk-hospitals`. Primary, IHT, SAR and live-aircraft
  fallback paths all consume those canonical values.

The static audit now checks these contracts so a future edit that reintroduces a
second km-to-NM literal, loses a documented update route, or lets package/version
metadata drift fails before deployment.

## The app validates itself

This matters more than any check I could add from outside, because it runs at
the desk rather than only before deployment.

- **`validateConfiguration(CONFIG)`** runs at boot. Schema version, unique ids
  and titles across the document and map-layer registries, a `dataVersion` on
  every static layer, `YYYY-MM-DD` on every review stamp. The result lands on
  `AirDesk.system.configStatus`, is rendered as a *Configuration needs
  attention* block in **System Status**, and is passed to `reportError` on boot
  when `settings.showConfigurationWarnings` is on.
- **`validateFeatures(collection)`** runs on every reference dataset
  registration and update, and **throws** on anything that is not a `Feature`
  or carries an unsupported geometry. A malformed dataset replacement aborts
  its own module rather than silently registering nothing.
- **`OPERATIONAL_REVIEWS`** carry `reviewAfterIso` dates and surface a warning
  in System Status once due.
- **`AirDesk.health`** tracks live feed state and last-confirmed times for
  TracPlus, heli status, shift notes, maps and network behind the header chip.
  TracPlus derives a stale state after three minutes without a successful poll.
- **System Status deployment self-check** reads the already-loaded release,
  configuration, shell, dataset registry, map state, shared sync state and
  protocol. It deliberately performs no provider request.

`tools/verify.mjs` now fails the build on `configStatus.valid === false`, so a
release cannot ship with a configuration only System Status would have told you
about.

**What it does not validate is feature ids.** `validateFeatures()` checks
geometry and stops; `validateUniqueIds()` guards the CONFIG registries, not the
data. That leaves the contract's most important rule — ids survive an import —
with nothing behind it, and it is invisible to feature counting: renumbering all
748 LZs changes no count. `tools/dataset-baseline.json` stores the id sets and
`check` compares against them, failing on duplicates or on wholesale
replacement, and printing the added/removed diff for anything smaller.

## Checks

```bash
# Node 20+ is required for the locked Playwright 1.63 verification dependency.
npm run check    # static source and package checks
npm run verify   # initialization and reference checks in jsdom
npm test         # all seven non-browser suites
npm run browser  # Chromium layouts, dialog interaction and Axe
npm run test:all # npm test plus browser checks
npm run visual:baseline && npm run visual:compare  # around visual/CSS edits
```

`tools/visual-check.mjs` (added v5.24, expanded in v5.52) screenshots 18
maintained screens at desktop, iPad and phone sizes, 54 screenshots in total,
before and after an edit and reports every screen that changed.
It is the packaged visual-regression check for stylesheet/UI changes. Use it
when presentation code changes; a documentation-only or version-only release
does not need to manufacture a screenshot diff.

**Controls, launch and fonts (v6.1).** One close button for every dialog
(`.dialog .close`, `.dd-x`, `.oa-x`, `.tg-close`: a 32px circle with a CSS-drawn
X). Primary skill selectors are individual hairline chips with a solid green
selection. Other segmented controls use `.seg`/`.seg-btn`, including CAD times
format and Standard/Citrix. Button colours are v6.0's and are deliberately untouched. `#airdesk-launch`
runs first in `<body>`: the splash leaves at `DOMContentLoaded` (never before
550ms) and a CSS animation removes it at 3.2s even if that script never runs; on
iOS Safari it also draws matching `apple-touch-startup-image` links. The status
bar is `black-translucent` so a Home Screen launch fills the same area as that
image; `.header`, the `.app` header row, dialogs and the error banner add
`env(safe-area-inset-top)` (zero elsewhere), and `#airdesk-standalone` in
`<head>` marks a Home Screen launch so the splash does not animate in a second
time. Change the splash, the drawn image and these insets together. DM Sans and
Roboto Mono are embedded as woff2 in `#airdesk-fonts` (fonts from `data:` only in
the CSP); because the embedded fonts are variable, stylesheet weights are written
as the faces Google Fonts actually drew (400-800 in hundreds). `.ad-skel`
placeholders are written inside the element the result later replaces.

**Tokens and What's new.** The app stylesheet's literal values sit on one
scale: type 10/11/12/13/14.5/16/18.5/22px, weights 400-800 in hundreds (matching
the embedded-font remap above), radii 6/10/14/18px plus pill and circle, and
`--shadow-sm/md/lg` for plain drop shadows (insets, focus rings and coloured
glows stay explicit). Board View type stays deliberately `calc()`-scaled by
`--bs`/`--fit`. Add a new value only as a token. `#airdesk-whats-new` shows its
`NOTES` once per updated version, keyed `whats-new-seen`; add two or three lines
there for each release.

**Response Plan card footers.** A `.resource` card's button row is
bottom-anchored (`.resource>.mini-actions{margin-top:auto}`) and the two cards
in a row are stretched to equal height (`.resource-grid{align-items:stretch}`),
so a card with less content above it opens a gap with nothing in it. A divider
(`.resource .mini-actions{border-top:...}`) turns that space into a footer.
`#screen-iht` keeps its own top padding on this row unchanged. The name-to-
detail gap above it (`.resource small{margin-top:5px}`) is slightly looser for
the same reason.

`check` proves the file is well-formed. `verify` proves it assembles. `browser`
proves the application shell renders and remains usable in a real engine. The
division is load-bearing: inject a `throw` at the top of any module and `check`
stays green — the syntax of an aborting module is perfectly valid — while
`verify` fails naming the missing subsystem. That is exactly the failure mode
that took down the previous lineage twice, both times as a silent abort partway
through an init chain.

Checks printed **OPEN** are non-blocking review items, not defects, and do not
affect the exit code.

### What `check` guards

| Check | The failure it catches |
|---|---|
| Script blocks parse | A syntax error kills its block silently; several blocks here are one dataset, so losing one loses a map layer with nothing surfaced. |
| HTML comment pairs balance | A comment opened `<!--` and closed `*/` raises no error — the browser eats markup to the next real `-->`. This once swallowed a whole CSS block and a script while every syntax check passed. |
| Tag balance, duplicate ids | Markup rot. |
| Named functions, none unreferenced | Dead code. Named IIFEs excluded — this codebase scopes binding steps that way. |
| No `console.log` / `debugger` / `alert()` | Debug leftovers. The MapLibre block is excluded; its ten `console.log` calls are vendor code. `console.warn`/`error` are deliberate diagnostics. |
| netlify.toml rewrites point at the app file | The version-bump trap — see *Deployment* in the README. |
| `APP.version` = filename = header chip | The chip has gone stale before: v5.0 shipped with markup reading v4.6.1. |
| `APP.buildDate` = file-header build date | Prevents release metadata from carrying a stale prior-build date. |
| Header stable-baseline text = `APP.baseline` | Prevents a release from claiming one frozen baseline in the UI and another in the maintainer contract. |
| iOS launch image = HTML splash | Status bar translucent with the header inset, the same tile radius, and no second entrance on a Home Screen launch. Otherwise iOS shows two different screens while loading. |
| Declared Node engine satisfies the locked Playwright engine | Prevents `npm ci`/browser verification from being documented as supported on a Node version the package cannot actually use. |
| CSP `connect-src` covers every fetched origin | `netlify.toml` promises this; here it is checked. |
| Tasking & Clinical Guidance: single inert template, mapped source metadata | See *Editing traps*. |
| Dataset ids retained | Duplicates, dropped ids, or a renumbered id space — the one import failure that feature counts cannot see. |
| Client credentials/config entries accounted for and single-source | Google Maps, LINZ Basemaps, LINZ Data Service and Firebase must all be present in their canonical locations; the two LINZ keys must remain distinct and each provider key must occur only where its owner expects it. |

### What `verify` guards

Boot completes; every required namespace and named subsystem under `primary`,
`sar`, `transfer`, `map` and `system` present; configuration validates clean;
`APP.version` agrees with the filename; the service catalogue covers all six
providers; 20 reference data modules registered; the tab bar and app shell
rendered; nothing fixed and full-viewport sitting on top of the UI; no
unexpected console errors.

### What neither can see

**Rendering.** jsdom has no WebGL, so MapLibre never initialises and the app
runs its `PlaceholderMapAdapter` fallback — which is the path `verify`
exercises. Tiles, layer draw order, terrain, the measurement tool and anything
visual still need a real device. Two console errors during `verify`
(`createObjectURL is not a function`, `MapLibre GL JS did not load`) are that
fallback working as designed and are allowlisted.

## Editing traps

Read the *AI maintenance contract* in the file header first. Beyond it:

- **`airdesk-tasking-clinical-guidance-content` is the single inert source for the Tasking & Clinical Guidance modal.** It contains the mapped reference sections from the approved full guideline PDF, while the runtime script only provides navigation, search and presentation. Keep the content as valid HTML, never move approved wording into executable JavaScript, and update its source metadata and PDF fingerprint whenever the approved guideline changes.
- **Datasets are replaced in the owning module,** never duplicated into a
  second source. The header lists which module owns which approved source.
- **Approved-dataset imports must retain existing feature ids** for sites that
  survive the import, even when names, coordinates or metadata change. An
  automated rewrite will renumber them silently. Ask any tool producing a
  replacement for an id-level diff — added, removed, retained — as a separate
  output, and check that before the content.
- **`AirDesk.services.catalog` and the CSP `connect-src` move together.**
- **CSS order is intentional** — see below.

## Structural observations

Findings from the final handover review that are **not** defects, recorded so a
future reviewer does not spend time rediscovering or "cleaning up" deliberate
patterns:

| Observation | Assessment |
|---|---|
| **Numerous `!important` flags in the application stylesheet** | v5.12-v5.21 removed the flags that could be proven unnecessary with screenshot comparison. What remains is primarily deliberate base-plus-modifier and device-layout behaviour. Change these only component-by-component with visual regression checks. |
| CSS selectors and generated inline styles occur in multiple responsive/device variants | Expected for the desktop, iPad and Citrix layouts. Apparent duplication is not enough reason to merge rules without screenshot verification. |
| Best-effort empty `catch` blocks remain in map/UI integration paths | Sampled cases are intentional, for calls such as MapLibre layer updates, clipboard access, selection APIs and URL parsing where failure is harmless and there is no useful operator action. Do not turn these into logging noise. |
| No inline `on*` handlers remain (the Google Fonts loader went with v6.1's embedded fonts); interactions use `addEventListener` | Intentional and compatible with the current CSP. |
| No runtime `eval`, `document.write` or string-argument `setTimeout` is used | A historical `new Function` example remains only in documentation/commentary describing a removed parser. |
| `textContent` is preferred over `innerHTML`; the remaining HTML insertion points are deliberate renderers | Continue to treat any new `innerHTML` use as a review point. External links opening a new tab retain `rel="noopener"`. |
| Accessibility is regression-tested automatically, but not fully certified | `npm run browser` covers serious/critical Axe findings on the maintained screens. Keyboard flow and screen-reader behaviour still require human testing if formal accessibility assurance is needed. |

The static audit already checks named-function reachability and rejects debug
leftovers, duplicate ids and parse failures. A broad source compaction pass would
therefore add risk without a demonstrated maintenance benefit. Prefer small,
module-owned refactors when a component is already being changed.

## If you are picking this up cold

1. Read *Start here* in `README.md`, then the comment block at the top of the
   HTML: standing design decisions, module index, dataset routes, maintenance
   contract. `RELEASE-NOTES.md` explains why things are the way they are.
2. Read `README.md` — deployment, credentials, provider usage/quota controls and the production acceptance record.
3. Use Node 20+ and run `npm ci && npm run test:all`. All suites should be green.
4. Datasets are replaced in their owning module. Ids survive.
5. After any change: `npm run test:all`; for visual or CSS changes also
   `npm run visual:baseline` before and `npm run visual:compare` after. Then a
   real device, because no check here can see live map tiles or providers.
6. On a version bump: rename the file **and** update both rewrites in
   `netlify.toml`, and the `APP.version` constant. `check` enforces all three.

### Heli Status extensible roster (v5.34)

Configured base slots remain the permanent roster skeleton. Each base can additionally hold up to three persisted `additional:true` rows in the same `state.slots[baseId]` array and Firebase record. Additional rows receive stable ids, are included in callsign/tail identity indexes and Board View, and are removed only by the Edit-mode delete action. `aircraftType` is optional metadata on the same slot object and follows the aircraft when configured slots are reordered.

Do not create a separate additional-aircraft collection or Firebase path. `maxSlots` remains the configured roster definition, while rows beyond `maxSlots` are explicitly additional. This distinction protects role ordering and future roster maintenance.

## Current review implementation notes

- `MapLibreLinzAdapter.applyAutoPlaceLabelPolicy` acts only on the Auto/topolite
  style. Topo is left unchanged. First-paint island thresholds retain any native
  minimum zoom stricter than 7. `tools/map-policy-check.mjs` checks this policy
  with a mocked layer API; it does not render LINZ tiles.
- `AirDesk.ui.feedback.copy` owns copy busy state and failure feedback. Its
  `preserveLabel` option keeps icon-only coordinate controls intact. SAR message
  generation retains a visible manual-copy preview on failure and hides it after
  a successful retry. Concurrent actions are guarded.

Aircraft advisory ownership: IHT exposes its canonical `getSelectedBase` resolver;
SAR exposes a copy of its rendered effective base. The shared TracPlus renderer
binds a workflow to each status region and resolves its location explicitly.
`tools/aircraft-advisory-check.mjs` covers isolation, selection, freshness, reset
and opening the corresponding fleet panel with mocked positions.

Build identity: `APP.buildId` is the single diagnostic identifier for a working
package. System Status and deployment self-check read it directly. It does not
change storage keys, cache policy, the baseline, or the displayed release version.
Primary skill-pill aria-pressed state follows the same selected value as its CSS
class in normal interactions, reset and draft restoration.
