import { readFileSync, writeFileSync } from 'node:fs';
// The app filename is discovered, not hard-coded — it carries the version, so
// a literal here would go stale on every bump and was doing exactly that.
import { APP_FILE } from './lib.mjs';
const src = readFileSync(APP_FILE,'utf8');
const BLOCKS = ['airdesk-aerodromes-lzs','airdesk-marlborough-jetties',
  'airdesk-huts-campsites','airdesk-hospitals','airdesk-hems-bases','airdesk-clinical-pathway-layers'];
// airdesk-aviation-guidance holds two unrelated, independently-registered
// datasets (IFR_DATA and GUIDANCE_DATA) in one script block. Baselining by
// script id would combine their features and ids into one bucket, diluting
// the 90% retention floor: a maintainer could lose most of GUIDANCE_DATA's
// ~256 ids and still clear the floor on the strength of IFR_DATA's ~405
// untouched ones. Each JS const in this block is its own baseline entry,
// keyed by the same id the app registers it under (ifr-routes /
// air-desk-guidance), so each is checked -- and diffed -- independently.
const CONSTS_IN_BLOCK = {
  'airdesk-aviation-guidance': [['ifr-routes', 'IFR_DATA'], ['air-desk-guidance', 'GUIDANCE_DATA']]
};
function countAndIds(text) {
  const features = (text.match(/"type"\s*:\s*"Feature"/g) || []).length;
  const ids = [...text.matchAll(/"properties"\s*:\s*\{\s*"id"\s*:\s*"([^"]+)"/g)].map(x => x[1]);
  return { features, ids: [...new Set(ids)].sort() };
}
const datasets = {};
for (const id of BLOCKS) {
  const m = new RegExp(`<script[^>]*id="${id}"[^>]*>([\\s\\S]*?)<\\/script>`).exec(src);
  if (!m) continue;
  datasets[id] = countAndIds(m[1]);
}
for (const [blockId, consts] of Object.entries(CONSTS_IN_BLOCK)) {
  const m = new RegExp(`<script[^>]*id="${blockId}"[^>]*>([\\s\\S]*?)<\\/script>`).exec(src);
  if (!m) continue;
  for (const [datasetId, constName] of consts) {
    const c = new RegExp(`const ${constName}=(\\{[\\s\\S]*?\\});\\n`).exec(m[1]);
    if (!c) continue;
    datasets[datasetId] = countAndIds(c[1]);
  }
}
writeFileSync('tools/dataset-baseline.json', JSON.stringify({
  note: 'Feature counts and the full id set of every approved dataset at the current protected baseline. tools/check.mjs fails if ids are dropped, duplicated, or renumbered wholesale, and prints the added/removed diff for anything smaller. Regenerate deliberately after an approved dataset import or operational-data reverification: node tools/dataset-baseline.mjs',
  updated: new Date().toISOString().slice(0, 10),
  appVersion: (/version:\s*'([\d.]+)'/.exec(src) || [,'unknown'])[1],
  datasets
}, null, 2) + '\n');
console.log(Object.entries(datasets).map(([k,v])=>`  ${k}: ${v.features} features, ${v.ids.length} ids`).join('\n'));
