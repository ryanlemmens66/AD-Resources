/*
  tools/unit-check.mjs -- focused unit checks. Each block lifts one piece of the
  app (or sw.js) and runs it against mocks, so a behaviour that needs a live
  service, a map or a real outage can still be exercised on every run:
  the offline shell worker, Scene Weather state handling, the Auto map label
  policy and the closer-aircraft advisories. Any failed assertion throws and
  fails the run.
*/
import { readFileSync } from 'node:fs';
import vm, { runInNewContext } from 'node:vm';
import assert from 'node:assert/strict';
import { JSDOM } from 'jsdom';
import { APP_FILE } from './lib.mjs';

/* ---- Offline shell worker (sw.js) with mocked fetch and cache ---- */
{
const source = readFileSync(new URL('../sw.js', import.meta.url),'utf8');
let count=0;
async function scenario(name, options={}, action){
 const handlers={},deleted=[],stored=[];
 const cached={kind:'cached'},live={ok:true,status:200,clone(){return this}};
 const cache={put:async(k,v)=>{if(options.writeFail)throw Error('quota');stored.push(k)},match:async()=>options.noCache?undefined:cached};
 const context={URL,setTimeout,clearTimeout,fetch:async()=>{if(options.offline)throw Error('offline');return options.response||live},caches:{open:async()=>{if(options.openFail)throw Error('storage');return cache},keys:async()=>['airdesk-shell','airdesk-shell-old','other-app'],delete:async k=>deleted.push(k)},self:{location:{origin:'https://desk.test'},addEventListener:(name,fn)=>handlers[name]=fn,clients:{claim:async()=>{}},skipWaiting:async()=>{}}};
 runInNewContext(source,context);
 await action({context,handlers,deleted,stored,cached,live});
 console.log('PASS '+name);count++;
}
const request={url:'https://desk.test/',method:'GET',mode:'navigate'};
await scenario('live response cached',{},async x=>{assert.equal(await x.context.shellNetworkFirst(request),x.live);assert.deepEqual(x.stored,['/__airdesk-shell'])});
await scenario('cache quota failure preserves live response',{writeFail:true},async x=>assert.equal(await x.context.shellNetworkFirst(request),x.live));
await scenario('unavailable cache preserves live response',{openFail:true},async x=>assert.equal(await x.context.shellNetworkFirst(request),x.live));
await scenario('offline returns saved shell',{offline:true},async x=>assert.equal(await x.context.shellNetworkFirst(request),x.cached));
await scenario('host 503 returns saved shell',{response:{ok:false,status:503}},async x=>assert.equal(await x.context.shellNetworkFirst(request),x.cached));
await scenario('404 is not masked',{response:{ok:false,status:404}},async x=>assert.equal((await x.context.shellNetworkFirst(request)).status,404));
await scenario('offline without saved shell fails visibly',{offline:true,noCache:true},async x=>assert.rejects(x.context.shellNetworkFirst(request),/offline/));
await scenario('activation preserves unrelated caches',{},async x=>{let promise;x.handlers.activate({waitUntil:p=>promise=p});await promise;assert.deepEqual(x.deleted,['airdesk-shell-old'])});
await scenario('live APIs, cross-origin requests and writes are not intercepted',{},async x=>{for(const req of [{...request,mode:'cors'},{...request,method:'POST'},{...request,url:'https://other.test/'}])x.handlers.fetch({request:req,respondWith:()=>assert.fail('unexpected interception')})});
console.log(`All ${count} offline-worker checks passed`);
}

/* ---- Scene Weather loading, stale-response, failure and retry states ---- */
{
const html=readFileSync(APP_FILE,'utf8');
const start=html.indexOf('async function showSceneWeather(){');
const end=html.indexOf('\nfunction boot(){',start);
const dom=new JSDOM('<div id="modal" hidden><div id="modal-body"></div></div>',{runScripts:'outside-only'});
const w=dom.window,d=w.document;let count=0;
const check=(name,fn)=>{fn();count++;console.log('PASS '+name)};
try{
 w.eval(`
 const $=id=>document.getElementById(id);
 const CAA_VFR_MINIMA_HTML='<p>Reference retained</p>';
 function windyEmbedHtml(){return ''}
 function civilTwilightEnd(){return null}
 function formatNZTime(){return ''}
 function fieldsFromResponse(){return [['Temperature','12 C']]}
 const requests=[];
 function fetchWeather(){return new Promise((resolve,reject)=>requests.push({resolve,reject}))}
 const AirDesk={primary:{sceneLocation:{getCoordinate:()=>({lat:-36,lng:174})}},ui:{showModal:(title,body)=>{$('modal').hidden=false;$('modal-body').innerHTML=body}}};
 ${html.slice(start,end)}
 window.openWeather=showSceneWeather;window.requests=requests;
 `);
 let pending=w.openWeather();
 check('weather loading state announced',()=>assert.equal(d.getElementById('scene-weather-loading').getAttribute('role'),'status'));
 w.requests.shift().resolve({});await pending;
 check('weather success replaces loading',()=>{assert.match(d.getElementById('modal-body').textContent,/12 C/);assert.equal(d.getElementById('scene-weather-loading'),null)});
 pending=w.openWeather();d.getElementById('modal').hidden=true;w.requests.shift().resolve({});await pending;
 check('late weather success does not reopen closed dialog',()=>assert.equal(d.getElementById('modal').hidden,true));
 pending=w.openWeather();d.getElementById('modal-body').innerHTML='<p>Another dialog</p>';w.requests.shift().reject(new Error('Unavailable'));await pending;
 check('late weather failure cannot replace another dialog',()=>assert.equal(d.getElementById('modal-body').textContent,'Another dialog'));
 pending=w.openWeather();w.requests.shift().reject(new Error('Unavailable'));await pending;
 check('weather failure retains references and offers retry',()=>{assert.ok(d.getElementById('scene-weather-retry'));assert.match(d.getElementById('modal-body').textContent,/Reference retained/)});
 d.getElementById('scene-weather-retry').click();
 check('weather retry starts a fresh request',()=>{assert.equal(w.requests.length,1);assert.ok(d.getElementById('scene-weather-loading'))});
 w.requests.shift().resolve({});await new Promise(r=>setTimeout(r,0));
 check('weather retry recovers successfully',()=>assert.match(d.getElementById('modal-body').textContent,/12 C/));
 console.log(`All ${count} state checks passed (simulated service responses)`);
}finally{w.close()}
}

/* ---- Auto map island-label policy with a mocked layer API ---- */
{
const html=readFileSync(APP_FILE,'utf8');
const start=html.indexOf('    applyAutoPlaceLabelPolicy(){'),end=html.indexOf('    pauseLinzSymbols(on){',start);
const declaration=html.match(/static AUTO_ISLAND_LABELS = [^;]+;/)[0];
const Adapter=vm.runInNewContext(`class MapLibreLinzAdapter {${declaration}\n${html.slice(start,end)}};MapLibreLinzAdapter`);
const adapter=new Adapter();let zoom=4.7,calls=[];
const layers=[{id:'Place-Label-Island-4',type:'symbol'},{id:'Place-Label-Island-10',type:'symbol'},{id:'Place-Label-City',type:'symbol'}];
adapter.map={getZoom:()=>zoom,getStyle:()=>({layers}),getLayer:id=>layers.find(x=>x.id===id),setLayoutProperty:(...args)=>calls.push(args)};
let count=0;const check=(name,fn)=>{fn();count++;console.log('PASS '+name)};
adapter.vectorStyle='topolite';adapter.applyAutoPlaceLabelPolicy();
check('Auto hides known and additional island labels below 7',()=>{assert.equal(calls.length,2);assert.ok(calls.every(x=>x[2]==='none'))});
check('city labels stay untouched',()=>assert.ok(calls.every(x=>x[0]!=='Place-Label-City')));
calls=[];zoom=7;adapter.applyAutoPlaceLabelPolicy();
check('Auto allows island labels at threshold',()=>assert.ok(calls.length===2&&calls.every(x=>x[2]==='visible')));
calls=[];adapter.vectorStyle='topographic';adapter.applyAutoPlaceLabelPolicy();
check('Topo style is not mutated',()=>assert.equal(calls.length,0));
adapter.vectorStyle='topolite';adapter._linzSymbolsPaused=true;adapter.applyAutoPlaceLabelPolicy();
check('paused symbols are not restored by policy',()=>assert.equal(calls.length,0));
const prepared=html.slice(html.indexOf("            if (mode === 'topolite') {"),html.indexOf('            this._warmStyleDependencies(json, styleUrl);'));
const json={layers:[{id:'Place-Label-Island-4',minzoom:4},{id:'Place-Label-Island-8',minzoom:8},{id:'Place-Label-City',minzoom:2}]};
vm.runInNewContext(prepared,{mode:'topolite',json,MapLibreLinzAdapter:Adapter});
check('first-paint policy preserves stricter native zoom thresholds',()=>{assert.equal(json.layers[0].minzoom,7);assert.equal(json.layers[1].minzoom,8);assert.equal(json.layers[2].minzoom,2)});
console.log(`All ${count} map-policy checks passed (mocked layer API, no map rendering)`);
}

/* ---- Closer-aircraft advisories with mocked positions and DOM ---- */
{
const html=readFileSync(APP_FILE,'utf8');
const between=(a,b)=>html.slice(html.indexOf(a),html.indexOf(b,html.indexOf(a)));
const dom=new JSDOM('<body>'+['primary','iht','sar'].map(x=>`<div class="mini-actions"><button id="${x}-live-aircraft-btn">Live Aircraft</button></div>`).join('')+'</body>');
const points={primary:{lat:0,lng:0},iht:{lat:10,lng:0},sar:{lat:20,lng:0}};
const bases={primary:{lat:4,lng:0},iht:{lat:14,lng:0},sar:{lat:24,lng:0}};
let opened=null;
const c={document:dom.window.document,Date,Number,Set,RULES:{aircraft:{responseFixStaleMs:300000}},feedStatus:'ok',lastFetch:Date.now(),airborne:[{lat:11,lng:0,transmitted:Date.now()}],boundElements:new Set(),openFleetDetail:w=>opened=w,haversineKm:(a,b)=>Math.hypot(a.lat-b.lat,a.lng-b.lng)*111,AirDesk:{primary:{sceneLocation:{getCoordinate:()=>points.primary},nearestResources:{effectiveBase:()=>bases.primary},responseCalculations:{getLiveAircraft:()=>null}},transfer:{workflow:{getOrigin:()=>points.iht,getSelectedBase:()=>bases.iht}},sar:{scene:{getCoordinate:()=>points.sar,getSelectedBase:()=>bases.sar}}}};
c.getAirborne=()=>c.airborne;
runInNewContext(between('function nearerThanBaseText(','function feedHealthText')+between('function refreshPills(){','function openFleetDetail(workflow){'),c);
let count=0;const check=(n,f)=>{f();count++;console.log('PASS '+n)};
for(const w of ['primary','iht','sar'])c.attachStatusLine(w+'-live-aircraft-btn',w);
c.refreshPills();
const pill=w=>c.document.querySelector('#'+w+'-live-aircraft-btn-status button');
check('IHT compares its sending hospital and selected base',()=>assert.ok(pill('iht')));
check('IHT advisory does not leak into Primary or SAR',()=>{assert.equal(pill('primary'),null);assert.equal(pill('sar'),null)});
check('amber IHT action opens IHT fleet',()=>{pill('iht').click();assert.equal(opened,'iht')});
c.airborne=[{lat:21,lng:0,transmitted:Date.now()}];c.refreshPills();
check('SAR uses its own scene and clears IHT advisory',()=>{assert.ok(pill('sar'));assert.equal(pill('iht'),null)});
check('amber SAR action opens SAR fleet',()=>{pill('sar').click();assert.equal(opened,'sar')});
bases.sar={lat:20.5,lng:0};c.refreshPills();
check('nearer selected resource suppresses SAR advisory',()=>assert.equal(pill('sar'),null));
bases.sar={lat:24,lng:0};c.airborne[0].transmitted=Date.now()-300001;c.refreshPills();
check('stale aircraft fix never raises advisory',()=>assert.equal(pill('sar'),null));
c.airborne[0].transmitted=Date.now();c.feedStatus='fail';c.refreshPills();
check('failed feed suppresses advisory',()=>assert.equal(pill('sar'),null));
c.feedStatus='ok';c.lastFetch=Date.now()-300001;c.refreshPills();
check('stale feed suppresses advisory',()=>assert.equal(pill('sar'),null));
c.lastFetch=Date.now();points.sar=null;c.refreshPills();
check('cleared scene removes advisory without fallback to other tab',()=>assert.equal(pill('sar'),null));
check('FENZ preview is a labelled three-row resizable field',()=>{assert.match(html,/<textarea class="preview preview-short" rows="3" id="fenz-lz-preview" aria-label=/);assert.match(html,/\.preview\.preview-short\s*\{\s*height:\s*auto;\s*min-height:\s*0;\s*resize:\s*vertical;?\s*\}/)});
dom.window.close();console.log(`All ${count} aircraft-advisory checks passed (mocked positions and DOM)`);
}
