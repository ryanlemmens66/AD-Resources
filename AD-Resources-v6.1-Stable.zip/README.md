# AirDesk — National Air Desk Resources

A single-file operational desk tool for the Hato Hone St John National Air Desk
(New Zealand). Primary taskings, interhospital transfer, search and rescue, and
a live scene map.

> **Status:** v6.1 **Stable Production Baseline**, build `20260928.9`, frozen
> 28 September 2026 for official live use on the Hato Hone St John National Air
> Desk. The immediate rollback release is v6.0 (frozen 2026-09-24); keep its ZIP
> unchanged. Embedded datasets were last verified 2026-09-24 (`APP.dataVersion`
> `2026.09.24`) and are unchanged by the freeze. Operational and technical
> ownership: Ryan Lemmens. The release is live once the post-deploy sign-off
> below is recorded. See `AUDIT.md` for the freeze verification and
> `CHANGELOG.md` / `RELEASE-NOTES.md` for history.

## Going live -- the short version

1. On a maintainer computer: `npm ci`, then `npm run test:all`. Every suite
   must pass (117 static, 43 runtime, 66 workflow, 9 offline, 7 state,
   6 map-policy, 11 advisory and 200 browser checks at the freeze).
2. Upload the release ZIP to the production Netlify site (*Deployment*).
3. Run the live-origin smoke test and fill in the sign-off record
   (*Production sign-off and external controls*).
4. Tell the desk: reload once online; iPhone/iPad Home Screen users remove
   and re-add the AirDesk icon so iOS captures the new launch screen.
5. If anything in step 3 fails, redeploy the v6.0 ZIP (*Rollback*) and
   record why.

The package is prepared for Netlify deployment, subject to the production sign-off
below. After deployment, reload online: the network-first worker saves a successful
HTML response as the latest shell. A changed HTML file does not require a changed
worker. During a network timeout or server failure, the previously saved shell may
be shown. Verify the deployed build and offline/reconnect behavior on the live origin.

## Start here -- reviewing or taking over this app

**Reading order (about 30 minutes):**

1. This section, then *Where the documentation lives* below.
2. The comment block at the top of `AirDesk-v6.1.html`: especially
   *Standing design decisions*, *Maintenance entry points* and the
   *AI maintenance contract*.
3. `ARCHITECTURE.md`: how the single file is put together and what the checks
   do and do not prove.
4. *Deployment*, *Credentials* and *Production sign-off and external controls* in
   this file.
5. On a maintainer computer with Node 20 or later, run `npm ci`, then
   `npm run test:all` (automated suites and browser checks should pass), then open the HTML file
   in a browser. The release ZIP does not include `node_modules`.

**Things that look wrong but are deliberate.** Please don't "fix" these without
reading why:

| What you'll notice | Why it is like this |
|---|---|
| One 4 MB HTML file with everything inline | It must run from a single file on locked-down desk machines and Citrix. About 75% of it is embedded datasets and the bundled MapLibre library, not app code. No build step by design. |
| No GitHub, no CI; releases are versioned ZIPs uploaded to Netlify | The chosen release process. `npm run test:all` run locally, before the ZIP is created, is the authoritative pre-upload gate -- not something Netlify is relied on to provide. `netlify.toml` does configure `command = "node tools/check.mjs"`, so a build that Netlify actually runs would re-check the static suite, but per Netlify's own current documentation a manual deploy without continuous deployment does not necessarily run a build command at all (behaviour differs by upload path -- CLI, logged-in Drop, and updating an existing site's deploy are not all documented as equivalent). Treat any Netlify-side check as an additional safeguard when it happens, never as a substitute for running the local suite first. |
| Client-side provider credentials visible in the file | A browser app cannot keep client credentials secret. Google and LINZ keys rely on provider-side restrictions and quota controls; the Firebase web key is public by design and data access is controlled by Firebase Security Rules (and, where adopted, App Check). See *Credentials*. |
| Numerous `!important` rules in the application stylesheet | Mostly deliberate base-plus-modifier overrides. Dead ones were removed in v5.12-v5.21; the remainder should be changed only component-by-component with visual regression checks. See the header's *Standing design decisions*. |
| A table of 68 old global names (`legacyPaths`) | Compatibility aliases for older bookmarks and snippets. Nothing in the app uses them; do not remove without checking for outside consumers. |
| Historical references to v4.7.3, v5.0, v5.56 and v6.0 in release history | Preserved history. The current stable baseline is v6.1 (frozen 2026-09-28); the immediate rollback release is v6.0. v5.56 preceded v6.0. |
| Many deliberately empty `catch {}` blocks | Best-effort calls (mainly map/layer updates and cleanup) where failure is expected and harmless. See `ARCHITECTURE.md`. |
| Tail numbers for NRES callsigns fill in by themselves | Per-desk tail memory, learned from the synced board and stored locally, never in Firebase. |

**If ownership or support moves to a new team, update:**

- `GOVERNANCE` in the `#airdesk-core-config` module (operational owner,
  technical owner, data steward). It feeds the Maintenance ownership panel in
  System Status.
- Access to the Netlify site, the Google Cloud project (Maps key restrictions),
  the Firebase project (database rules) and both LINZ credentials -- see
  *Deployment* and *Credentials*.
- The SharePoint links used in the app (for example Helicopter Info), which
  point at the Air Desk site.
- The ownership and contact wording in `README.md` and `NOTICE.md`.

## Where the documentation lives

Five maintenance locations, deliberately:

- **The comment block at the top of `AirDesk-v6.1.html`** is the in-file
  authority: release identity, the *Standing design decisions* to read before
  editing, the module index (*Maintenance entry points*), the dataset
  replacement routes (*Map update routes*), and the *AI maintenance contract*.
- **This file** is the package handover: deployment, credentials, provider
  usage/quota behaviour, the checks, and the production controls and acceptance record.
- **`ARCHITECTURE.md`** explains how the single HTML file is structured, which
  maintenance patterns are deliberate, and what each check can and cannot prove.
- **`CHANGELOG.md`** summarises each release in a paragraph.
- **`RELEASE-NOTES.md`** keeps the full reasoning for each release from v5.0:
  what was checked, what was tried and reverted, and why. (Until v5.23 these
  notes lived in the file header; they moved out in v5.24 to keep it short.)
  Add detailed notes for future releases here, not in the header.

Where they overlap, the in-file block wins -- it travels with the deliverable.

## What's in the package

| File | Purpose |
|---|---|
| `AirDesk-v6.1.html` | The entire application — markup, styles, scripts, datasets, MapLibre GL JS and image payloads, all inlined. This is the deliverable and the source of truth. |
| `sw.js` | Offline shell worker. Caches this HTML file and nothing else, so a reload during an outage still brings up the datasets, the reference content and the response calculation. Must deploy in the same folder. |
| `netlify.toml` | Deployment config: root rewrite, the NZTA same-origin proxy, cache policy, security headers, CSP. |
| `ARCHITECTURE.md` | How the file is put together — module layout, how the app validates itself, the editing traps, and what a code reviewer will flag. Read before editing the HTML. |
| `CHANGELOG.md` | Concise release history and verification record for each preserved edition. |
| `RELEASE-NOTES.md` | Full reasoning, checks and corrections for each release from v5.0 (moved out of the file header in v5.24). |
| `tools/check.mjs` | Static pre-deployment check. See *Checks* below. |
| `tools/verify.mjs` | Runtime check — boots the app in jsdom. See *Checks* below. |
| `tools/browser-check.mjs` | Chromium layout, interaction and serious/critical accessibility regression check. |
| `tools/visual-check.mjs` | Before/after screenshot comparison for visual or stylesheet changes. See *Checks* below. |
| `tools/dataset-baseline.json` | The feature counts and full id set of every approved dataset at the current protected/reverified baseline. What id retention is checked against. |
| `tools/dataset-baseline.mjs` | Regenerates that baseline. Run it deliberately after an approved import or explicit operational-data reverification. |
| `tools/lib.mjs` | Shared helpers for both scripts. |
| `NOTICE.md` | Copyright status. There is deliberately no `LICENSE` — read it before reusing anything. |

There is no application build step. The app itself has no dependencies.
`npm ci` supplies the lockfile-pinned jsdom, Playwright and Axe versions for the verification tools;
`npm run check` runs on a bare Node install. The complete locked verification suite requires **Node 20 or newer** because the packaged Playwright 1.63 dependency requires Node 20+. The filename carries the version and the tools discover it
rather than hard-coding it, so exactly one `AirDesk-v*.html` should be present
at a time.

## Deployment

> **Public vs package files.** Netlify publishes the whole folder, so
> `netlify.toml` returns 404 for the maintainer files (README, CHANGELOG,
> RELEASE-NOTES, ARCHITECTURE, NOTICE, package files, `netlify.toml`,
> `tools/`). They are still in the ZIP. If you add a new maintainer file,
> add a matching rule; only the app HTML and `sw.js` need to be public.

**Netlify.** Upload the complete `AD-Resources-vx.x.zip`. Keep the package
structure intact. `netlify.toml` supplies the publish directory, structural
check, redirects, proxy and response headers.

Three things in that file are load-bearing rather than boilerplate:

- **The root rewrite.** The HTML is versioned rather than named `index.html`,
  so without `from = "/"` the site root is a 404 and the desk is only reachable
  at the versioned path. **On every version bump, rename the file and update
  both rewrites together.** The check asserts this, because the failure mode is
  invisible to whoever just deployed — the versioned URL they are testing still
  works, and only the bookmark breaks.
- **The NZTA proxy.** `#airdesk-nzta` tries the ArcGIS FeatureServer first, then
  `/airdesk-nzta-delays.json`, then the Journeys URL direct. That direct call is
  CORS-locked, so the rewrite is the only fallback that can actually succeed.
  Without it the road-warnings layer silently stays empty whenever the
  FeatureServer is down. Verified working against the deployed site
  2026-09-14; it cannot be tested locally, because the rewrite only exists on
  Netlify.
- **`Referrer-Policy: strict-origin-when-cross-origin`.** Keep this policy so
  provider-side website/referrer restrictions can function where configured.
  Do not infer from the header that any provider restriction has actually been
  applied: Google and both LINZ credentials still need their production-account
  settings confirmed under *Production sign-off and external controls*.

### Offline and updates — a deliberate difference from Clinical Hub

**AirDesk has a deliberately narrow service worker.** It caches the application
shell only, using a network-first request with a three-second timeout. During an
outage the embedded datasets, clinical guidance and typed response calculation
remain available. Live feeds, map tiles and remote services are never cached,
so stale operational information cannot be presented as current. The worker
uses a fixed cache key and therefore needs no filename edit on a version bump.

The running build identifies itself through the header chip (`#build-version`),
which reads from `APP.version` in `#airdesk-core-config`. That chip has gone
stale before — v5.0 shipped with markup still reading v4.6.1 — so the check now
asserts that the constant, the filename and the chip all agree.

### Operator assurance in v5.4 and v5.5

System Status shows when Maps, TracPlus, Heli Status and Shift Notes were last
confirmed. TracPlus changes to **Stale** if a successful poll has not been
confirmed for three minutes. This catches suspended tabs and stalled polling
without changing the feed interval or discarding the existing aircraft cache.

The **Run Self-check** button in System Status inspects the loaded release,
configuration, app shell, embedded datasets, map state, shared sync state and
secure hosting. It reads state already held by the application and deliberately
makes no Google, LINZ, TracPlus, Firebase or other provider request.

v5.5 makes the self-check environment-aware. It verifies embedded content
through the canonical `AirDesk.data` module registry, so an immediate check no
longer fails while map layers are still registering. HTTP localhost and
127.0.0.1 are shown as **Local Test** information. Any non-local HTTP deployment
still fails the secure-hosting check, while Netlify HTTPS passes.

## Checks

```bash
npm ci           # install locked test dependencies
npx playwright install chromium # once, for the browser check
npm run check    # static source and package checks
npm run verify   # initialization and reference checks in jsdom
npm test         # static, runtime, workflow, offline, state, map-policy and advisory suites
npm run browser  # desktop, Citrix-sized, iPad and phone profiles, Axe and board checks
# if the Playwright browser can't download, point at an installed Chromium:
# AIRDESK_CHROMIUM=/path/to/chrome npm run browser
npm run test:all # all checks
```

For any visual or stylesheet change, also prove what did (or did not) change
on screen:

```bash
npm run visual:baseline   # before editing: 54 screenshots, desktop + iPad + phone
npm run visual:compare    # after editing: lists every screen that changed
```

`tools/visual-check.mjs` covers every tab (empty and with a scene), CAD notes,
five dialogs, the Heli Status Board live and in Edit mode, the map type menu,
and Board View desk and wall. The clock is frozen, providers are blocked and
version numbers are blanked, so a version bump alone never counts as a change.
Screenshots go to the system temp folder, never into the package. Up to 40
changed pixels on a screen is reported as anti-aliasing noise. The same before/after screenshot discipline was used during the v5.12-v5.23
stylesheet cleanup series; the reusable packaged tool now keeps that workflow
repeatable for future visual changes.

### Tasking & Clinical Guidance update route

The approved **National Air Desk Tasking & Operating Guidelines PDF** is the
authority for the **Tasking & Clinical Guidance** modal. Approved wording lives
in one place only, the inert HTML template
`#airdesk-tasking-clinical-guidance-content`. The renderer provides navigation,
search and presentation only. Do not maintain a second guidance-content dataset
or copy approved wording into executable JavaScript.

The current v2.01 template has seven operator-facing categories: Clinical
Conditions; ANTS Criteria & Specific Skills; Area Specific Considerations;
Tasking, Landing & Destinations; Escalation, Coordination & Major Incidents;
Other Agencies & RCCNZ Advice; and Principles & Definitions. Category order and
source-section mapping are deliberately checked by all three regression suites.

When the guidelines are replaced or extended:

1. Supply the **current AD-Resources ZIP** and the **new complete approved PDF**.
   The PDF is an update source, not a runtime dependency and is not packaged.
2. Compare every mapped source section in full, including headings, tables,
   thresholds, examples and narrative wording. Add, remove or reorder content
   only to match the approved source. Preserve issued numbering and wording,
   including source-document anomalies.
3. Update the template metadata (`data-guidance-version`, source dates,
   `data-source-pages`, `data-source-sections` and `data-source-sha256`) and each
   category's own source-section/page map.
4. Update the `tasking-guidelines` entry in `#airdesk-core-config` so System
   Status reports the same approved version and review date.
5. Update the matching expectations in `tools/check.mjs`, `tools/verify.mjs` and
   `tools/browser-check.mjs`. Search all three files for removed or renamed
   category/section ids rather than changing only the first failing assertion.
6. Review any **other owning module** affected by the new PDF in the same
   release. Examples include SAR, hospital/reference data, CAD quick-reference
   material and operational timing rules. Do not duplicate those sources into
   the guidance template merely to make updating easier.
7. Run `npm run test:all`. For a large presentation change, also run the visual
   baseline/compare workflow and review the guidance screens at desktop, iPad
   and phone widths -- the phone profile exists specifically because this is
   the one category of layout bug desktop/iPad testing alone cannot catch
   sizes.

Section ranges across categories should not overlap except where the approved
source itself does so. The issued v2.01 guideline lists section **4.14 twice**
for two different clinical topics, so AirDesk preserves that numbering exactly
and relies on unique internal section ids. Section 12.2.2's maternity-facility
table is also not duplicated because the same issued table is already shown at
4.25.1.

The current viewer covers the approved desk-reference content from sections
1-9, 11-16, callsign management at 17.9-17.9.1, coordination at 18.0-18.1,
major incidents at 19.0-19.2 and RCCNZ clinical advice at 21.0. Section 10 is
implemented by the maintained calculation engine and `AirDesk.rules`; most of
section 17 is CAD procedure; section 20 describes other Air Desk applications.

### Map data update routes

Mapping data is maintained **in its owning module**, never by adding a second
overlay, late patch script or duplicate FeatureCollection. For a future update,
start from the latest production ZIP plus the complete replacement source file,
replace the canonical data, preserve stable feature ids for surviving features,
and run the dataset-id diff before accepting the release.

| Owning module | Update source / responsibility | Maintenance rule |
|---|---|---|
| `#airdesk-aerodromes-lzs` | Approved aerodrome / landing-zone workbook | Replace the canonical FeatureCollection. Preserve `properties.id` for sites that remain. |
| `#airdesk-aviation-guidance` | Approved 3A Air Desk guidance plus selected MapIT operational points (8C Rafting Evac Sites, 8D Makara Peak Evac Sites, 8F Taranaki Basin Oil Rigs), the 12 NM limit and the approved 40 km road-distance trauma rings | Replace the owning embedded data rather than adding parallel layers. Preserve surviving ids. Do not import the separate 40-minute trial trauma rings; airstrips and Jet A1 fuel are deliberately excluded from AirDesk. |
| `#airdesk-clinical-pathway-layers` | Approved STEMI, stroke, major-trauma and SCI/catchment KML/KMZ | Update the shared pathway geometry and assignments in this module. Do not add a parallel pathway layer to compensate for an old one. |
| `#airdesk-hospitals` | Hospital coordinates, short codes and hospital-specific `helipadToEDMin` | Keep one canonical hospital record. If Section 10.5 changes, update the value here once. |
| `#airdesk-hems-bases` | HEMS base coordinates and callsign/base definitions | Preserve base ids because calculations, map labels and fleet logic reference them. |
| `#airdesk-maternity-medical-centres` | Approved maternity-unit and medical-centre CSV data | Replace the source arrays in this module. |
| `#airdesk-emergency-resources` | Ambulance, FENZ, Surf Life Saving and Coastguard source packs | Replace the relevant owned resource dataset, not the renderer. |
| `#airdesk-marlborough-jetties` | Marlborough jetty CSV | Preserve ids for retained jetties. |
| `#airdesk-huts-campsites` | Huts and campsites CSV | Preserve ids for retained locations. |

`tools/dataset-baseline.json` currently protects the approved id spaces for
eight datasets: 748 aerodrome/LZ features, 960 Marlborough jetties, 1,249
huts/campsites, 41 hospitals, 16 HEMS bases, the clinical-pathway registry, and
**two** datasets sharing the `#airdesk-aviation-guidance` module -- 405 IFR
route features and 274 Air Desk Guidance features, baselined separately (as
`ifr-routes` and `air-desk-guidance`) precisely because they are unrelated
datasets that happen to live in one script block. Baselining them together
under one combined id space would let a large loss from the smaller,
actively-maintained Guidance set hide behind the larger, effectively static
IFR set never tripping the 90% retention floor -- confirmed by simulating a
60-id (22%) loss from Guidance alone, which the split catches and the combined
approach would not have. Any future module that combines more than one logical
dataset in one script block should be split the same way when it is baselined,
not folded into one entry for convenience. The pathway entry has no standalone
feature-id set because that module owns shared geometry/layer configuration
rather than a flat feature collection. Do not regenerate the baseline just to
make a failing check green. Review the added/removed id diff first, then
regenerate it only as part of an approved source-data import.

Live/support feeds such as TracPlus and NZTA are provider integrations, not
embedded mapping imports. Changing their endpoints belongs in
`#airdesk-core-config` / the owning integration module and may also require a
CSP or Netlify-proxy change.

### Operational timing and default updates

Operational timing constants have one maintained home: `AirDesk.rules` inside
`#airdesk-core-config`. The response, transfer, SAR, nearest-resource and live
aircraft fallback paths all read those rules rather than carrying their own
copy of the same numbers. Current groups include:

- `rules.aviation`: km-to-NM conversion, cruise speed, daytime takeoff, normal
  night takeoff, extended-night takeoff, Te Anau takeoff and the bases to which
  the special rules apply.
- `rules.road`: fallback road speed and the road-time cushion.
- `rules.response`: helicopter/road scene defaults, response delay, clinical
  intercept and the major-trauma ring.
- `rules.aircraft`: airborne/ground speed thresholds and feed/freshness values.

Hospital-specific helipad-to-ED times are deliberately **not** copied into
`AirDesk.rules`; they belong to each canonical hospital record in
`#airdesk-hospitals`. If an approved guideline changes Section 10 or another
timing source, update the owning rule/hospital value once, then run all checks
and compare representative Primary, IHT and SAR calculations against the new
source. Do not compensate by editing downstream formulas or adding a late
override.

### Release workflow

The GitHub repository stores the versioned release ZIPs only; it runs no CI
and is not part of the release gate. Before each Netlify upload, run
`npm run test:all` -- this is the authoritative gate; nothing about the
Netlify upload step is relied on to catch what it would have caught. Create
the next versioned folder and ZIP, and retain the previous ZIP unchanged.
`netlify.toml` configures `command = "node tools/check.mjs"`, so if Netlify
does run a build for a given upload, it re-checks the static suite -- but
per Netlify's own current documentation, a manual deploy without continuous
deployment does not necessarily run a build command, so this cannot be
assumed to happen on every upload. The jsdom and browser suites only ever
run locally; nothing on Netlify's side runs them under any circumstance.

Exit code 0 clean, 1 on failure. Checks printed **OPEN** are non-blocking review items rather than
defects and do not fail the run.

`check` proves the file is well-formed. `verify` proves it assembles itself.
The division is load-bearing: inject a `throw` at the top of any module and
`check` stays green — an aborting module's syntax is still valid — while
`verify` fails naming the missing subsystem. That is the failure mode that took
down the previous Air Desk lineage twice.

What it guards, and why each one is there:

| Check | The failure it catches |
|---|---|
| Inline script blocks parse | A syntax error kills its whole block silently. Several blocks here are a single data domain, so losing one loses a map layer with nothing surfaced. |
| HTML comment pairs balance | A comment opened `<!--` and closed `*/` raises no error anywhere — the browser consumes markup as inert text to the next real `-->`. This has previously swallowed an entire CSS block and a whole script while every syntax check passed. |
| Tag balance, duplicate ids | Ordinary markup rot. |
| Named functions, none unreferenced | Dead code. Named IIFEs are excluded — this codebase scopes binding steps that way and they are not dead. |
| No `console.log` / `debugger` / `alert()` | Debug leftovers. The bundled MapLibre block is excluded; its ten `console.log` calls are vendor code. `console.warn` and `console.error` are deliberate diagnostics and are not flagged. |
| netlify.toml rewrites point at the app file | The version-bump trap described above. |
| `APP.version` = filename = header chip | The stale chip. |
| `APP.buildDate` = file-header build date | Prevents a new ZIP carrying the previous release date in its exported metadata. |
| CSP `connect-src` covers every fetched origin | `netlify.toml` says "when an endpoint is added there, add it here". This is that promise, checked. |
| Client credentials/config entries accounted for | Google Maps, LINZ Basemaps, LINZ Data Service and Firebase are all required in their canonical locations. |
| Provider credentials remain single-source | Google Maps and both LINZ values must each occur only in the expected configuration location; the two LINZ keys must remain distinct. |
| **Dataset ids retained** | The contract's central rule, made mechanical. See below. |

### What `verify` guards

Boot completes inside a ceiling; every required namespace and named subsystem
under `primary`, `sar`, `transfer`, `map` and `system` present;
`AirDesk.system.configStatus` valid with no issues; `APP.version` agrees with
the filename; the service catalogue covers all six providers (DOC was removed
at v5.53 as unreachable dead code -- see CHANGELOG.md); 20 reference
data modules registered; tab bar and app shell rendered; nothing fixed and
full-viewport covering the UI; no unexpected console errors.

That configuration check matters because the app has always validated itself —
schema version, unique registry ids and titles, a `dataVersion` on every static
layer, ISO review dates — and surfaced the result only in the System Status
modal, which nobody opens on a good day. Now it fails the build.

### Dataset id retention

The update contract's central rule is that a feature surviving an approved
re-import keeps its existing id, even when its name, coordinates or metadata
change — everything cross-references by id. Nothing in the app enforces that.
`validateFeatures()` checks a feature is a Feature with a supported geometry and
stops there; `validateUniqueIds()` guards the CONFIG registries, not the data.

An export that renumbered all 748 LZs would register cleanly, boot cleanly, and
pass every other check here, because the feature count would be unchanged.

So `tools/dataset-baseline.json` stores the approved id spaces themselves — 3,693 ids
across eight dataset entries (the pathway registry intentionally has no standalone feature ids). The check then:

- **fails** on duplicate ids, or when fewer than 90% of the baseline ids survive
  (the id space was replaced rather than edited)
- **reports** anything smaller as an added/removed diff, naming the ids

That report *is* the id-level diff the contract asks a maintainer to produce
before accepting an import — you no longer have to remember to ask for it.
Sites legitimately come and go, so a small diff is informational; after checking
it, regenerate the baseline with `node tools/dataset-baseline.mjs` in the same
commit as the import.

**Neither check can see rendering.** jsdom has no WebGL, so MapLibre never
initialises and the app runs its `PlaceholderMapAdapter` fallback — which is
the path `verify` exercises. Map tiles, layer draw order, terrain and the
measurement tool still need a real device. Two console errors during `verify`
(`createObjectURL is not a function`, `MapLibre GL JS did not load`) are that
fallback working as designed and are allowlisted.

## Credentials

Four client-side configuration credentials are expected in this package:
Google Maps, LINZ Basemaps, LINZ Data Service and the Firebase web API key.
They are intentionally client-visible. Google/LINZ protection is provided by
the provider's supported website/API restrictions and quota controls; Firebase
Realtime Database access is controlled by its server-side Security Rules, not
by hiding the Firebase web key. `tools/check.mjs` enforces the canonical
locations and single-source expectations so a future rotation does not miss an
embedded copy.

### Google Maps Platform

`runtimeConfig.googleMapsApiKey`. **Shared with Clinical Hub Resources,**
deliberately — the file's own comment reads *"Desk keys — restrict LINZ + Google
to this origin in the provider consoles. Do not add a second unrestricted key."*

Because the two apps share one key, the API restriction list is the **union of
both**, not just AirDesk's five:

| API | Used by |
|---|---|
| Routes | both |
| Geocoding | AirDesk |
| Maps JavaScript | AirDesk (loaded only to reach `ElevationService`) |
| Maps Elevation | AirDesk |
| Weather | AirDesk |
| Address Validation | Clinical Hub only |

Restricting to AirDesk's five breaks Clinical Hub's address search; restricting
to Clinical Hub's two breaks most of AirDesk. Referrer restriction needs **both**
Netlify origins on the key.

Places API is not used by either app and should stay disabled.

### LINZ services

`runtimeConfig.linzApiKey` supplies LINZ Basemaps tile/style access.
`runtimeConfig.linzDataServiceApiKey` is a separate LINZ Data Service
credential used by the Powerlines WFS layer. They are deliberately different
keys and must not be merged during rotation. LINZ's current Basemaps
documentation states that Developer-access keys can be restricted to a
nominated website by contacting LINZ. Confirm the applicable restriction for
both credentials with the account owner rather than assuming the same control
surface or policy applies to every LINZ product.

### Firebase

`#airdesk-firebase-config` — project `air-desk-resources`, Realtime Database in
`asia-southeast1`, compat SDK 10.14.1 from gstatic. This is the shared-desk
board: handover, shift notes, heli status.

The web API key here is **public by design** and is not the same kind of secret
as the Maps key — the database is protected by its security rules, not by that
key. Rules must allow read/write under `airdesk`.

Do not copy plan limits or pricing into this handover document: they can change
independently of the application. Confirm the current Firebase plan, quotas,
billing state and rule deployment in the Firebase/Google Cloud consoles during
production sign-off.

## Provider usage, quota and failure behaviour

Provider pricing, free allowances and SKU names change independently of
AirDesk, so this document deliberately does not freeze current dollar amounts
or monthly allowances. Before changing production quotas or billing controls,
check the current provider documentation and the account's own console.

The maintainable application contract is the request/failure behaviour:

| Action | Provider work performed |
|---|---|
| Scene search (address) | Geocoding, then a road route |
| Scene search (DDM / lat-long, or set from map) | Road route only; `parseDirectCoordinate` skips geocoding |
| Repeat of a recently cached address query | Geocode may be absorbed by the app cache; route is refreshed |
| Change destination hospital/base or select a live aircraft | Recomputes the road route |
| Open Compare Hospitals | Uses a route matrix; provider charging may be per element |
| Open Scene Weather | Weather lookup, cached per coordinate |
| Drop an LZ pin | Elevation sampling, cached per coordinate |
| SAR scene search | Geocoding/reverse-geocoding as required; no road-route call |

Routing intentionally requests traffic-aware results. Do not switch routing
preference for cost reasons without an operational decision and regression
testing, because it changes the ETA presented to the desk.

**Quota/provider failure behaviour.** `routeMinutes` falls back to
`estimatedRoadMinutes`, displayed as `~N min (est.)` with approximate
kilometres. Elevation, Weather and the comparison matrix fail within their own
panels. Geocoding is different: an address cannot be resolved if the geocoding
provider is unavailable, although direct coordinates can still be entered.
For that reason, production quota changes should be validated against the
actual workflows before being tightened.

Provider website/referrer restrictions also mean calls may fail when the HTML
is opened from `file://` or an unapproved origin. The supported production
behaviour is the deployed HTTPS origin.

## Editing traps

Read the *AI maintenance contract* in the file header first. Beyond it:

- **Tasking & Clinical Guidance lives in the inert
  `#airdesk-tasking-clinical-guidance-content` template.** Edit only the
  markup inside that template. Backticks and `${...}` are ordinary text there
  and cannot execute as JavaScript. Do not add a literal `</template>` inside
  the content because that would close the container early.
- **Datasets are replaced in the owning module,** never duplicated into a second
  source. The header lists which module owns which approved source.
- **Approved-dataset imports must retain existing feature ids** for sites that
  survive the import, even when names, coordinates or metadata change. An
  automated rewrite will silently renumber them. Ask any tool that produces a
  replacement dataset for an id-level diff — added, removed, retained — as a
  separate output, and check that before checking the content.
- **Four LZ fields are near-empty by history, not by fault.** `expiryDate`
  (747/748 blank), `lastVerified` (745/748), `hazards` (738/748) and
  `fenzNotes` (714/748) were never captured for the historic landmark sites the
  dataset was built from. Sites added from here carry them. Do not treat the
  blanks as an import defect or backfill them with placeholder text.
- **CSS order is intentional.** Apparent duplicates require cascade and device
  testing.
- **`AirDesk.services.catalog` and the CSP `connect-src` must move together.**
  The check enforces this.

## Production sign-off and external controls

v6.1 is the frozen software baseline for official live use (build
`20260928.9`, frozen 2026-09-28). The static ZIP can prove configuration shape
and behaviour under test; it cannot inspect provider consoles, Firebase
server-side rules or the deployed origin. Those are external attestations by
the named owner, recorded here.

### A. Controls carried forward from the v6.0 freeze

Items 1 to 5 were confirmed by the production/account owner, **Ryan Lemmens**,
on 2026-09-24. v6.1 changes none of the keys, origins, provider APIs, Firebase
paths, CSP origins or embedded datasets they cover, so they carry forward
unchanged. Reconfirm an item only if its subject has changed since that date.

1. **Google Maps account/restrictions — confirmed.** Owned by Ryan Lemmens;
   website/API restrictions in place. The key is shared with Clinical Hub
   Resources, so rotation or restriction changes must keep both apps' origins
   and APIs (see *Credentials*).
2. **LINZ Basemaps and Data Service restrictions — confirmed.** Both separate
   credentials are owned/controlled by Ryan Lemmens with production
   restrictions confirmed. Keep `linzApiKey` and `linzDataServiceApiKey`
   distinct and single-source in `runtimeConfig`.
3. **Firebase production controls — confirmed by the project owner.** The
   embedded client configuration is not a security boundary; Realtime Database
   Security Rules are the authoritative control and must be reviewed again if
   the access model changes.
4. **Operational-source review — closed.** Confirmed 2026-09-24: SH6 Haast to
   Lake Moeraki remains closed until further notice; the PARAPARA 30-minute
   road-time adjustment is permanent; Waihi Bowling Club is the active LZ
   replacing inactive Morgan Park. `APP.dataVersion` is `2026.09.24`. Future
   changes still need an approved operational source or owner confirmation,
   never an inferred software edit. The Waitematā STEMI diversion rule is
   prompted for review in System Status from 4 February 2027.
5. **TracPlus proxy arrangement — accepted for production.** The Cloudflare
   Worker/account arrangement is accepted. An ownership or endpoint change must
   update the service registry, CSP and this record together.

### B. Freeze gate — complete before upload

6. **Automated gate.** `npm ci` then `npm run test:all` on a maintainer
   computer, all suites passing. Recorded for the freeze in `AUDIT.md`.
7. **Clinical and operational content owner confirmation.** The operational
   owner confirms the embedded Tasking & Clinical Guidance (v2.01, 15 May 2026),
   hospital, LZ and pathway data are current for live use. Software checks
   prove the content is intact, not that it is clinically current.

### C. Live-origin smoke test — complete after upload

8. Open the **root** production URL (not the versioned filename) and run
   through:
   - **Identity:** on desktop or iPad the header chip reads **v6.1**, and System
     Status shows build **20260928.9** and baseline *6.1 Stable Production*.
     On a phone (650px or narrower) the chip is hidden by design; tap the
     green-dot Desk Status panel and confirm Build 20260928.9.
   - **Self-check:** System Status → Run Self-check reads *All deployment
     checks passed.* and Secure deployment shows *HTTPS is active.*
   - **Workflows:** Primary, Transfers, SAR and Resources each open; one real
     address search returns a route with a live road time (not `~N min (est.)`).
   - **Live services:** map tiles draw on Auto, Topo and Aerial; TracPlus
     aircraft appear and System Status shows them fresh; Scene Weather loads;
     NZTA warnings layer populates; Heli Status and Shift Notes load and a
     test note saves and syncs to a second device (then remove it).
   - **Board View, Tasking & Clinical Guidance and CAD outputs** open and copy.
   - **Offline:** after one online load, turn the network off and reload; the
     app shell, reference content and response calculation still open. Turn
     the network back on and confirm live feeds recover.
   - **iPhone/iPad Home Screen:** remove any existing AirDesk icon, open the
     URL in Safari, wait a few seconds, then Add to Home Screen. Launch it:
     one continuous green splash, then the app, with the header clear of the
     status bar/notch. Check portrait and landscape.
   - **Citrix / desk workstation:** the actual desk session loads, Citrix
     mode can be chosen, and the map performs acceptably.

### D. Sign-off record

Fill this in on the day of the live upload and keep it with the release ZIP.

| Field | Value |
|---|---|
| Release | AirDesk v6.1, build `20260928.9`, Stable Production Baseline |
| Release ZIP and SHA-256 | `AD-Resources-v6.1-Stable.zip`; SHA-256 in `AD-Resources-v6.1-Stable.zip.sha256` beside it |
| Production URL | |
| Netlify deploy ID and time | |
| Items 1–5 carried forward (or reconfirmed on) | 2026-09-24 |
| Item 6 automated gate | Passed 2026-09-28 (`AUDIT.md`) |
| Item 7 content owner confirmation (name, date) | |
| Item 8 smoke test (devices, date, result) | |
| Rollback artifact | v6.0 ZIP, retained unchanged |
| Production owner sign-off (name, date) | Ryan Lemmens, |

9. **Ownership and support.** Operational and technical ownership remains with
   Ryan Lemmens. If Digital & Data formally accepts support later, update
   `GOVERNANCE` in `#airdesk-core-config`, this README and `NOTICE.md`, and
   record the transfer as its own release rather than silently changing
   ownership metadata.

### Rollback

If the smoke test or live use shows a defect that affects operations, do not
patch the live copy. Upload the retained v6.0 ZIP to the same Netlify site (or
use Netlify's *Publish deploy* on the previous v6.0 deploy), reload every desk
once online, and confirm the chip reads v6.0. The service worker is
network-first, so an online reload picks up the rolled-back HTML. Record the
reason in `CHANGELOG.md` and fix forward from the v6.1 ZIP.

### Stable-baseline promotion procedure

v6.1 is the current stable production baseline (promoted from v6.0 on
2026-09-28 using this procedure). Use it only when promoting a future release
to replace that baseline:

1. Start from the last fully tested versioned ZIP. Do not develop directly in
   the deployed copy.
2. Create the new release folder/file, update `APP.version`, package metadata
   and both Netlify rewrite targets. If the release is being formally adopted
   as the new rollback/stable baseline, update the header baseline text and
   `APP.baseline` deliberately in the same release. Otherwise leave the v6.1
   baseline metadata unchanged.
3. Update `CHANGELOG.md` and `RELEASE-NOTES.md` with what changed and what did
   not. Keep historical release facts historical rather than globally
   replacing old version numbers.
4. Run `npm ci` and `npm run test:all`. For any visible/CSS change, also run a
   before/after visual comparison. Resolve every failing check rather than
   weakening the assertion to make a release pass.
5. Increment `APP.buildId` for each changed working package. Keep `APP.buildDate`
   and the HTML header Build date aligned; keep the release version unchanged
   until a version change is authorized. Package the project contents at the archive root, including the HTML,
   `sw.js` and `netlify.toml`. Exclude `node_modules`, temporary files and
   screenshots. Verify ZIP integrity and record its SHA-256.
6. Upload through the approved Netlify workflow. Do not assume a manual upload
   ran the configured build command unless the deploy log shows it.
7. Run the production smoke test above on the live HTTPS origin, then record
   the deployed version, date, checksum and named production owner. Keep the
   immediately previous production ZIP as the rollback artifact and record the
   replacement baseline decision in both CHANGELOG and RELEASE-NOTES.

Controls already resolved in the application do not need reopening during a
routine handover: CSP is enforced, the service worker caches only the offline
shell, GitHub/CI is not part of the release workflow, and Playwright browser
verification is already packaged. `npm run test:all` remains the pre-release
regression gate, followed by the deployed smoke test above.

## Related

Clinical Hub Resources is a separate application that shares this
one's Google API key and its audit conventions. Changes to key restriction
affect both.
